# Esports Warmup Routine — Pre-Game Rituals That Actually Work

> **Price:** $3 | **Skill Level:** All Levels | **Format:** Markdown Guides + JSON Templates

## What Is This?

Stop jumping straight into ranked and wondering why you're playing like garbage for the first 3 games. This is a complete warmup system — backed by actual sports science — designed for competitive gamers.

**Your hands are cold. Your reaction time is 20% slower. Your crosshair placement is off.** All because you skipped warmup. This guide fixes that with 15-minute routines tailored to your game.

## What's Included

| File | Description |
|------|-------------|
| `src/warmup_fundamentals.md` | The science of warming up — why it matters, what happens to your body |
| `src/fps_warmup.md` | 15-minute routine for FPS games (Valorant, Apex, CS2) |
| `src/moba_warmup.md` | 15-minute routine for MOBAs (League of Legends, Dota 2) |
| `src/aim_drills.md` | Aim trainer exercises for Aim Lab and Kovaak's |
| `src/hand_stretches.md` | Wrist and hand exercises to prevent RSI and carpal tunnel |
| `examples/schedule_templates.json` | Weekly practice schedules for different commitment levels |

## Quick Preview

### The 15-Minute FPS Warmup (Summary)

```
MINUTE 0-3:   Hand stretches (prevent injury, increase blood flow)
MINUTE 3-6:   Aim trainer — tracking drills (smooth mouse control)
MINUTE 6-9:   Aim trainer — flick drills (snappy target acquisition)
MINUTE 9-12:  Deathmatch / practice range (in-game feel)
MINUTE 12-15: Crosshair placement drill (holding angles, peeking)

Total: 15 minutes. That's it. Then you queue ranked.
```

### Why 15 Minutes?

Research on physical sports warmups shows diminishing returns after 15-20 minutes of targeted warmup. Longer than that and you're:
- Fatiguing your hands before the actual session
- Burning motivation on drills instead of real games
- Not actually getting better (just doing busy work)

15 minutes is the sweet spot: enough to activate muscle memory, not enough to drain you.

## How to Use

1. **Start with `src/warmup_fundamentals.md`** to understand WHY warming up works
2. **Pick your game type** — `fps_warmup.md` or `moba_warmup.md`
3. **Always do hand stretches** from `src/hand_stretches.md` (seriously, RSI is real)
4. **Use `examples/schedule_templates.json`** to build a weekly practice plan
5. **Read `src/aim_drills.md`** for detailed aim trainer routines

## Who This Is For

- Competitive players who want consistent performance from game 1
- Anyone who feels "cold" for their first few matches
- Players who game 4+ hours and want to prevent hand injuries
- Teams that want a shared warmup routine before scrims

## FAQ

**Q: I don't have Aim Lab or Kovaak's. Can I still use this?**
A: Absolutely. Each game's warmup includes in-game alternatives (practice range, deathmatch, bot matches). The aim trainer drills are a bonus, not a requirement.

**Q: What if I only have 5 minutes?**
A: Do the hand stretches (2 min) + one aim drill (3 min). Something is always better than nothing.

**Q: Is this just for PC players?**
A: The hand stretches and game-specific warmups work for all platforms. The aim trainer sections are PC-focused since Aim Lab and Kovaak's are PC apps.

## License

MIT License — see LICENSE file.
