# Warmup Fundamentals — The Science Behind Pre-Game Routines

## Table of Contents
1. [Why Warming Up Works](#why-warming-up-works)
2. [What Happens When You Don't Warm Up](#what-happens-when-you-dont-warm-up)
3. [The Science (Simplified)](#the-science-simplified)
4. [Mental vs Physical Warmup](#mental-vs-physical-warmup)
5. [The Optimal Warmup Window](#the-optimal-warmup-window)
6. [Common Warmup Myths](#common-warmup-myths)
7. [Building Your Personal Routine](#building-your-personal-routine)

---

## Why Warming Up Works

Every professional athlete warms up before competing. Basketball players shoot
free throws. Sprinters do stride-outs. Boxers shadowbox.

**Esports athletes are no different.** Gaming requires:
- Fine motor control (mouse precision, key timing)
- Fast reaction time (200ms or less in FPS games)
- Pattern recognition (reading enemy movement)
- Decision-making under pressure (clutch situations)

All of these are WORSE when you're cold. Here's the proof:

```
STUDY: Reaction Time Before vs After Warmup
(Based on sports science research on fine motor tasks)

  Cold (no warmup):        Average reaction time: 280ms
  After 5 min warmup:      Average reaction time: 245ms  (-12.5%)
  After 15 min warmup:     Average reaction time: 225ms  (-19.6%)
  After 30 min warmup:     Average reaction time: 228ms  (diminishing returns)

  TRANSLATION FOR GAMING:
  280ms reaction = you die to a peek before your crosshair moves
  225ms reaction = you trade kills or win the duel
  
  That 55ms difference? It's the difference between:
  - Dying to the Jett dash-peek
  - Killing the Jett mid-dash
```

### The Cold Start Problem

You know this feeling:

```
Game 1: "Why is my aim so bad?"     → 5 kills, 12 deaths
Game 2: "Getting better..."         → 8 kills, 9 deaths  
Game 3: "Now I'm warmed up!"        → 14 kills, 6 deaths

YOU JUST WASTED 2 FULL GAMES as your warmup.
That's 40+ minutes of ranked where you're playing below your real skill.
Your teammates are malding. Your rank is tanking. All preventable.
```

A proper 15-minute warmup means **Game 1 feels like Game 3.**

---

## What Happens When You Don't Warm Up

### Your Hands Are Cold (Literally)

Blood flow to your fingers decreases when you're at rest. Cold fingers mean:

```
COLD HANDS EFFECTS:
  ├── Slower fine motor control (mouse movements less precise)
  ├── Reduced grip strength (mouse slips, keys feel heavy)
  ├── Stiffer joints (less fluid wrist movement)
  └── Higher injury risk (cold tendons are more prone to strain)

WARM HANDS EFFECTS:
  ├── Faster nerve conduction (signals reach muscles quicker)
  ├── Better blood flow (muscles respond faster)
  ├── Looser joints (wider range of motion)
  └── Lower injury risk (warm tendons are elastic and flexible)
```

### Your Brain Is in "Idle Mode"

Your brain has different modes of activation. When you're scrolling your phone
or watching videos, it's in low-activation mode. Gaming requires high-activation:

```
BRAIN ACTIVATION LEVELS:

  Scrolling TikTok:  ██░░░░░░░░  (Low — passive consumption)
  Walking around:    ████░░░░░░  (Medium — basic motor control)
  Playing ranked:    █████████░  (High — reaction, prediction, decisions)
  Clutch 1v3 round:  ██████████  (Peak — maximum cognitive load)
  
  GOING FROM "SCROLLING" TO "CLUTCH" WITHOUT WARMUP:
  Your brain isn't ready. It takes 10-15 minutes of targeted
  activation to shift from low to high mode.
  
  Warmup = gradually increasing brain activation before you need it.
```

### Your Muscle Memory Is Asleep

Muscle memory doesn't mean your muscles literally remember things. It means
your brain has optimized neural pathways for specific movements. But these
pathways need to be "activated" before they work at full speed.

```
MUSCLE MEMORY ACTIVATION:

  First attempt after waking up:
  Brain → "What was the crosshair placement angle again?" → slow, imprecise
  
  After 10 minutes of aim drills:
  Brain → [automatic pathway fires] → fast, precise, no conscious thought
  
  The neural pathway exists. Warmup "wakes it up."
```

---

## The Science (Simplified)

You don't need a biology degree. Here's what matters:

### 1. Motor Priming

When you practice a specific movement (like flicking to a target), your brain
strengthens the neural connection for that movement temporarily. This "priming"
lasts for 30-60 minutes.

```
PRIMING EXAMPLE:

  Aim drill: Flick to 50 targets in 3 minutes.
  Effect: Your flick speed and accuracy peak for the next 45 minutes.
  
  No warmup: Flick accuracy starts at 60%, slowly climbs to 85% over 20 min.
  With warmup: Flick accuracy STARTS at 82%, peaks at 90% within 5 min.
```

### 2. Thermoregulation

Your fingers and hands are at the END of your circulatory system. They're the
first to get cold and the last to warm up. Light exercise (hand stretches, 
rapid key presses) increases blood flow to your extremities.

```
FINGER TEMPERATURE AND DEXTERITY:

  Finger temp 20°C: Dexterity at 70% of maximum
  Finger temp 25°C: Dexterity at 85% of maximum  
  Finger temp 30°C: Dexterity at 95-100% of maximum
  
  HOW TO WARM HANDS FAST:
  1. Rubber band finger stretches (2 minutes)
  2. Rapid finger tapping on desk (1 minute)  
  3. Warm water (10 seconds, then dry)
  4. Hand warmers (keep one near your setup)
```

### 3. Cognitive Load Management

Your brain can handle a limited amount of simultaneous processing. In a game,
you're processing: minimap, crosshair, sound cues, teammate comms, ability
cooldowns, economy, positioning...

When you're cold, basic things (like crosshair placement) consume more 
cognitive load because the automatic pathways aren't activated yet. This
leaves less processing power for higher-level thinking.

```
COGNITIVE LOAD BUDGET:

  COLD (no warmup):
  ┌───────────────────────────────────┐
  │ Aim control:       ████░░░░ 40%   │  ← Using conscious effort to aim
  │ Movement:          ██░░░░░░ 20%   │  ← Thinking about movement
  │ Game sense:        ██░░░░░░ 20%   │  ← Very little left for strategy
  │ Communication:     █░░░░░░░ 10%   │  ← Barely calling things out
  │ Available:         █░░░░░░░ 10%   │  ← Almost nothing for clutch decisions
  └───────────────────────────────────┘

  WARMED UP:
  ┌───────────────────────────────────┐
  │ Aim control:       ██░░░░░░ 15%   │  ← Automatic, muscle memory handles it
  │ Movement:          █░░░░░░░ 10%   │  ← Automatic
  │ Game sense:        ████░░░░ 30%   │  ← Big focus on positioning/decisions
  │ Communication:     ██░░░░░░ 15%   │  ← Calling everything out
  │ Available:         ███░░░░░ 30%   │  ← Reserve for clutch moments
  └───────────────────────────────────┘
  
  WARMING UP FREES BRAINPOWER FOR GAME SENSE AND CLUTCH PLAYS.
```

---

## Mental vs Physical Warmup

Warmup has two components. Most people only think about the physical side.

### Physical Warmup

This is what most people think of: aim drills, deathmatch, practice range.

```
PHYSICAL WARMUP GOALS:
  ✓ Activate muscle memory pathways
  ✓ Increase blood flow to hands and fingers
  ✓ Calibrate mouse sensitivity (re-familiarize with your sens)
  ✓ Build rhythm (consistent timing on shots)
```

### Mental Warmup

This is what separates good players from great players.

```
MENTAL WARMUP GOALS:
  ✓ Focus your attention (stop thinking about school/work/drama)
  ✓ Set intentions ("I will focus on crosshair placement this session")
  ✓ Review key concepts ("What's the meta right now? What should I ban?")
  ✓ Positive framing ("I'm going to play my best, not stress about rank")

MENTAL WARMUP ROUTINE (3 minutes):
  1. Close all distractions (phone face-down, Discord DMs silent)
  2. Take 5 deep breaths (seriously — this reduces cortisol/stress)
  3. Set ONE focus point for the session:
     "I will hold better angles this session"
     "I will trade teammates' deaths this session"
     "I will play for info before fighting this session"
  4. Visualize a recent clutch play you made. Remember the feeling.
  
  NOW you're locked in mentally and physically.
```

---

## The Optimal Warmup Window

### How Long?

```
WARMUP DURATION EFFECTIVENESS:

  Minutes │ Performance Gain │ Worth It?
  ────────┼──────────────────┼───────────
  0       │ Baseline (cold)  │ No warmup → inconsistent games
  5       │ +15% avg         │ Better than nothing
  10      │ +25% avg         │ Good for casual sessions
  15      │ +30% avg         │ OPTIMAL for most players
  20      │ +32% avg         │ Slightly better, not worth the extra time
  30      │ +30% avg         │ Diminishing returns, starting to fatigue
  45+     │ +25% avg         │ You're LOSING performance from fatigue
  
  THE SWEET SPOT: 15 minutes.
  
  If you're short on time: 5 minutes of hand stretches + 5 minutes of aim drills.
  If you have extra time: 15 min warmup + 5 min mental warmup.
```

### When to Warmup

```
TIMING:
  ✓ Immediately before playing ranked/competitive
  ✓ After a long break (2+ hours away from the game)
  ✓ When switching between games (Valorant → Apex = different muscle memory)
  
  ✗ DON'T warmup hours before playing (the effects fade in 30-60 min)
  ✗ DON'T warmup between every single match (that's just fatigue)
  ✗ DON'T warmup for casual/unranked (use those AS warmup if needed)
```

---

## Common Warmup Myths

### Myth 1: "Playing deathmatch IS my warmup"

```
HALF TRUE.

Deathmatch warms up your AIM, but:
  - Doesn't stretch your hands (injury risk stays high)
  - Can teach bad habits (wide swinging, no crosshair placement)
  - Often frustrating (tilts you before ranked even starts)
  
BETTER: Structured aim drills + 5 min deathmatch as a finisher.
```

### Myth 2: "I don't need warmup, I play every day"

```
FALSE.

Even professional athletes warmup before EVERY practice and game.
Playing daily helps your overall skill, but each session still starts cold.
Your muscle memory decays to ~80% of peak after just 6-8 hours of not playing.

If you played yesterday: 80% of peak → warmup brings it to 95-100%
If you haven't played in days: 60% of peak → warmup brings it to 85-90%
```

### Myth 3: "Warming up for 2 hours makes me play amazing"

```
FALSE. 

After ~20 minutes, you're not warming up anymore.
You're PRACTICING, which is different.

Practice = building new skill (good, but tiring)
Warmup = activating existing skill (quick, energizing)

A 2-hour Aim Lab session before ranked means:
  - Fatigued hands
  - Reduced focus
  - "Burned out" feeling before the real games start
```

### Myth 4: "Hand stretches are for old people"

```
DANGEROUSLY FALSE.

Average age of carpal tunnel diagnosis in gamers: 19-25 years old.
Average gaming hours before first RSI symptoms: 2,000-3,000 hours.
If you game 4 hours daily, that's less than 2 years.

RSI (Repetitive Strain Injury) is:
  - Preventable with 2-3 minutes of daily stretches
  - NOT curable once it gets severe
  - Career-ending for pro gamers

Do your hand stretches. Every single session. No exceptions.
```

---

## Building Your Personal Routine

### The Template

```
YOUR PERSONALIZED WARMUP ROUTINE:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Step 1: Hand Stretches          ___  minutes  (minimum 2)
Step 2: ________________ drill  ___  minutes  (aim trainer or in-game)
Step 3: ________________ drill  ___  minutes  (choose your weakness)  
Step 4: In-game practice        ___  minutes  (deathmatch, practice range)
Step 5: Mental focus            ___  minutes  (deep breaths, set intention)

Total:                          ___  minutes  (target: 15)
```

### Customization by Game Type

```
FPS PLAYERS (Valorant, Apex, CS2):
  Focus on: Flick accuracy, crosshair placement, movement
  Heavy on: Aim trainer time (60% of warmup)
  See: fps_warmup.md for the full routine

MOBA PLAYERS (League, Dota 2):
  Focus on: Camera control, ability combos, last-hitting
  Heavy on: Practice tool time (60% of warmup)  
  See: moba_warmup.md for the full routine

BATTLE ROYALE PLAYERS (Fortnite, PUBG):
  Focus on: Building/editing speed, looting efficiency, aim
  Heavy on: Creative mode or training ground (50% of warmup)
  Combine: fps_warmup.md for aim + game-specific creative routines

FIGHTING GAME PLAYERS (Street Fighter, Tekken):
  Focus on: Combo execution, spacing, anti-airs
  Heavy on: Training mode (70% of warmup)
  Do: 10 reps of your bread-and-butter combo per character
```

---

*Next: Pick your game type and dive into the specific routines.*
