# Aim Drills — Targeted Exercises for Every Aim Type

## Table of Contents
1. [The 4 Types of Aim](#the-4-types-of-aim)
2. [Tracking Drills](#tracking-drills)
3. [Flicking Drills](#flicking-drills)
4. [Click-Timing Drills](#click-timing-drills)
5. [Switching Drills](#switching-drills)
6. [Building a Drill Playlist](#building-a-drill-playlist)
7. [Benchmarks and Progress](#benchmarks-and-progress)

---

## The 4 Types of Aim

Not all aim is the same. Different games demand different aim types.

```
AIM TYPE        WHAT IT IS                        GAMES THAT NEED IT MOST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Tracking        Following a moving target          Apex, Overwatch, Fortnite
Flicking        Snapping to a target instantly      Valorant, CS2, Osu!
Click-Timing    Clicking at the exact right moment  CS2 (AWP), Valorant (Op)
Target Switch   Moving between multiple targets     All FPS (multi-enemy fights)

MOST PLAYERS: Only practice flicking (because Gridshot is fun).
ACTUAL IMPROVEMENT: Requires all 4 types in balance.
```

### What to Focus On By Game

```
YOUR MAIN GAME     → PRIMARY AIM TYPE → SECONDARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Valorant            → Flicking          → Click-Timing
CS2                 → Flicking          → Click-Timing
Apex Legends        → Tracking          → Target Switch
Overwatch           → Tracking          → Target Switch
Fortnite            → Tracking          → Flicking
Call of Duty        → Flicking          → Tracking
Rainbow Six Siege   → Click-Timing      → Flicking
```

---

## Tracking Drills

Tracking = keeping your crosshair on a moving target for sustained damage.
Critical for: Apex, Overwatch, Fortnite (SMG/AR spraying).

### Aim Lab Scenarios

```
BEGINNER TRACKING:
──────────────────
  Scenario: "Circletrack"
  Duration: 60 seconds
  Target: 1 orb moving in a circle
  Focus:  Keep crosshair dead-center on the orb
  
  TIPS:
  - Use your ARM for large movements, WRIST for small corrections
  - Don't predict where the target will go — react and follow
  - Smooth mouse movement, not jerky corrections

INTERMEDIATE TRACKING:
─────────────────────
  Scenario: "Strafetrack"
  Duration: 60 seconds
  Target: 1 bot strafing left-right at random intervals
  Focus:  Track the bot's head through direction changes
  
  TIPS:
  - Watch for the direction change "tell" (bot slows before switching)
  - Keep your crosshair slightly ahead of the target's movement
  - Maintain steady mouse speed

ADVANCED TRACKING:
─────────────────
  Scenario: "Multitrack" or "Evadetrack"
  Duration: 60 seconds
  Target: Fast-moving, erratic target with direction changes
  Focus:  Maximum accuracy % on a target that doesn't want to be tracked
  
  TIPS:
  - React, don't predict. Prediction only works on predictable patterns.
  - Accept 70-80% accuracy. Even pros don't hit 100% on erratic tracking.
  - Focus on RECOVERY SPEED — how fast you get back on target after losing it.
```

### Kovaak's Scenarios

```
BEGINNER:    "Smooth Your Aim - Invincible"
INTERMEDIATE: "PGTI Voltaic Easy"
ADVANCED:    "Air Angelic 4 Voltaic"
EXPERT:      "PGTI Voltaic Hard" or "Tamspeed 2bpes"
```

### No Aim Trainer Alternative

```
ANY FPS GAME — THE TRACKING DRILL:

  1. Enter a practice mode with bots/dummies
  2. Find a moving target (moving bot, strafing enemy)
  3. Place your crosshair on the target's head
  4. DO NOT SHOOT. Just track them for 30 seconds.
  5. After 30 seconds of pure tracking, start shooting.
  
  The "don't shoot" phase forces your brain to focus on
  tracking QUALITY instead of trying to get kills.
  
  Do 3 rounds of 30 seconds tracking + 30 seconds shooting.
```

---

## Flicking Drills

Flicking = snapping your crosshair from one point to another as fast as possible.
Critical for: Valorant, CS2, click-timing games.

### Aim Lab Scenarios

```
BEGINNER FLICKING:
─────────────────
  Scenario: "Gridshot" (the classic)
  Duration: 60 seconds
  Target: 3 large orbs appearing on a grid
  Focus:  Snap to center of each orb, click, snap to next
  
  TIPS:
  - Don't just spam clicks. Each click should be AIMED.
  - Move to the target, THEN click (not click while moving)
  - Start slow and build speed over days, not minutes

INTERMEDIATE FLICKING:
─────────────────────
  Scenario: "Spidershot" or "Sixshot"
  Duration: 60 seconds
  Target: Smaller orbs appearing at wider angles
  Focus:  Accuracy on longer flick distances
  
  TIPS:
  - For wide flicks, use your ARM. For small corrections, use your WRIST.
  - Don't overshoot (flicking past the target). If you do, lower your sens.
  - If you undershoot consistently, raise your sens slightly.

ADVANCED FLICKING:
─────────────────
  Scenario: "Microshot Speed" or "Detection"
  Duration: 60 seconds
  Target: Very small targets appearing briefly
  Focus:  Reaction time + precision on tiny targets (headshot practice)
  
  TIPS:
  - At this level, speed AND accuracy must coexist
  - If accuracy drops below 60%, slow down
  - Track your average reaction time — it should decrease over weeks
```

### Kovaak's Scenarios

```
BEGINNER:    "1wall6targets TE"
INTERMEDIATE: "Pasu Voltaic Easy"
ADVANCED:    "Popcorn Voltaic"
EXPERT:      "Pasu Voltaic Hard" or "Ww3t Voltaic"
```

---

## Click-Timing Drills

Click-timing = clicking at the precise moment for a one-shot kill.
Critical for: AWP in CS2, Operator in Valorant, snipers in any game.

```
WHAT MAKES CLICK-TIMING DIFFERENT:

  Flicking:      Move mouse TO target → click immediately
  Click-Timing:  Hold crosshair on an angle → enemy appears → click
  
  It's about WHEN you click, not WHERE you move.
  
  The challenge: clicking too early (whiffing) vs too late (you're dead).
```

### Aim Lab Scenarios

```
BASIC CLICK-TIMING:
──────────────────
  Scenario: "Detection"
  Duration: 60 seconds  
  Targets: Small targets appear for a brief window
  Focus:  Click before they disappear, but don't misclick
  
  TIPS:
  - Pre-position your crosshair in the center of the spawn area
  - React to the target, don't anticipate it
  - One click per target — no spam clicking

ADVANCED CLICK-TIMING:
─────────────────────
  Scenario: "Headshot" or any scenario with peek-like target appearance
  Duration: 60 seconds
  Targets: Targets appear and disappear quickly (simulating peeks)
  Focus:  Window is <500ms. You need to identify + click in that time.
  
  REAL-WORLD APPLICATION:
  An enemy peeks you in Valorant/CS2. They're visible for ~300ms.
  You need to click their head in that window. This drill trains that.
```

### In-Game Click-Timing Practice

```
CS2 / VALORANT AWP/OP DRILL:

  1. Custom game, place yourself at a common AWP angle
  2. Have a bot walk across the angle (or peek from behind cover)
  3. Hold your crosshair on the angle
  4. Click the moment the bot's body crosses your crosshair
  
  Do 30 reps. Track hits vs misses.
  
  COMMON MISTAKES:
  - Moving your crosshair TO the target (this is flicking, not timing)
  - Clicking after the target is already past your crosshair (too slow)
  - Spam-clicking when you see movement (discipline — one shot)
```

---

## Switching Drills

Target switching = moving between multiple targets in sequence.
Critical for: multi-enemy fights, spray transfers, ability targeting.

### Aim Lab Scenarios

```
BASIC TARGET SWITCH:
───────────────────
  Scenario: "Gridshot" with focus on SWITCHING speed between orbs
  Duration: 60 seconds
  Focus:  The TRANSITION between targets, not individual clicks
  
  MENTAL MODEL:
  Click target 1 → brain already knows where target 2 is → 
  mouse is moving to target 2 BEFORE you finish clicking target 1
  
  This "look ahead" is what makes target switching feel fluid.

ADVANCED TARGET SWITCH:
──────────────────────
  Scenario: "Multishot" or "Switch Track"
  Duration: 60 seconds
  Focus:  Switch between 2 moving targets
  
  Track target A for 2 seconds → switch to target B → track for 2 seconds → switch back
  
  This simulates Apex/OW fights where you need to swap targets mid-spray.
```

### Kovaak's Scenarios

```
BEGINNER:    "Bounce 180 Voltaic Easy"
INTERMEDIATE: "Bounce 180 Voltaic Medium"
ADVANCED:    "Target Switch Voltaic"
```

---

## Building a Drill Playlist

### The 10-Minute Aim Warmup Playlist

```
BALANCED PLAYLIST (all aim types):

  Round 1: Tracking (90 seconds)
  ────────────────────────────
  Aim Lab: Circletrack or Strafetrack
  
  Round 2: Flicking (90 seconds)
  ───────────────────────────
  Aim Lab: Gridshot or Spidershot
  
  Round 3: Click-Timing (90 seconds)
  ──────────────────────────────
  Aim Lab: Detection
  
  Round 4: Target Switch (90 seconds)
  ──────────────────────────────────
  Aim Lab: Multishot or Sixshot (focus on transitions)
  
  Round 5: Your Weakness (90 seconds)
  ──────────────────────────────────
  Repeat whichever round you performed worst on.
  
  Round 6: Freestyle (90 seconds)
  ──────────────────────────────
  Your favorite scenario at maximum effort. End on a high note.
  
  TOTAL: ~10 minutes (with transitions between scenarios)
```

### Game-Specific Playlists

```
VALORANT/CS2 PLAYLIST (Precision Focus):
  1. Spidershot (60s) — flick precision
  2. Microshot Speed (60s) — small target headshots
  3. Detection (60s) — click-timing / peek reactions
  4. Sixshot (60s) — target switching
  5. Gridshot (60s) — confidence builder / fun finish

APEX/OVERWATCH PLAYLIST (Tracking Focus):
  1. Circletrack (60s) — smooth tracking warmup
  2. Strafetrack (60s) — reactive tracking
  3. Gridshot (60s) — flick coordination
  4. Multishot (60s) — multi-target tracking
  5. Evadetrack (60s) — hard tracking challenge
```

---

## Benchmarks and Progress

### Voltaic Benchmarks (Community Standard)

The Voltaic community maintains standardized benchmarks for aim trainer scores.
Here's a simplified version:

```
RANK SYSTEM:
  Iron      → You're just starting. Focus on form, not scores.
  Bronze    → You understand the basics. Time to build consistency.
  Silver    → You're better than most casual players.
  Gold      → Solid aim. Competitive in ranked games.
  Platinum  → Top 10% of aim trainer players.
  Diamond   → Your aim is rarely the reason you lose.
  Master+   → You could go pro (mechanically, at least).

APPROXIMATE SCORES (Aim Lab Gridshot as reference):
  Iron:     < 50,000
  Bronze:   50,000 - 70,000
  Silver:   70,000 - 85,000
  Gold:     85,000 - 95,000
  Platinum: 95,000 - 105,000
  Diamond:  105,000+
  
NOTE: Gridshot scores are NOT a good measure of in-game aim.
They're a fun benchmark but don't correlate directly to
game performance. Use them to track YOUR progress over time.
```

### Weekly Progress Tracker

```
WEEK OF: ___________

  TRACKING (best score):
    Monday:    _______
    Wednesday: _______
    Friday:    _______
    Change:    _______ (improving? plateauing?)
  
  FLICKING (best score):
    Monday:    _______
    Wednesday: _______
    Friday:    _______
    Change:    _______
  
  CLICK-TIMING (best score):
    Monday:    _______
    Wednesday: _______
    Friday:    _______
    Change:    _______
  
  NOTES: _________________________________
         _________________________________
```

### When You Hit a Plateau

```
STUCK AT THE SAME SCORE FOR 2+ WEEKS?

  Option 1: Lower the difficulty
  ──────────────────────────────
  Go back to the easier version of the drill.
  Sometimes you advanced too fast and need to
  solidify fundamentals before progressing.
  
  Option 2: Change the drill
  ──────────────────────────
  Your brain has "optimized" for this specific scenario.
  Switch to a different drill that targets the same aim type.
  The novel stimulus forces new adaptation.
  
  Option 3: Adjust your sensitivity
  ─────────────────────────────────
  If you consistently overshoot, lower your sens by 5%.
  If you consistently undershoot, raise it by 5%.
  Give the new sens 3 days before judging.
  
  Option 4: Take a break
  ──────────────────────
  2-3 days of NO aim training, just playing games.
  Sometimes your brain needs rest to consolidate gains.
  You might come back and beat your PB immediately.
```

---

*Drills locked and loaded. Combine these with your game-specific warmup for maximum results.*
