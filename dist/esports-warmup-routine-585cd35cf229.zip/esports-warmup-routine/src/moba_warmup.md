# MOBA Warmup Routine — 15 Minutes to Sharper Gameplay

## Table of Contents
1. [Why MOBAs Need Different Warmups](#why-mobas-need-different-warmups)
2. [The Full 15-Minute Routine](#the-full-15-minute-routine)
3. [Phase 1: Hand Prep (0:00-3:00)](#phase-1-hand-prep-000-300)
4. [Phase 2: APM Activation (3:00-6:00)](#phase-2-apm-activation-300-600)
5. [Phase 3: Last-Hit Practice (6:00-9:00)](#phase-3-last-hit-practice-600-900)
6. [Phase 4: Combo Execution (9:00-12:00)](#phase-4-combo-execution-900-1200)
7. [Phase 5: Mental Prep (12:00-15:00)](#phase-5-mental-prep-1200-1500)
8. [Game-Specific Variations](#game-specific-variations)

---

## Why MOBAs Need Different Warmups

FPS warmup is about aim. MOBA warmup is about **decisions per minute.**

In a MOBA, you're not flicking to targets. You're:
- Last-hitting minions with precise click timing
- Executing ability combos in the right order
- Managing camera position while tracking multiple things
- Making split-second fight-or-flight decisions

```
FPS WARMUP FOCUS:          MOBA WARMUP FOCUS:
├── Mouse precision         ├── Click accuracy (smaller targets)
├── Reaction time           ├── APM (actions per minute)
├── Crosshair placement     ├── Camera control
└── Weapon handling         ├── Combo muscle memory
                            └── Map awareness activation
```

### The MOBA "Cold Start" Problem

```
Game 1 (no warmup):
  - Miss 3 CS per wave because click timing is off
  - Fat-finger ability combo (wrong key order)
  - Forget to check minimap for first 5 minutes
  - Get ganked because camera was locked to lane
  
  3 CS/wave × 10 waves in laning phase = 30 CS behind
  30 CS = ~600 gold = one component item your opponent has and you don't
  
  YOU LOST LANE BEFORE IT STARTED.

Game 1 (with warmup):
  - Last-hitting feels crisp from minute 1
  - Combo execution is automatic
  - Minimap checks happen naturally
  - Camera control is fluid
  
  SAME SKILL LEVEL. Different preparation. Different outcome.
```

---

## The Full 15-Minute Routine

```
TIME        ACTIVITY                     WHAT IT WARMS UP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
0:00-3:00   Hand stretches + finger taps  Blood flow, click precision
3:00-6:00   APM activation drill          Keyboard speed, key recognition
6:00-9:00   Last-hit practice             CS timing, minion health reading
9:00-12:00  Combo execution               Ability order, cooldown awareness
12:00-15:00 Mental prep + map review      Game plan, matchup reminders

READY TO QUEUE RANKED.
```

---

## Phase 1: Hand Prep (0:00-3:00)

Same hand stretches as FPS (see hand_stretches.md for full guide).
MOBA-specific additions:

```
MOBA-SPECIFIC HAND PREP:

  Standard stretches from hand_stretches.md (2 minutes)
  
  PLUS:
  
  DRILL: Rapid Key Tap (30 seconds)
  ──────────────────────────────────
  Place your left hand on QWER (League) or QWER (Dota on QWER layout).
  Rapidly tap each key in sequence: Q-W-E-R-Q-W-E-R-Q-W-E-R
  Do this for 15 seconds as fast as possible.
  Then reverse: R-E-W-Q-R-E-W-Q for 15 seconds.
  
  This activates the specific finger movements you'll use all game.
  
  DRILL: Click Precision Warmup (30 seconds)
  ───────────────────────────────────────────
  Open any window on your desktop.
  Click the close button (X) in the corner. 
  Open another window. Click its close button.
  Repeat as fast as possible for 30 seconds.
  
  Why? The close button is tiny — similar to clicking a minion's 
  health bar right as it enters last-hit range. Precision clicking.
```

---

## Phase 2: APM Activation (3:00-6:00)

APM (Actions Per Minute) is how fast you execute inputs. Top MOBA players
average 200-400 APM in team fights. Your cold APM is probably 50-100.

### The Keyboard Speed Drill

```
DRILL: Pattern Typing (3 minutes)

  Open Notepad, a text editor, or even the in-game chat.
  
  MINUTE 1: ABILITY KEYS
  Type this pattern as fast as possible (don't worry about typos):
  QWERQWERQWERQWERQWERQWERQWER
  
  Then with numbers mixed in:
  Q1W2E3R4Q1W2E3R4Q1W2E3R4
  
  This simulates ability usage with item actives.
  
  MINUTE 2: CAMERA + ABILITIES
  While typing ability patterns with your left hand,
  move your mouse around the screen in a figure-8 with your right hand.
  
  This activates BOTH hands simultaneously — the core MOBA skill.
  
  MINUTE 3: RAPID CLICK + KEYS
  Click your mouse rapidly while alternating QWER presses.
  This simulates attack-moving while casting abilities.
  
  TARGET APM (rough guideline):
  Casual player:  80-120 APM
  Ranked player:  150-250 APM
  High elo:       250-400 APM
  Pro player:     300-500 APM
  
  Don't stress about your number. The goal is to ACTIVATE fast input,
  not achieve a specific APM count.
```

---

## Phase 3: Last-Hit Practice (6:00-9:00)

Last-hitting (CS-ing) is the single most important mechanical skill in MOBAs.
Missing CS = missing gold = losing lane = losing game.

### League of Legends

```
PRACTICE TOOL DRILL (3 minutes):

  1. Open Practice Tool
  2. Pick your main champion
  3. Start at Level 1, buy a Doran's item
  4. Go to lane, DO NOT level up any abilities
  5. Last-hit using ONLY auto attacks for 3 minutes
  
  RULES:
  ✗ No abilities for last-hitting
  ✗ No attack-move (right-click on minions directly)
  ✗ Don't push the wave (only hit minions at kill threshold)
  
  SCORING:
  Perfect CS at 3 minutes ≈ 38 CS
  Target: 32+ CS (85%+ accuracy)
  
  TRACK YOUR SCORE EACH SESSION:
  Day 1:  __ / 38
  Day 2:  __ / 38
  Day 3:  __ / 38
  ...
  
  If you consistently hit 34+, add abilities:
  Use ONE ability per wave to last-hit, auto-attack the rest.
  This simulates real laning where you mix autos and abilities.
```

### Dota 2

```
DEMO MODE DRILL (3 minutes):

  1. Open Demo Hero
  2. Pick your main hero
  3. Spawn enemy creeps (console: -createhero npc_dota_hero_axe enemy)
  4. Last-hit for 3 minutes with auto attacks only
  
  DOTA-SPECIFIC FOCUS:
  - Different attack animations per hero (some are SLOW)
  - Turn rate matters (face the creep before attacking)
  - Deny your own creeps too (attack allies below 50% HP)
  
  SCORING (Dota 2):
  Perfect CS + denies at 3 minutes ≈ 30 CS + 15 denies
  Target: 24+ CS, 10+ denies
  
  TIPS:
  - Watch the enemy creep's projectile hitting your creep
  - Time your attack to land AFTER their projectile
  - The damage numbers that pop up help you estimate kill threshold
```

---

## Phase 4: Combo Execution (9:00-12:00)

Every champion/hero has key ability combos that need to be automatic.
If you have to THINK about the key order mid-fight, you're too slow.

### League of Legends Combo Drills

```
DRILL: Your Main's Bread-and-Butter Combo (3 minutes)

  In Practice Tool, spawn a Target Dummy (press the dummy icon).
  
  STEP 1 (1 minute): Execute your main combo 10 times.
  
  EXAMPLES:
  ┌──────────────┬──────────────────────────────────────┐
  │ Champion      │ Bread-and-Butter Combo               │
  ├──────────────┼──────────────────────────────────────┤
  │ Yasuo         │ E → Q (tornado) → R → Auto → Q       │
  │ Lux           │ Q → E → Auto → R → E2                │
  │ Zed           │ W → E → Q → R → Auto → E             │
  │ Ahri          │ E → W → Q → R forward → Auto         │
  │ Thresh        │ Q → Q2 → E (flay back) → R           │
  │ Lee Sin       │ Q → Q2 → Auto → E → Auto → R         │
  │ Riven         │ Q → Auto → Q → Auto → Q → Auto → W   │
  │ Katarina      │ E → W → Q → E (to dagger) → R        │
  └──────────────┴──────────────────────────────────────┘
  
  Don't have a main? Pick the 2 champs you play most.
  
  STEP 2 (1 minute): Flash combos.
  Practice the same combo but with Flash included:
  Flash → Combo  OR  Combo → Flash (for extending range)
  
  STEP 3 (1 minute): Speed run.
  Execute the combo as FAST as possible 10 times.
  You should hear the abilities overlap (animation canceling).
  
  THE GOAL: Zero hesitation. Your fingers should execute the combo
  without your brain consciously choosing each key.
```

### Dota 2 Combo Drills

```
DRILL: Item + Ability Combos (3 minutes)

  In Demo Mode, give yourself core items and max level.
  
  EXAMPLES:
  ┌──────────────┬──────────────────────────────────────────┐
  │ Hero          │ Common Full Combo                        │
  ├──────────────┼──────────────────────────────────────────┤
  │ Invoker       │ Cold Snap → Forge Spirits → Alacrity     │
  │ Tinker        │ Blink → Laser → Rocket → Rearm → repeat  │
  │ Earth Spirit  │ Roll → Kick → Pull → Magnetize           │
  │ Storm Spirit  │ Ball → Pull → Overload → Orchid → Hex     │
  │ Puck          │ Orb → Jaunt → Silence → Rift → Phase     │
  │ Sand King     │ Blink → Epicenter → Burrowstrike          │
  └──────────────┴──────────────────────────────────────────┘
  
  Execute each combo 10 times. Focus on key ORDER and SPEED.
  
  DOTA-SPECIFIC: Include item actives (BKB, Blink, Eul's) in the combo.
  These are often forgotten in fights because they're on less-used keys.
```

---

## Phase 5: Mental Prep (12:00-15:00)

The final 3 minutes are pure mental preparation. This is what separates
players who "just play" from players who "play to win."

### Matchup Review (1 minute)

```
BEFORE YOU QUEUE, ANSWER THESE QUESTIONS:

  1. What champion/hero am I playing?  _______________
  2. What's my win condition?           _______________
     (e.g., "Scale to 25 min," "Snowball early kills," "Team fight")
  3. What matchups am I scared of?     _______________
     (e.g., "I lose to Zed in lane. Play safe pre-6.")
  4. What's my first item buy path?    _______________
     (Don't think about this during the game — decide NOW.)
```

### Map Awareness Activation (1 minute)

```
THE MINIMAP TIMER:

  Set a repeating timer on your phone for every 5 seconds.
  For 60 seconds, every time the timer beeps, 
  look at your minimap (or imagine checking it).
  
  This programs your brain to check the minimap frequently.
  In-game, you won't have the timer, but the HABIT will carry over.
  
  TARGET MINIMAP CHECK FREQUENCY:
  Bronze/Silver: Every 15-20 seconds (work toward this)
  Gold/Plat:     Every 8-12 seconds
  Diamond+:      Every 3-5 seconds (basically constant awareness)
```

### Intention Setting (1 minute)

```
PICK ONE FOCUS POINT FOR THIS SESSION:

  □ "I will track enemy jungle position on minimap"
  □ "I will not die to ganks (play safe when I don't see jungler)"
  □ "I will hit 8+ CS per minute"
  □ "I will land my key ability combo in every team fight"
  □ "I will communicate objective timers to my team"
  □ "I will take a 10-second mental break after every death"
  
  PICK ONE. Not two. Not three. ONE.
  
  Trying to improve everything at once = improving nothing.
  One focus point per session. Rotate through them over a week.
```

---

## Game-Specific Variations

### League of Legends Full Warmup

```
0:00-3:00   Hand stretches + QWER rapid tapping
3:00-6:00   Practice Tool: Last-hit 3 waves with auto attacks only
6:00-9:00   Practice Tool: Execute your main's full combo 20 times
9:00-12:00  Practice Tool: Flash combo 10 times + animation cancel practice
12:00-15:00 Review matchup + set minimap check intention + queue up
```

### Dota 2 Full Warmup

```
0:00-3:00   Hand stretches + key pattern drill (include item hotkeys)
3:00-6:00   Demo Mode: Last-hit + deny practice (3 waves)
6:00-9:00   Demo Mode: Full combo with items 15 times
9:00-12:00  Demo Mode: Practice hero-specific micro (illusions, summons)
12:00-15:00 Review today's meta picks + set focus point + queue up
```

### Teamfight Tactics / Auto-Battlers

```
0:00-3:00   Hand stretches (less intensive, APM is lower)
3:00-6:00   Review current meta: tier lists, top comps, item priorities
6:00-9:00   Mental drill: Name the best items for 5 different carries
9:00-12:00  Review your last 3 games: where did you lose? Why?
12:00-15:00 Set focus point: "I will scout at least 3 times per stage"
```

---

*Hands warmed, combos loaded, game plan locked. Time to climb.*
