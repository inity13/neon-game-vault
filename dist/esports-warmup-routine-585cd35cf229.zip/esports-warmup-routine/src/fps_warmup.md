# FPS Warmup Routine — 15 Minutes to Peak Performance

## Table of Contents
1. [The Full 15-Minute Routine](#the-full-15-minute-routine)
2. [Phase 1: Hand Prep (0:00-3:00)](#phase-1-hand-prep-000-300)
3. [Phase 2: Tracking Drills (3:00-6:00)](#phase-2-tracking-drills-300-600)
4. [Phase 3: Flick Drills (6:00-9:00)](#phase-3-flick-drills-600-900)
5. [Phase 4: In-Game Practice (9:00-12:00)](#phase-4-in-game-practice-900-1200)
6. [Phase 5: Crosshair Discipline (12:00-15:00)](#phase-5-crosshair-discipline-1200-1500)
7. [Game-Specific Variations](#game-specific-variations)
8. [Quick 5-Minute Emergency Warmup](#quick-5-minute-emergency-warmup)

---

## The Full 15-Minute Routine

```
TIME        ACTIVITY                     WHAT IT WARMS UP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
0:00-3:00   Hand stretches + finger taps  Blood flow, joint flexibility
3:00-6:00   Tracking drills (aim trainer) Smooth mouse control, wrist movement
6:00-9:00   Flick drills (aim trainer)    Snap targeting, reaction time
9:00-12:00  Deathmatch / practice range   Game-specific feel, weapon handling
12:00-15:00 Crosshair placement drill     Angle holding, pre-aim discipline

READY TO QUEUE RANKED.
```

---

## Phase 1: Hand Prep (0:00-3:00)

This isn't optional. Your hands need blood flow before precision work.

### Quick Stretch Sequence (See hand_stretches.md for full guide)

```
STRETCH 1: Prayer Stretch (30 seconds)
──────────────────────────────────────
  Press palms together in front of chest.
  Lower hands toward belly while keeping palms pressed.
  Feel the stretch in your wrists and forearms.
  Hold for 15 seconds. Release. Repeat.

STRETCH 2: Reverse Prayer (30 seconds)
──────────────────────────────────────
  Press the BACKS of your hands together.
  Raise hands toward chin while keeping them pressed.
  Hold for 15 seconds. Release. Repeat.

STRETCH 3: Finger Extensions (30 seconds)
────────────────────────────────────────
  Spread all fingers as wide as possible.
  Hold for 5 seconds. Make a fist. Hold for 5 seconds.
  Repeat 3 times.

STRETCH 4: Wrist Circles (30 seconds)
─────────────────────────────────────
  Extend arms forward. Circle wrists slowly.
  10 circles clockwise. 10 circles counterclockwise.

STRETCH 5: Finger Taps (30 seconds)
───────────────────────────────────
  Tap each finger to your thumb rapidly.
  Index-middle-ring-pinky-ring-middle-index.
  Do this as fast as possible for 30 seconds.
  This activates fine motor control pathways.

STRETCH 6: Shake It Out (30 seconds)
────────────────────────────────────
  Shake hands loosely for 15 seconds.
  Then grip your mouse and move it in small circles for 15 seconds.
  First contact with the mouse should feel warm and loose.
```

---

## Phase 2: Tracking Drills (3:00-6:00)

Tracking = following a moving target smoothly with your crosshair.
This warms up your wrist for sustained mouse control.

### If You Have Aim Lab / Kovaak's

```
DRILL: Smooth Tracking (3 minutes)

  AIM LAB: "Circletrack" or "Strafetrack" scenario
  KOVAAK'S: "Smooth Your Aim" or "PGTI Voltaic Easy"
  
  SETTINGS:
  - Target speed: Medium (start slow, it's a warmup)
  - Target size: Large (this isn't training, it's activation)
  - Duration: 60 seconds per round, 3 rounds
  
  FOCUS ON:
  ✓ Smooth, fluid mouse movement (no jerky corrections)
  ✓ Keeping crosshair CENTERED on the target (not chasing it)
  ✓ Using your wrist AND arm (don't just wrist-aim the whole time)
  
  DON'T WORRY ABOUT:
  ✗ Your score (this is warmup, not training)
  ✗ Speed (start at 70% effort, ramp up naturally)
  ✗ Perfect accuracy (80%+ tracking is fine for warmup)
```

### No Aim Trainer? In-Game Alternatives

```
VALORANT:
  Go to Practice Range → turn on moving bots (Medium armor, Strafe).
  Track their heads with your crosshair without shooting.
  Follow them smoothly for 30 seconds each. Do 6 bots.

APEX LEGENDS:
  Firing Range → turn on the moving dummies (secret Easter egg).
  Track their movement with your crosshair while strafing yourself.
  3 minutes of tracking without shooting, just following.

CS2:
  Workshop map: "Aim Botz" → set bots to move.
  Track moving bots with crosshair. Shoot only after 
  your crosshair has been on their head for 1 full second.
  This forces smooth tracking instead of flicking.
```

---

## Phase 3: Flick Drills (6:00-9:00)

Flicking = snapping your crosshair to a stationary target.
This warms up fast-twitch muscle fibers for reaction shots.

### If You Have Aim Lab / Kovaak's

```
DRILL: Flick Shots (3 minutes)

  AIM LAB: "Gridshot" (classic) or "Spidershot"  
  KOVAAK'S: "1wall6targets TE" or "Pasu Voltaic Easy"
  
  SETTINGS:
  - Target size: Large for minute 1, Medium for minute 2, Small for minute 3
  - Target count: 3-6 targets visible at a time
  
  ROUND 1 (60 sec): Large targets, moderate speed
  ─────────────────────────────────────────────────
  Don't rush. Focus on ACCURACY over speed.
  Every shot should be a clean snap to the center.
  Target: 85%+ accuracy.
  
  ROUND 2 (60 sec): Medium targets, faster pace
  ──────────────────────────────────────────────
  Increase speed slightly. Accept 75-80% accuracy.
  Focus on the snap motion being crisp.
  
  ROUND 3 (60 sec): Small targets, max controlled speed
  ────────────────────────────────────────────────────
  Full speed. This simulates headshots in a real game.
  Target: 65-70% accuracy at high speed.
  
  IF YOU'RE HITTING <50% ACCURACY: You're going too fast.
  Slow down. Speed without accuracy is worthless in a real game.
```

### No Aim Trainer? In-Game Alternatives

```
VALORANT:
  Practice Range → set bots to appear one at a time (Armor: None, Mode: Practice).
  Flick to each bot's head and one-tap them with a Vandal or Sheriff.
  60 seconds per round, 3 rounds. Count your headshot percentage.

APEX LEGENDS:
  Firing Range → stand ~30 meters from the stationary targets.
  Use a Wingman. Flick between targets, aiming for the head.
  3 minutes. Focus on clean snaps, not spray.

CS2:
  Aim Botz workshop map → set to stationary.
  100 kills with AK-47, headshots only. Time yourself.
  Your time should improve after warmup vs first attempt.
```

---

## Phase 4: In-Game Practice (9:00-12:00)

Now bring the warmed-up aim into the actual game engine. The "feel" of your
game is different from aim trainers (movement speed, weapon handling, audio cues).

### Valorant

```
DEATHMATCH (3 minutes):

  RULES FOR YOURSELF:
  1. Sheriff or Vandal ONLY (no spray weapons)
  2. Walk, don't run (practice crosshair discipline)
  3. Pre-aim every corner before peeking
  4. Go for headshots only (ignore your K/D)
  
  THIS ISN'T ABOUT WINNING THE DM.
  It's about activating in-game muscle memory.
  
  If DM queue is long: Use the Practice Range with hard bots.
```

### Apex Legends

```
FIRING RANGE (3 minutes):

  1. Pick up an R-301 and a Wingman
  2. R-301 spray control (1 minute):
     - Stand at 30m from targets
     - One-clip each target (no stopping mid-spray)
     - Focus on pulling down smoothly to control recoil
  3. Wingman flicks (1 minute):
     - Flick between targets rapidly
     - Headshots only
  4. Movement + shooting (1 minute):
     - Slide-jump toward targets while shooting
     - Practice hipfire accuracy while moving
```

### CS2

```
DEATHMATCH (3 minutes):

  1. AK-47 only
  2. Tap/burst fire — no spraying allowed
  3. Focus on counter-strafing (stop moving before shooting)
  4. Pre-aim common headshot angles
  
  ALTERNATIVE: Community FFA servers (faster respawns).
  
  FOCUS: The counter-strafe timing. This is unique to CS2 
  and doesn't exist in aim trainers. You NEED in-game practice.
```

---

## Phase 5: Crosshair Discipline (12:00-15:00)

The final phase: cementing good habits before you queue up.

### The Crosshair Placement Drill

```
THE RULE: Your crosshair should ALWAYS be at head height,
aimed at where an enemy COULD appear.

DRILL (any FPS game, practice mode):

  Walk through a map slowly. As you approach each corner:
  
  1. Place crosshair at head height on the corner
  2. Wide peek (swing out to see the angle)
  3. Note: Is your crosshair already on where a head would be?
  
  YES → Good. That's where it should be.
  NO  → Adjust, re-peek. Where was your crosshair? Why was it wrong?
  
  Do this for 3 minutes on ONE map.
  
  FOCUS AREAS:
  ┌──────────────────────────────────────────────────┐
  │ □ Crosshair at head height (not feet, not body)  │
  │ □ Pre-aiming common angles (not empty space)      │
  │ □ Checking close corners first (clear near → far) │
  │ □ Not aiming at the ground while walking          │
  └──────────────────────────────────────────────────┘
```

### The "No Correction" Game

```
ADVANCED DRILL (for experienced players):

  In deathmatch or practice mode:
  
  When you see an enemy, DO NOT CORRECT YOUR AIM.
  Shoot exactly where your crosshair is when you first see them.
  
  If you miss: Your crosshair placement was bad. Note it.
  If you hit: Your default crosshair position was correct.
  
  Play 2 minutes like this. It ruthlessly exposes where your
  crosshair naturally rests and forces you to fix bad habits.
  
  Don't worry about dying — you're training crosshair DISCIPLINE.
```

---

## Game-Specific Variations

### Valorant Warmup (15 min)

```
0:00-3:00   Hand stretches (standard)
3:00-6:00   Aim Lab: Gridshot → Spidershot → Circletrack (1 min each)
6:00-9:00   Practice Range: Sheriff head-only vs bots (hard mode)
9:00-12:00  Deathmatch: Vandal, headshots only, walk everywhere
12:00-15:00 Custom game: Walk through your main map, pre-aim every angle

VALORANT-SPECIFIC TIP:
  Practice counter-strafing in deathmatch. Tap the opposite 
  movement key to stop instantly before shooting. This is THE 
  mechanical skill that determines gunfight outcomes in Valorant.
```

### Apex Legends Warmup (15 min)

```
0:00-3:00   Hand stretches (standard)
3:00-6:00   Aim Lab: Tracking scenarios (Apex needs tracking more than flicking)
6:00-9:00   Firing Range: R-301 spray control + Wingman flicks
9:00-12:00  Firing Range: Movement + shooting (slide-jump hipfire drills)
12:00-15:00 Movement tech practice: 5 min of slide-jumps, wall bounces

APEX-SPECIFIC TIP:
  Spend more time on tracking drills than flick drills.
  Apex TTK is high (takes many bullets to kill), so sustained
  tracking accuracy matters more than one-shot flick aim.
```

### CS2 Warmup (15 min)

```
0:00-3:00   Hand stretches (standard)
3:00-6:00   Aim Botz: AK tap (30 sec) → AK spray (30 sec) → AWP flick (1 min) → Deagle (1 min)
6:00-9:00   Aim Botz: Spray transfer drill (kill target, immediately spray next)
9:00-12:00  FFA Deathmatch: AK only, counter-strafe every shot
12:00-15:00 Retake server or deathmatch: Practice common angle holds

CS2-SPECIFIC TIP:
  Include spray pattern practice. CS2's spray patterns are unique
  and need to be re-calibrated every session. Spend at least 
  60 seconds doing AK spray-transfer drills.
```

---

## Quick 5-Minute Emergency Warmup

When your squad is already in queue and you have literally no time:

```
THE SPEED WARMUP (5 minutes):

  0:00-1:00  Hand stretches (prayer + reverse prayer + finger taps)
  1:00-3:00  Aim trainer: Gridshot (Aim Lab) or equivalent — one round
  3:00-5:00  In-game practice range: 50 kills, headshots only, fastest weapon
  
  THIS GETS YOU TO ~80% OF YOUR PEAK.
  Not perfect, but 10x better than loading straight into ranked.
  
  IF YOU HAVE LITERALLY 2 MINUTES:
  0:00-1:00  Hand stretches
  1:00-2:00  Move your mouse in figure-8s on your desktop while 
             rapidly clicking. Seriously. This activates hand 
             coordination faster than anything else.
```

---

*Your aim is warmed up. Now go get those W's.*
