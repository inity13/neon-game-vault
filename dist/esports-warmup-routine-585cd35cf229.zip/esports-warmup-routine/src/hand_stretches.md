# Hand Stretches — Protect Your Hands, Protect Your Career

## Table of Contents
1. [Why This Matters (Seriously)](#why-this-matters-seriously)
2. [Before Every Session (2 Minutes)](#before-every-session-2-minutes)
3. [During Long Sessions (1 Minute Every Hour)](#during-long-sessions-1-minute-every-hour)
4. [After Every Session (2 Minutes)](#after-every-session-2-minutes)
5. [Warning Signs of RSI](#warning-signs-of-rsi)
6. [Ergonomic Setup Tips](#ergonomic-setup-tips)

---

## Why This Matters (Seriously)

This is the section everyone skips. "Hand stretches? That's for old people."

Here are some uncomfortable facts:

```
GAMING INJURY STATISTICS:

  - 40-50% of esports pros report chronic hand/wrist pain
  - Average age of first RSI symptoms in gamers: 19-24
  - Carpal tunnel surgery recovery time: 3-6 MONTHS (no gaming)
  - Some pros have retired permanently due to hand injuries
  
  NOTABLE CASES:
  - Multiple CS pros have taken extended breaks for wrist surgery
  - Several League pros have retired early due to chronic wrist pain
  - Smash Bros players routinely deal with hand issues from controllers

  2-3 MINUTES OF STRETCHING prevents this. That's it.
  It's the cheapest insurance you'll ever get.
```

### What Actually Happens to Your Hands

```
WHEN YOU GAME FOR HOURS:

  Your tendons slide through narrow tunnels in your wrist.
  Repetitive motion (clicking, key pressing) creates friction.
  Friction causes inflammation. Inflammation causes swelling.
  Swelling compresses the nerves. Compressed nerves = PAIN.
  
  TIMELINE:
  Normal use:   Tendons slide freely, no issues
  Heavy use:    Slight friction, no symptoms yet
  Chronic use:  Inflammation begins, mild discomfort
  Overuse:      Swelling compresses median nerve → CARPAL TUNNEL
  
  ┌──────────────────────────────────────┐
  │ The Carpal Tunnel (cross-section)    │
  │                                      │
  │    ╔══════════════════╗              │
  │    ║  Tendons (9)     ║ ← These     │
  │    ║  ○ ○ ○ ○ ○ ○ ○  ║    swell     │
  │    ║  ○ ○             ║              │
  │    ║  ◉ Median Nerve  ║ ← This gets │
  │    ╚══════════════════╝    squeezed  │
  │    ────────────────────              │
  │    Carpal ligament                   │
  │                                      │
  │ When tendons swell, the nerve gets   │
  │ compressed → numbness, tingling, pain│
  └──────────────────────────────────────┘
  
  STRETCHING: Reduces friction, improves blood flow, prevents swelling.
  It literally keeps the tunnel open and the nerve happy.
```

---

## Before Every Session (2 Minutes)

Do ALL of these before you touch your mouse. In order. Takes 2 minutes.

### Stretch 1: Prayer Press (20 seconds)

```
HOW TO DO IT:
  1. Press palms together in front of your chest (prayer position)
  2. Keep fingers pointing up
  3. Slowly lower your hands toward your belly
  4. Keep palms pressed together the whole time
  5. Stop when you feel a stretch in your wrists/forearms
  6. Hold for 10 seconds
  7. Return to start. Repeat once.
  
  DIAGRAM:
     🙏  ← Start here (chest height)
      |
      |  ← Lower slowly
      |
     🙏  ← Stop here (belly height) - hold 10 sec
  
  WHAT YOU SHOULD FEEL: Gentle stretch in the underside of your wrists.
  WHAT YOU SHOULD NOT FEEL: Sharp pain. If it hurts, don't go as low.
```

### Stretch 2: Reverse Prayer (20 seconds)

```
HOW TO DO IT:
  1. Press the BACKS of your hands together (reverse prayer)
  2. Fingers pointing down
  3. Slowly raise your hands toward your chin
  4. Keep backs of hands pressed together
  5. Hold for 10 seconds at the top
  6. Return. Repeat once.
  
  DIAGRAM:
     🙏  ← Raise to here (chin height) - hold 10 sec
      |
      |  ← Raise slowly
      |
     🙏  ← Start here (belly height, backs of hands together)
  
  WHAT IT STRETCHES: Top of your wrists and the extensor tendons.
```

### Stretch 3: Wrist Flexor Stretch (20 seconds)

```
HOW TO DO IT:
  1. Extend your RIGHT arm straight forward, palm up
  2. With your LEFT hand, gently pull your RIGHT fingers down toward the floor
  3. Hold for 10 seconds
  4. Switch arms and repeat
  
  DIAGRAM:
     ──────→  (arm extended, palm up)
          ↓   (other hand pulls fingers down)
  
  THIS IS THE MOST IMPORTANT STRETCH FOR MOUSE USERS.
  Your wrist flexors do ALL the clicking work. Keep them limber.
```

### Stretch 4: Wrist Extensor Stretch (20 seconds)

```
HOW TO DO IT:
  1. Extend your RIGHT arm straight forward, palm DOWN
  2. With your LEFT hand, gently push your RIGHT fingers down
  3. Hold for 10 seconds
  4. Switch arms and repeat
  
  Same as above but with palm facing down instead of up.
  Stretches the opposite muscle group.
```

### Stretch 5: Finger Spreads (20 seconds)

```
HOW TO DO IT:
  1. Spread all fingers as WIDE as possible
  2. Hold for 5 seconds — really feel the stretch between fingers
  3. Make a tight FIST
  4. Hold for 5 seconds — squeeze hard
  5. Repeat 2 times
  
  DIAGRAM:
    🖐️ (spread wide, hold 5 sec)  →  ✊ (tight fist, hold 5 sec)  → repeat
  
  This improves blood flow and loosens the small muscles between fingers.
```

### Stretch 6: Thumb Circles (20 seconds)

```
HOW TO DO IT:
  1. Extend your thumb away from your hand
  2. Slowly circle it clockwise 5 times
  3. Circle counterclockwise 5 times
  4. Do both hands
  
  Your thumb does a LOT of work:
  - Mouse side buttons
  - Spacebar (jump)
  - Controller thumbstick
  
  Don't neglect it.
```

---

## During Long Sessions (1 Minute Every Hour)

Set a timer. Every 60 minutes, do these quick resets:

### The 60-Second Reset

```
BETWEEN MATCHES (or during queue):

  0-15 sec: Shake hands loosely (like shaking off water)
  15-30 sec: Prayer press (quick version, one rep)
  30-45 sec: Finger spreads (2 reps)
  45-60 sec: Wrist circles (5 each direction)
  
  DONE. Queue pops. Back to gaming.
  
  WHY EVERY HOUR?
  After 45-60 minutes of continuous use, your tendons start 
  accumulating micro-friction damage. A 1-minute reset:
  - Restores blood flow
  - Reduces accumulated friction
  - Prevents stiffness from building
  
  Think of it like this:
  Running for 1 hour straight → cramps and exhaustion
  Running for 15 min, stretch, run 15 min, stretch → much less fatigue
  
  Same principle for your hands.
```

### Signs You Need an Immediate Break

```
STOP AND STRETCH NOW IF:

  ⚠️ Tingling in your fingers (especially thumb, index, middle)
  ⚠️ Numbness in any finger
  ⚠️ Dull ache in your wrist that doesn't go away
  ⚠️ Sharp pain when clicking or pressing keys
  ⚠️ Weakness in grip (dropping your mouse)
  
  These are early warning signs of nerve compression.
  If stretching doesn't resolve them in 5 minutes, 
  STOP GAMING FOR THE DAY. Not tomorrow. Today.
```

---

## After Every Session (2 Minutes)

Cool-down stretches are just as important as warmup stretches.
Your muscles and tendons are warm and pliable after gaming — perfect
time to do deeper stretches.

### Post-Session Routine

```
STRETCH 1: Deep Wrist Flexor (30 seconds)
────────────────────────────────────────
  Same as the pre-session wrist flexor stretch, but hold for 20 seconds 
  per arm instead of 10. Go slightly deeper into the stretch.

STRETCH 2: Forearm Massage (30 seconds)
──────────────────────────────────────
  Use your thumb to massage the muscles on the TOP of your forearm.
  Start at the wrist and work toward the elbow.
  Apply moderate pressure. Find any tight spots and hold for 5 seconds.
  
  These muscles (extensors) get incredibly tight from mouse use.
  You might find spots that are surprisingly sore.

STRETCH 3: Finger Tendon Glides (30 seconds)
────────────────────────────────────────────
  This exercise helps tendons glide smoothly in their tunnels:
  
  Position 1: Fingers straight out (flat hand)      →
  Position 2: Curl fingers at middle joints (hook)    ↓
  Position 3: Curl fingers into a fist                ↓
  Position 4: Extend fingers (back to flat)          ↑
  
  Do this sequence 5 times, slowly and smoothly.
  You should feel your tendons sliding in your wrist.

STRETCH 4: Arm/Shoulder Release (30 seconds)
───────────────────────────────────────────
  1. Clasp hands behind your back
  2. Straighten your arms and push your hands away from your body
  3. Lift your arms up slightly while pushing chest forward
  4. Hold for 15 seconds
  5. Release and shake out
  
  This opens up your chest and shoulders, which get hunched 
  from sitting at a desk. Hunched posture compresses nerves
  in your neck and shoulders that run down to your hands.
```

---

## Warning Signs of RSI

RSI (Repetitive Strain Injury) develops gradually. Catch it early.

```
STAGE 1: MILD (Easily reversible)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Symptoms:
  - Mild ache after long sessions
  - Stiffness when waking up
  - Discomfort that goes away with stretching
  
  Action: Do your stretches. Add hourly breaks. You're fine.

STAGE 2: MODERATE (Reversible with changes)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Symptoms:
  - Pain during gaming (not just after)
  - Tingling or numbness in fingers
  - Weakness when gripping mouse
  - Pain when twisting doorknobs or opening jars
  
  Action: 
  - Reduce gaming to 2-hour max sessions with breaks
  - Apply ice after sessions (15 min on, 15 min off)
  - Do stretches 3x daily (morning, before gaming, after gaming)
  - Consider a wrist brace for sleeping (keeps wrist neutral)
  - SEE A DOCTOR if symptoms persist for 2+ weeks

STAGE 3: SEVERE (May require medical intervention)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Symptoms:
  - Constant pain even when not gaming
  - Can't grip objects without pain
  - Waking up at night with numb hands
  - Visible swelling in wrist area
  - Sharp, shooting pain from wrist to elbow
  
  Action: SEE A DOCTOR. Not "maybe." DEFINITELY.
  You may need physical therapy or, in severe cases, surgery.
  DO NOT try to "push through it."
```

---

## Ergonomic Setup Tips

Stretches help, but a bad setup causes injury faster than stretches can prevent it.

### Mouse Hand Position

```
BAD:                          GOOD:
                              
  ╲ Wrist bent UP             ── Wrist straight/neutral
   ╲                          
    ╲───Mouse                  ──╲───Mouse
  ─────────Desk               ─────────Desk
  
  Your wrist should be NEUTRAL — not bent up, down, or sideways.
  
  FIXES:
  - Wrist rest (use it BETWEEN clicks, NOT during)
  - Lower desk height so forearms are parallel to floor
  - Mouse at same height as keyboard (no reaching up)
```

### Keyboard Hand Position

```
BAD:                          GOOD:
  
  Wrists resting ON desk     Fingers hovering OVER keys
  while fingers reach UP     with forearms supported
  to keys                    
  
  ╲                            ──
   ╲──── Keyboard              ──╲── Keyboard
  ──────── Desk               ──────── Desk
  
  FIXES:
  - Keyboard feet FLAT (not angled up) — reduces wrist extension
  - Wrist rest for between-typing breaks
  - Fingers should "drop" onto keys, not "reach" for them
```

### Chair and Posture

```
THE IDEAL GAMING POSTURE:

  Head:     Centered over shoulders, not leaning forward
  Screen:   Top of monitor at eye level, arm's length away
  Shoulders: Relaxed, not shrugged up to ears
  Elbows:   At ~90° angle, close to your body
  Forearms:  Parallel to the floor
  Wrists:   Neutral (not bent in any direction)
  Back:     Supported by chair, slight recline (100-110°)
  Feet:     Flat on floor or footrest
  
  SIDE VIEW:
  
       O  ← Head (over shoulders)
      /|\ ← Shoulders relaxed
       |  ← Back supported (100-110° recline)
      / \ ← Feet flat
  ────────── Floor
  
  THE #1 MISTAKE: Leaning forward toward the monitor.
  This compresses your neck → shoulders → arms → wrists.
  Scoot your chair forward instead of leaning.
```

### Quick Ergonomic Checklist

```
RUN THROUGH THIS ONCE A WEEK:

  □ Monitor at eye level (not looking down or up)
  □ Monitor at arm's length distance
  □ Chair seat height: feet flat on floor
  □ Armrests at elbow height (or remove them if too high)
  □ Mouse and keyboard at same height
  □ Wrists neutral (not bent up/down/sideways)
  □ Room temperature comfortable (cold = tight muscles)
  □ Lighting: no glare on screen (squinting = tension)
  □ Take a break every 60 minutes minimum
```

---

*Your hands are your most valuable gaming asset. Protect them like your rank depends on it — because it does.*
