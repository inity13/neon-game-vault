# Fortnite Pro Guide — Complete Battle Royale Strategy

> From noob to cracked in one guide. Building, weapons, rotations, and settings — everything you need to dominate.

## What's Inside

- **Building Techniques** — Wall-ramp rushes, 90s, tunneling, retakes, and when to use each
- **Weapon Tier Lists** — Every weapon class ranked with DPS breakdowns and optimal ranges
- **Drop Location Rankings** — Every named POI rated for loot quality, rotation safety, and contest frequency
- **Settings Optimization** — Video, audio, keybinds, and sensitivity configs for max FPS and smoothest aim
- **Game Sense Guide** — Rotations, storm positioning, third-party awareness, and endgame strategies
- **Season Meta Analysis** — Framework for evaluating new items and adapting your loadout

## Quick Preview

### Building Speed Tiers

| Tier | Technique | Avg. Time | When to Use |
|------|-----------|-----------|-------------|
| S | Triple-edit retake | < 2s | Box fight retakes, high ground contests |
| A | Double 90s | < 1.5s | Quick height gain, early fight positioning |
| A | Ramp-wall-floor rush | < 1s/tile | Aggressive pushes, closing distance |
| B | Basic wall-ramp | < 0.5s/tile | Default approach, safe rotation cover |
| C | Single wall place | Instant | Panic defense, blocking shots |

### Top 5 Weapon Combos (Current Meta Framework)

1. **Assault Rifle + Shotgun + SMG + Heals + Mobility** — The balanced loadout
2. **Sniper + AR + Shotgun + Heals + Heals** — Long-range control
3. **SMG + Shotgun + Shotgun + Heals + Mobility** — Hyper-aggressive box fighting
4. **AR + DMR + Shotgun + Heals + Utility** — Mid-range dominance
5. **Shotgun + SMG + Utility + Heals + Heals** — Late-game survival

*Full tier lists with DPS calculations, damage drop-off charts, and headshot multipliers inside.*

## Files Included

| File | Description |
|------|-------------|
| `src/building_guide.md` | Complete building techniques from beginner to advanced |
| `src/weapon_tier_list.md` | All weapons ranked with stats and analysis |
| `src/drop_locations.md` | Every POI ranked and analyzed |
| `src/settings_optimization.md` | Video, audio, input, and keybind optimization |
| `src/game_sense_guide.md` | Rotations, positioning, and decision-making |
| `src/sensitivity_calculator.py` | Python script to calculate your ideal sensitivity |
| `examples/pro_settings_profiles.json` | Pre-made settings profiles (Competitive, Casual, Performance) |

## How to Use

1. **Start with Settings** — `src/settings_optimization.md` to get your game running smooth
2. **Run the Sensitivity Calculator** — `python3 src/sensitivity_calculator.py` to find your ideal sens
3. **Learn Building** — Work through `src/building_guide.md` from Beginner to Advanced
4. **Study Weapons** — Use `src/weapon_tier_list.md` to optimize your loadout choices
5. **Pick Your Drops** — Use `src/drop_locations.md` to find your perfect landing spot
6. **Level Up Game Sense** — `src/game_sense_guide.md` for the final edge

## Who This Is For

- Players stuck in low-rank lobbies who want to improve fast
- Casual players who want to understand the meta without watching 100 YouTube videos
- Anyone who wants a single reference they can come back to every session

## License

MIT License — See LICENSE file.
