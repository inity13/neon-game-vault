# Weapon Tier List & DPS Analysis

> Updated framework for evaluating any weapon in any season. Learn the principles, not just the current meta.

## How This Tier List Works

Weapons are ranked within their class using these factors:
- **DPS (Damage Per Second)** — Raw theoretical damage output
- **Effective Range** — Distance where the weapon performs best
- **Accuracy** — First-shot accuracy, bloom, recoil pattern
- **Versatility** — How many situations the weapon handles well
- **Skill Floor** — How easy it is to use effectively

### Tier Definitions

| Tier | Meaning |
|------|---------|
| **S** | Meta-defining. Pick this up every time you see it. |
| **A** | Strong. Reliable in most situations. |
| **B** | Solid. Good if you can't find S/A tier. |
| **C** | Situational. Only pick up if you have a specific plan. |
| **D** | Avoid. Better options exist in almost every scenario. |

---

## Assault Rifles

| Weapon | Tier | DPS (body) | Headshot Mult | Effective Range | Notes |
|--------|------|-----------|---------------|-----------------|-------|
| Burst AR (Legendary) | S | ~180 burst | 1.5x | 30-80m | Deadly accurate, burst catches people off guard |
| Standard AR (Legendary) | A | ~190 | 1.5x | 25-75m | Consistent, forgiving bloom |
| Standard AR (Epic) | A | ~180 | 1.5x | 25-70m | Slightly less damage, still great |
| Burst AR (Epic) | A | ~170 burst | 1.5x | 30-75m | Strong but needs good aim |
| Standard AR (Rare) | B | ~170 | 1.5x | 20-65m | Your mid-game workhorse |
| Standard AR (Uncommon) | B | ~165 | 1.5x | 20-60m | Fine for early game |
| Standard AR (Common) | C | ~158 | 1.5x | 15-55m | Drop this ASAP |

### AR Usage Tips
- **Tap fire** at 50m+ for first-shot accuracy
- **Burst spray** at 20-40m, 4-5 shot bursts with pauses
- **Full spray** only under 20m or into builds
- Crouching tightens bloom by ~25%

### Damage Falloff Chart (Generic AR Framework)

```
DAMAGE
100% |████████████████
 90% |                ████████
 80% |                        ████████
 70% |                                ████████
 60% |                                        ████
     +────────┬────────┬────────┬────────┬────────
     0m      25m      50m      75m     100m
                    DISTANCE
```

---

## Shotguns

| Weapon | Tier | Max Damage (body) | Headshot Mult | Effective Range | Fire Rate |
|--------|------|-------------------|---------------|-----------------|-----------|
| Pump (Legendary) | S | 110 | 2.0x (220!) | 0-10m | Slow |
| Pump (Epic) | S | 105 | 2.0x (210) | 0-10m | Slow |
| Tactical (Legendary) | A | 83 | 1.5x | 0-12m | Fast |
| Pump (Rare) | A | 100 | 2.0x (200) | 0-9m | Slow |
| Tactical (Epic) | B | 79 | 1.5x | 0-11m | Fast |
| Pump (Uncommon) | B | 95 | 2.0x (190) | 0-8m | Slow |
| Tactical (Rare) | B | 75 | 1.5x | 0-10m | Fast |
| Pump (Common) | C | 90 | 2.0x (180) | 0-7m | Slow |

### Pump vs Tactical Decision Tree

```
Are you confident in your aim?
├── YES → Use Pump
│   └── Can you consistently hit headshots?
│       ├── YES → Pump is your best friend (200+ headshots)
│       └── NO → Pump still fine, but consider Tactical
└── NO → Use Tactical
    └── The faster fire rate forgives missed shots
```

### Shotgun Damage Mechanics

Shotguns fire pellets in a spread pattern. Damage depends on how many pellets hit.

```
  CROSSHAIR SPREAD:
  
  Close (2m):     Medium (6m):     Far (10m):
  ┌────┐          ┌──────┐         ┌────────┐
  │·· ·│          │ ·  · │         │·   ·   │
  │ ·· │          │  ··  │         │  ·  ·  │
  │· · │          │ ·  · │         │ ·    · │
  └────┘          └──────┘         └────────┘
  All pellets     Most pellets     Few pellets
  = MAX damage    = 60-80% dmg     = 20-40% dmg
```

**Key insight:** At point-blank range, even a body shot with a Legendary Pump does 110. But a clean headshot does 220 — that's a one-shot elimination on most health pools. This is why pump headshot aim is the most important mechanical skill in the game.

---

## SMGs

| Weapon | Tier | DPS | Headshot Mult | Effective Range | Notes |
|--------|------|-----|---------------|-----------------|-------|
| Rapid Fire SMG (Legendary) | S | ~255 | 1.5x | 0-20m | Insane DPS, shreds builds |
| Standard SMG (Legendary) | A | ~210 | 1.5x | 0-25m | Good range for an SMG |
| Rapid Fire SMG (Epic) | A | ~240 | 1.5x | 0-18m | Burns ammo fast |
| Standard SMG (Epic) | A | ~200 | 1.5x | 0-23m | Reliable |
| Standard SMG (Rare) | B | ~190 | 1.5x | 0-20m | Fine |
| Standard SMG (Uncommon) | B | ~180 | 1.5x | 0-18m | Early game spray |
| Standard SMG (Common) | C | ~170 | 1.5x | 0-15m | Drop when possible |

### SMG Role
SMGs excel at:
1. **Spraying into boxes** after editing a wall
2. **Follow-up damage** after a shotgun shot
3. **Breaking builds** — high fire rate tears through wood
4. **Chip damage** during build fights

### The Shotgun-SMG Combo

```
  TIMELINE:
  
  0.0s     0.2s     0.5s     0.8s     1.0s
  │        │        │        │        │
  PUMP     SWITCH   SMG      SMG      SMG
  SHOT     TO SMG   SPRAY    SPRAY    SPRAY
  (110)    (swap)   (+50)    (+50)    (+50)
  
  Total damage in 1 second: ~260+ damage
```

This is the bread-and-butter combo. Hit a pump shot, immediately swap to SMG and spray. Don't wait to see if the pump killed — just swap and spray.

---

## Snipers & Long Range

| Weapon | Tier | Damage (body) | Headshot Mult | Bullet Drop | Notes |
|--------|------|--------------|---------------|-------------|-------|
| Bolt-Action (Legendary) | S | 120 | 2.5x (300!) | Medium | One-shot headshot at any range |
| Bolt-Action (Epic) | A | 115 | 2.5x (287) | Medium | Still one-shots with headshot |
| Semi-Auto Sniper (Legendary) | B | 80 | 2.0x | Low | Faster fire rate, less damage |
| Hunting Rifle (Legendary) | A | 100 | 2.5x (250) | High | No scope, requires skill |
| DMR (Legendary) | A | 45 | 1.5x | Very Low | Spam at range, consistent |

### Bullet Drop Reference

```
  AIM POINT vs ACTUAL HIT (100m shot):
  
  Bolt-Action:          Hunting Rifle:        DMR:
  ── aim ──             ── aim ──             ── aim ──
  ·                     ·                     
  ·                     ·                     ·  ← hit
   · ← hit             ·
                         · ← hit
  
  ~2 ticks below        ~3 ticks below        ~1 tick below
```

### Leading Targets

At 100m, a running target moves ~2-3 character widths during bullet travel time. Aim where they're going, not where they are.

```
  Target moving right →
  
  ← 3 widths →
  ┌──┐        ┌──┐
  │  │ AIM →  │  │  TARGET
  └──┘  HERE  └──┘  IS HERE
```

---

## Utility & Explosives

| Item | Tier | Damage | Use Case |
|------|------|--------|----------|
| Rocket Launcher | S | 110 (player) / 400 (build) | Destroying boxes, forcing movement |
| Grenade Launcher | A | 100 (player) / 400 (build) | Area denial, breaking turtles |
| Grenades | B | 100 | Free damage, no ammo cost |
| Firefly Jar | B | 40 + burn | Forces players out of wood builds |
| Shockwave Grenade | S | 0 (mobility) | Rotations, escapes, pushing |
| Boogie Bomb | A | 0 (CC) | Forces dance = free shotgun shot |

---

## Loadout Optimization

### The 5-Slot Formula

```
  SLOT 1: Close Range (Shotgun)         — ALWAYS
  SLOT 2: Mid Range (AR / SMG)          — ALWAYS  
  SLOT 3: Flex (Sniper / SMG / Utility) — SITUATION
  SLOT 4: Heals (Minis / Medkit)        — ALWAYS
  SLOT 5: Heals OR Mobility             — SITUATION
```

### Heal Priority

| Heal | HP Restored | Time | Priority |
|------|-------------|------|----------|
| Small Shield (Mini) | +25 shield (cap 50) | 2s | ★★★★★ |
| Big Shield | +50 shield | 5s | ★★★★ |
| Medkit | +100 HP | 10s | ★★★ |
| Bandages | +15 HP (cap 75) | 3.5s | ★★ |
| Chug Splash | +20 HP/Shield | Instant | ★★★★★ |
| Slurp Juice | +75 total | Over time | ★★★ |

**Rule:** Minis > Big Shield > Chug Splash > Medkit > Slurp > Bandages

Carry at least 6 minis if possible. They're the fastest heal and most efficient use of an inventory slot.

---

## How to Evaluate New Weapons

When a new weapon drops in a patch, ask these questions:

1. **What's the DPS?** Compare to existing weapons in the same slot
2. **What's the effective range?** Does it fill a gap or overlap?
3. **What's the skill floor?** Can you use it effectively without practice?
4. **Does it replace anything?** If it doesn't clearly beat something, skip it
5. **What's the ammo type?** Competing for the same ammo as your primary?

```
  NEW WEAPON EVALUATION:
  
  DPS > Current weapon?  ──→ YES → Consider swapping
                          └→ NO  → Does it fill a different range?
                                    ├→ YES → Consider adding to loadout
                                    └→ NO  → Skip it
```

---

*Tier lists shift every season. The framework for evaluating weapons doesn't. Learn to think about DPS, range, and role — and you'll always know what to pick up.*
