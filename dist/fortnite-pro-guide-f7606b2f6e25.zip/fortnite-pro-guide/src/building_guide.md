# Building Techniques — From Foundations to Cracked

## Table of Contents
1. [Building Fundamentals](#building-fundamentals)
2. [Defensive Builds](#defensive-builds)
3. [Offensive Builds](#offensive-builds)
4. [Advanced Techniques](#advanced-techniques)
5. [Edit Patterns](#edit-patterns)
6. [Practice Drills](#practice-drills)

---

## Building Fundamentals

### The 4 Building Pieces

| Piece | Hotkey (Default) | HP (Wood/Brick/Metal) | Build Time | Primary Use |
|-------|-------------------|-----------------------|------------|-------------|
| Wall | Q / Mouse 4 | 150 / 300 / 400 | 0.5s start | Defense, blocking shots |
| Floor | - | 150 / 300 / 400 | 0.5s start | Bridging, protection from below |
| Ramp (Stair) | F / Mouse 5 | 150 / 300 / 400 | 0.5s start | Height gain, cover while pushing |
| Cone (Pyramid) | T | 150 / 300 / 400 | 0.5s start | Trick edits, blocking, protection |

### Material Properties

```
WOOD      ████████░░  Starting HP: 90   Max: 150   Build Rate: Fastest
BRICK     ████████████░░  Starting HP: 90   Max: 300   Build Rate: Medium
METAL     ████████████████░░  Starting HP: 110  Max: 400   Build Rate: Slowest
```

**When to use each:**
- **Wood** — Early game, quick fights. Builds fastest so it blocks shots sooner.
- **Brick** — Mid-game default. Good balance of HP and build speed.
- **Metal** — Endgame tunneling, holding a position you won't leave. Highest max HP.

> **Pro Tip:** Wood has the highest STARTING HP relative to its build time. In a fast build fight where pieces are being shot immediately, wood can actually tank more damage than metal because it reaches full HP faster.

---

## Defensive Builds

### The Box (1x1)

The most fundamental defensive structure. 4 walls + floor + cone on top.

```
  TOP VIEW:
  ┌─────────┐
  │  [CONE] │
  │         │
  │   YOU   │
  │         │
  └─────────┘
  
  SIDE VIEW:
  ┌────┐
  │/\/\│  ← Cone (pyramid)
  │    │  ← Walls on all 4 sides
  │ @  │  ← You
  └────┘  ← Floor
```

**Build order:** Wall (front) → Wall (left) → Wall (right) → Wall (back) → Cone → Floor

**Why the cone?** Prevents opponents from placing their own floor above you. If someone owns the piece above your head, they can edit it open and shoot straight down on you.

### Double Box

```
  ┌─────────┬─────────┐
  │  [CONE] │  [CONE] │
  │         │         │
  │   YOU ──┼──→      │
  │         │         │
  └─────────┴─────────┘
```

Two connected 1x1 boxes. You move between them to avoid getting sprayed through a single wall. Edit the connecting wall to reposition, then close it.

**When to use:** When you're being pressured from one side and need to create distance within your own structure.

### Fortified Tower (3-Layer)

```
  LAYER 3 (TOP):
  ┌────┐
  │/\/\│  Cone
  ├────┤
  │ @  │  You peek from here
  ├────┤
  │████│  Ramp facing outward
  └────┘
  
  LAYER 2 (MIDDLE):
  ┌────┐
  │/\/\│  Cone
  ├────┤
  │████│  Ramp
  └────┘
  
  LAYER 1 (BASE):
  ┌────┐
  │    │  Walls only
  └────┘
```

**Build order per layer:** 4 walls → ramp → cone → jump → repeat

---

## Offensive Builds

### Wall-Ramp Rush

The bread and butter aggressive push. Place wall + ramp simultaneously while running forward.

```
  SIDE VIEW (moving right →):
  
           ╱│
          ╱ │
  ┌──────╱──┤
  │  @  ╱   │
  │    ╱    │
  └───╱─────┘
     ╱
```

**Execution:**
1. Jump forward
2. Place wall (facing opponent)
3. Place ramp (behind wall, under your feet)
4. Repeat

**Speed target:** 3 tiles/second at full sprint

### Double-Wall Ramp Rush

Same as above but with a second wall layer for protection. Harder to shoot through.

```
  SIDE VIEW:
  
           ╱│ │
          ╱ │ │
  ┌──────╱──┤ │
  │  @  ╱   │ │  ← Double wall protection
  │    ╱    │ │
  └───╱─────┘ │
     ╱        │
```

### Ramp-Wall-Floor Rush (The Triple)

Maximum protection while pushing. Floor prevents shots from below, wall blocks front, ramp gives you height.

```
  SIDE VIEW:
  
        ╱│
       ╱ │
  ┌───╱──┤
  │@█╱   │
  ├──────┤  ← Floor underneath
  └──────┘
```

**Execution order:** Ramp → Wall (in front of ramp) → Floor (under ramp)

This is the standard competitive push technique. Practice until you can do it without thinking.

---

## Advanced Techniques

### 90s (The Height Take)

The fastest way to gain height. You turn 90° each layer while placing wall + ramp.

```
  TOP VIEW (rotation):
  
  Start:  Turn 1:  Turn 2:  Turn 3:
  ↑ N     → E      ↓ S      ← W
  
  Each turn = 1 wall + 1 ramp + jump
```

**Types of 90s:**

| Type | Speed | Difficulty | Notes |
|------|-------|------------|-------|
| Standard 90s | Medium | ⭐⭐ | Wall, ramp, jump, turn. The default. |
| Protected 90s | Slow | ⭐⭐⭐ | Add a floor each layer for bottom protection |
| Thwifo 90s | Fast | ⭐⭐⭐⭐ | Jump before placing ramp, fastest variant |
| Mongraal 90s | Fastest | ⭐⭐⭐⭐⭐ | Pre-place floor, requires frame-perfect timing |

**Standard 90s step-by-step:**
1. Place wall in front of you
2. Place ramp behind the wall (you should be on it)
3. Jump to the top-right of the ramp
4. Turn 90° and repeat

### Tunneling

Moving horizontally through builds for protection during rotations (especially in competitive endgame).

```
  SIDE VIEW (moving right →):
  
  ┌────┬────┬────┬────┐
  │/\/\│/\/\│/\/\│/\/\│  ← Cones on top
  │    │    │ @→ │    │  ← You moving through
  ├────┼────┼────┼────┤  ← Floors
  └────┴────┴────┴────┘
```

**Execution per tile:**
1. Place floor beneath you
2. Place ramp/wall in front
3. Place cone above
4. Edit through front piece
5. Repeat

**Speed target:** 2 tiles/second in competitive play

### Retakes

When someone takes your high ground, retakes let you reclaim it.

#### Side Jump Retake
```
  Step 1: Box up       Step 2: Edit out side    Step 3: Place ramp up
  ┌────┐               ┌── ─┐                   ┌────┐
  │ @  │               │ @→ │                    │  ╱ │
  └────┘               └────┘                    │╱@  │
                                                  └────┘
```

#### Cone Jump Retake
```
  Step 1: Place cone    Step 2: Edit cone (ramp) Step 3: Jump off
  ┌────┐               ┌────┐                    │  @
  │/\/\│               │  ╱ │                    │ ╱
  │ @  │               │╱@  │                    │╱
  └────┘               └────┘                    └────
```

---

## Edit Patterns

### Essential Edits (Master These First)

| Edit | Pattern | Use Case |
|------|---------|----------|
| Wall → Door | Remove bottom-left + bottom-right | Quick peek without exposing yourself |
| Wall → Window | Remove center tile | Shotgun peek, limited exposure |
| Wall → Half-wall | Remove top 3 tiles | Low peek, hard to headshot |
| Ramp → Half-ramp | Remove left or right column | Side peek from behind ramp |
| Cone → Ramp | Remove 2 diagonal tiles | Instant ramp from pyramid |
| Floor → Half-floor | Remove 2 tiles | Drop down while maintaining some cover |

### Advanced Edit Plays

#### The Peanut Butter Edit (Wall)
Remove one corner tile. Creates a tiny peek hole that's very hard for opponents to shoot through.

```
  Standard Wall:     Peanut Butter:
  ┌──┬──┬──┐        ┌──┬──┬──┐
  │██│██│██│        │  │██│██│
  ├──┼──┼──┤        ├──┼──┼──┤
  │██│██│██│        │██│██│██│
  └──┴──┴──┘        └──┴──┴──┘
  
  ↑ Removed top-left = peek spot
```

#### The Mongraal Classic
Edit wall → shotgun shot → reset wall → edit again from different angle.

```
  Step 1: Edit open     Step 2: Shoot      Step 3: Reset      Step 4: New edit
  ┌──┬──┬──┐           ┌──┬──┬──┐         ┌──┬──┬──┐        ┌──┬──┬──┐
  │  │  │██│     💥     │  │  │██│         │██│██│██│        │██│  │  │
  ├──┼──┼──┤    ───→    ├──┼──┼──┤   →     ├──┼──┼──┤  →     ├──┼──┼──┤
  │  │  │██│           │  │  │██│         │██│██│██│        │██│  │  │
  └──┴──┴──┘           └──┴──┴──┘         └──┴──┴──┘        └──┴──┴──┘
```

---

## Practice Drills

### Daily Building Routine (15 minutes)

| Drill | Time | Focus |
|-------|------|-------|
| Free build (90s, retakes) | 3 min | Warm up muscle memory |
| Wall-ramp rush course | 3 min | Speed and consistency |
| Box fight edits | 3 min | Edit speed and accuracy |
| Tunneling practice | 3 min | Rotation mechanics |
| 1v1 creative fight | 3 min | Combine everything |

### Progression Milestones

| Milestone | Metric | Level |
|-----------|--------|-------|
| Place 4 walls consistently | < 1 second | Beginner |
| Standard 90s without falling | 5 in a row | Beginner+ |
| Wall-ramp rush across map | No gaps | Intermediate |
| Triple rush (ramp-wall-floor) | Smooth | Intermediate+ |
| Protected 90s | 5 in a row, no gaps | Advanced |
| Tunnel 10 tiles | < 6 seconds | Advanced |
| Mongraal classic combo | Consistent hits | Expert |
| Thwifo 90s | 5 in a row clean | Expert |

### Common Mistakes

| Mistake | Why It Happens | Fix |
|---------|---------------|-----|
| Ramps placing backwards | Crosshair too high/low | Keep crosshair at character center height |
| Falling off 90s | Jumping too early/late | Jump at peak of ramp, not before |
| Walls not placing | Too close to existing build | Step back slightly before placing |
| Slow edits | Selecting too many tiles | Practice the exact tile pattern, not the shape |
| Tunnel gaps | Moving too fast | Slow down, prioritize coverage over speed |

---

*Remember: Building is muscle memory. You won't get better by reading — you get better by practicing. Spend 15 minutes before every session running drills and you'll see improvement within a week.*
