# Drop Location Rankings & Rotation Guide

> Where you land determines the first 5 minutes of your game. Choose wisely.

## Rating System

Each location is rated on 5 factors (1-5 scale):

| Factor | What It Measures |
|--------|-----------------|
| **Loot Quality** | Number of chests, floor loot spawns, rare item chance |
| **Materials** | Available wood, brick, and metal from harvesting |
| **Safety** | How contested the spot is + how easy it is to get third-partied |
| **Rotation** | Access to zone, nearby vehicles, launch pads, terrain advantage |
| **Consistency** | How reliable the loot is game-to-game |

### Overall Rating Formula
```
Overall = (Loot × 0.25) + (Materials × 0.15) + (Safety × 0.25) + (Rotation × 0.2) + (Consistency × 0.15)
```

---

## Location Tier List

### S-Tier: Land Here Every Game If You Can

#### Major Named POI #1 (High-Loot Hub)
```
┌──────────────────────────────┐
│  Loot:      ★★★★★  (5/5)    │
│  Materials: ★★★★☆  (4/5)    │
│  Safety:    ★★☆☆☆  (2/5)    │
│  Rotation:  ★★★★★  (5/5)    │
│  Consist:   ★★★★★  (5/5)    │
│  OVERALL:   ★★★★☆  (4.2/5)  │
│                              │
│  Chests: 20-25               │
│  Players Landing: 3-6        │
│  Best For: Aggressive players│
└──────────────────────────────┘
```

**Strategy:** Land on the tallest building first for a chest + height advantage. Clear floor by floor working downward. Rotate toward the center of the next zone.

**Pros:**
- Massive loot pool, you'll leave fully kitted
- Central position means easy rotations to any zone
- Lots of cover for fights

**Cons:**
- Heavily contested — expect at least 2-3 fights off drop
- Getting third-partied is common
- You need to be fast and decisive

#### Major Named POI #2 (Resource-Rich Area)
```
┌──────────────────────────────┐
│  Loot:      ★★★★☆  (4/5)    │
│  Materials: ★★★★★  (5/5)    │
│  Safety:    ★★★☆☆  (3/5)    │
│  Rotation:  ★★★★☆  (4/5)    │
│  Consist:   ★★★★★  (5/5)    │
│  OVERALL:   ★★★★☆  (4.1/5)  │
│                              │
│  Chests: 15-20               │
│  Players Landing: 2-4        │
│  Best For: Balanced players  │
└──────────────────────────────┘
```

**Strategy:** Split the area with your duo/squad. Loot one section each, meet in the middle. Farm materials on the way out.

---

### A-Tier: Reliable, Less Contested

#### Edge-Map Named POI
```
┌──────────────────────────────┐
│  Loot:      ★★★★☆  (4/5)    │
│  Materials: ★★★☆☆  (3/5)    │
│  Safety:    ★★★★☆  (4/5)    │
│  Rotation:  ★★★☆☆  (3/5)    │
│  Consist:   ★★★★☆  (4/5)    │
│  OVERALL:   ★★★★☆  (3.7/5)  │
│                              │
│  Chests: 12-16               │
│  Players Landing: 1-3        │
│  Best For: Consistent loot   │
└──────────────────────────────┘
```

**Strategy:** Land uncontested most games. Loot everything, max materials, rotate early. The long rotation is the only downside.

#### Secondary Hub Area
```
┌──────────────────────────────┐
│  Loot:      ★★★☆☆  (3/5)    │
│  Materials: ★★★★☆  (4/5)    │
│  Safety:    ★★★★★  (5/5)    │
│  Rotation:  ★★★★☆  (4/5)    │
│  Consist:   ★★★★☆  (4/5)    │
│  OVERALL:   ★★★★☆  (3.9/5)  │
│                              │
│  Chests: 8-12                │
│  Players Landing: 0-2        │
│  Best For: Safe starts       │
└──────────────────────────────┘
```

---

### B-Tier: Solid, Nothing Special

#### Small Named POI
```
┌──────────────────────────────┐
│  Loot:      ★★★☆☆  (3/5)    │
│  Materials: ★★★☆☆  (3/5)    │
│  Safety:    ★★★★☆  (4/5)    │
│  Rotation:  ★★★☆☆  (3/5)    │
│  Consist:   ★★★☆☆  (3/5)    │
│  OVERALL:   ★★★☆☆  (3.3/5)  │
└──────────────────────────────┘
```

#### Unnamed Landmark Cluster
```
┌──────────────────────────────┐
│  Loot:      ★★☆☆☆  (2/5)    │
│  Materials: ★★★★★  (5/5)    │
│  Safety:    ★★★★★  (5/5)    │
│  Rotation:  ★★☆☆☆  (2/5)    │
│  Consist:   ★★★☆☆  (3/5)    │
│  OVERALL:   ★★★☆☆  (3.2/5)  │
└──────────────────────────────┘
```

**Note:** Unnamed spots are underrated. Low contest rate + decent floor loot. Rotate to a nearby named POI after initial loot for a full kit.

---

### C-Tier: Avoid Unless Forced

#### Tiny Landmark
```
┌──────────────────────────────┐
│  Loot:      ★☆☆☆☆  (1/5)    │
│  Materials: ★★☆☆☆  (2/5)    │
│  Safety:    ★★★★★  (5/5)    │
│  Rotation:  ★★☆☆☆  (2/5)    │
│  Consist:   ★★☆☆☆  (2/5)    │
│  OVERALL:   ★★☆☆☆  (2.3/5)  │
└──────────────────────────────┘
```

Only land here if the bus literally flies over it and nobody else is dropping. Even then, rotate immediately.

---

## Rotation Strategy

### Zone Prediction

```
  FULL MAP (simplified):
  ┌─────────────────────────────┐
  │         STORM               │
  │    ┌───────────────┐        │
  │    │   SAFE ZONE   │        │
  │    │               │        │
  │    │   ┌───────┐   │        │
  │    │   │ NEXT  │   │        │
  │    │   │ ZONE  │   │        │
  │    │   └───────┘   │        │
  │    │               │        │
  │    └───────────────┘        │
  │                             │
  └─────────────────────────────┘
```

**Rules of thumb:**
- Zone tends to pull toward the center of the previous zone
- Edge-map drops need to rotate earlier
- **Rotate early** (before the storm starts moving) for positioning advantage
- **Rotate late** (after storm moves) if you need to loot more but risk storm damage

### Rotation Timing by Phase

| Storm Phase | When to Rotate | Why |
|-------------|---------------|-----|
| Phase 1 (big circle) | After full loot | Plenty of time, no rush |
| Phase 2 | Before storm moves | Start taking position |
| Phase 3 | Immediately when zone shows | Zone is getting small, need good position |
| Phase 4+ | You should already be in zone | If you're rotating this late, you're in trouble |

### Rotation Priorities

```
  BEST → 1. Center zone with high ground and materials
         2. Edge zone with natural cover (hills, rocks)
         3. Center zone without cover
         4. Edge zone without cover
  WORST→ 5. Running from storm with no builds
```

### Vehicle Priority

| Vehicle | Speed | Protection | Noise | Rating |
|---------|-------|------------|-------|--------|
| Sports Car | ★★★★★ | ★★★ | ★★★★★ (loud) | A |
| Off-Road | ★★★★ | ★★★ | ★★★★ | A |
| Boat | ★★★★ | ★★ | ★★★ | B (water only) |
| Shopping Cart | ★★ | ★ | ★★ | C |

---

## Advanced Drop Strategy

### The "Split & Converge" (Duos/Squads)

```
  BUS PATH →→→→→→→→→→→→
                ↓ ↓
           Player 1  Player 2
                ↓      ↓
           [POI-A]  [POI-B]
                ↓      ↓
                └──┬───┘
                   ↓
              [MEET HERE]
              [Full kitted]
```

Split your team across 2 nearby locations to avoid fighting each other for loot. Meet up once looted.

### The "Late Drop" Technique

Watch where other players are going, then land at the SECOND best spot near them. They'll fight each other at the best spot while you loot in peace, then push the survivor when they're low.

### The "Hot Drop Recovery" Protocol

If you land in a contested area and get a bad spawn:

```
  Got a weapon?
  ├── YES → Fight the nearest player immediately
  │         (Don't loot more, you'll get killed while looting)
  └── NO  → Run to the next building/chest
             ├── Still no weapon? → Pickaxe swing and pray
             └── Got one? → Fight or reposition
```

---

*Your drop spot should match your playstyle. Aggressive? Land hot. Passive? Land edge. Improving? Rotate between both to develop all your skills.*
