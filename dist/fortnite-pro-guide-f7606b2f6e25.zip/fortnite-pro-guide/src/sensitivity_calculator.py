#!/usr/bin/env python3
"""
Sensitivity Calculator for Battle Royale Games

Helps you find your ideal mouse sensitivity based on your hardware,
physical setup, and playstyle preferences. Also converts sensitivity
between different games so your muscle memory stays consistent.

Usage:
    python3 sensitivity_calculator.py

The calculator will walk you through a series of questions and output
your recommended sensitivity settings.

Author: Game Vault
License: MIT
"""

import math
import json
import os
from typing import Optional


# =============================================================================
# CONSTANTS
# =============================================================================

# Standard field of view values for popular games (horizontal FOV at 16:9)
GAME_FOV_DEFAULTS: dict[str, float] = {
    "fortnite": 80.0,
    "valorant": 103.0,
    "apex_legends": 110.0,
    "overwatch": 103.0,
    "csgo": 106.26,
    "call_of_duty": 80.0,
    "pubg": 103.0,
}

# Sensitivity coefficients for converting between games
# These represent how each game translates raw mouse input to in-game rotation.
# The "yaw" value = degrees of rotation per count at sensitivity 1.0
GAME_YAW_VALUES: dict[str, float] = {
    "fortnite": 0.5585,    # Fortnite uses percentage-based sens (X% of 0.5585 deg/count)
    "valorant": 0.07,      # Valorant is very precise, low yaw per count
    "apex_legends": 0.022, # Apex uses a different scale entirely
    "overwatch": 0.0066,   # Overwatch sensitivity is relative to 15 (default)
    "csgo": 0.022,         # CS sensitivity * 0.022 = deg/count
    "call_of_duty": 0.0066,
    "pubg": 0.002222,
}

# Common mouse DPI presets
COMMON_DPI_VALUES: list[int] = [400, 800, 1200, 1600, 3200]

# Sensitivity recommendation ranges based on playstyle
# Values are in cm/360 (centimeters of mouse movement for a full 360° turn)
PLAYSTYLE_CM360: dict[str, tuple[float, float]] = {
    "aggressive": (20.0, 35.0),     # Fast flicks, close-range fights
    "balanced": (30.0, 50.0),       # Mix of aim and building
    "precision": (40.0, 65.0),      # Long-range tracking, careful aim
    "controller_convert": (15.0, 30.0),  # Used to fast sens on controller
}


# =============================================================================
# CORE CALCULATIONS
# =============================================================================

def calculate_cm_per_360(dpi: int, game_sensitivity: float, game: str) -> float:
    """Calculate centimeters of mouse movement needed for a full 360° rotation.

    This is the universal sensitivity metric that works across all games.
    Two players with the same cm/360 will have the same physical mouse
    movement for the same in-game rotation, regardless of which game
    they're playing.

    Args:
        dpi: Mouse DPI (dots per inch)
        game_sensitivity: In-game sensitivity value
        game: Game identifier (must be a key in GAME_YAW_VALUES)

    Returns:
        Centimeters of mouse movement for a 360° rotation

    Raises:
        ValueError: If the game is not recognized
    """
    if game not in GAME_YAW_VALUES:
        raise ValueError(f"Unknown game: {game}. Supported: {list(GAME_YAW_VALUES.keys())}")

    yaw = GAME_YAW_VALUES[game]

    # degrees per mouse count = yaw * sensitivity
    degrees_per_count = yaw * game_sensitivity

    # counts per 360 = 360 / degrees_per_count
    counts_per_360 = 360.0 / degrees_per_count

    # inches per 360 = counts / DPI
    inches_per_360 = counts_per_360 / dpi

    # convert to cm (1 inch = 2.54 cm)
    cm_per_360 = inches_per_360 * 2.54

    return cm_per_360


def cm360_to_game_sensitivity(cm_per_360: float, dpi: int, game: str) -> float:
    """Convert a cm/360 value to an in-game sensitivity for a specific game.

    This is the reverse of calculate_cm_per_360. Use it to convert your
    sensitivity from one game to another.

    Args:
        cm_per_360: Target centimeters per 360° rotation
        dpi: Mouse DPI
        game: Target game identifier

    Returns:
        The in-game sensitivity value that achieves the target cm/360
    """
    if game not in GAME_YAW_VALUES:
        raise ValueError(f"Unknown game: {game}. Supported: {list(GAME_YAW_VALUES.keys())}")

    yaw = GAME_YAW_VALUES[game]
    inches_per_360 = cm_per_360 / 2.54
    counts_per_360 = inches_per_360 * dpi
    degrees_per_count = 360.0 / counts_per_360
    sensitivity = degrees_per_count / yaw

    return sensitivity


def calculate_edpi(dpi: int, game_sensitivity: float) -> float:
    """Calculate effective DPI (eDPI).

    eDPI = DPI × in-game sensitivity. It's a quick way to compare
    sensitivities between players using different DPI values.
    Note: eDPI is only meaningful within the same game.

    Args:
        dpi: Mouse DPI
        game_sensitivity: In-game sensitivity value

    Returns:
        Effective DPI value
    """
    return dpi * game_sensitivity


def recommend_sensitivity(
    playstyle: str,
    mousepad_width_cm: float,
    dpi: int,
    game: str,
) -> dict[str, float]:
    """Recommend a sensitivity based on playstyle and physical setup.

    Takes into account:
    - Playstyle preference (how you like to play)
    - Mousepad size (physical constraint on movement)
    - Current DPI (hardware setting)
    - Target game

    Args:
        playstyle: One of 'aggressive', 'balanced', 'precision', 'controller_convert'
        mousepad_width_cm: Width of mousepad in centimeters
        dpi: Mouse DPI setting
        game: Target game identifier

    Returns:
        Dictionary with recommended sensitivity values and analysis
    """
    if playstyle not in PLAYSTYLE_CM360:
        raise ValueError(f"Unknown playstyle: {playstyle}. Options: {list(PLAYSTYLE_CM360.keys())}")

    low_cm360, high_cm360 = PLAYSTYLE_CM360[playstyle]
    mid_cm360 = (low_cm360 + high_cm360) / 2

    # Constrain to mousepad: you should be able to do at least a 180° with
    # one full swipe of your mousepad (half the cm/360 value)
    # If the mousepad is too small for the recommended range, adjust upward
    min_viable_cm360 = mousepad_width_cm * 2  # need at least 180° per swipe
    if mid_cm360 > min_viable_cm360:
        # Mousepad is too small for this sensitivity — cap it
        mid_cm360 = min_viable_cm360
        low_cm360 = min(low_cm360, min_viable_cm360)
        high_cm360 = min(high_cm360, min_viable_cm360)

    # Calculate game-specific sensitivity values
    sens_low = cm360_to_game_sensitivity(high_cm360, dpi, game)  # higher cm360 = lower sens
    sens_mid = cm360_to_game_sensitivity(mid_cm360, dpi, game)
    sens_high = cm360_to_game_sensitivity(low_cm360, dpi, game)  # lower cm360 = higher sens

    return {
        "recommended_sensitivity": round(sens_mid, 4),
        "range_low": round(sens_low, 4),
        "range_high": round(sens_high, 4),
        "cm_per_360": round(mid_cm360, 1),
        "edpi": round(calculate_edpi(dpi, sens_mid), 1),
        "mousepad_constraint": mid_cm360 == min_viable_cm360,
    }


def convert_sensitivity(
    source_game: str,
    source_sensitivity: float,
    target_game: str,
    dpi: int,
) -> dict[str, float]:
    """Convert sensitivity from one game to another.

    Maintains the same physical mouse movement (cm/360) between games,
    so your muscle memory transfers perfectly.

    Args:
        source_game: Game you're converting FROM
        source_sensitivity: Your sensitivity in the source game
        target_game: Game you're converting TO
        dpi: Mouse DPI (same for both games)

    Returns:
        Dictionary with converted sensitivity and cm/360 values
    """
    # First, find the cm/360 of the source sensitivity
    cm360 = calculate_cm_per_360(dpi, source_sensitivity, source_game)

    # Then convert that cm/360 to the target game's sensitivity
    target_sens = cm360_to_game_sensitivity(cm360, dpi, target_game)

    return {
        "source_game": source_game,
        "source_sensitivity": source_sensitivity,
        "target_game": target_game,
        "target_sensitivity": round(target_sens, 4),
        "cm_per_360": round(cm360, 1),
        "dpi": dpi,
    }


# =============================================================================
# INTERACTIVE CLI
# =============================================================================

def print_header(text: str) -> None:
    """Print a formatted section header."""
    print(f"\n{'='*60}")
    print(f"  {text}")
    print(f"{'='*60}\n")


def get_int_input(prompt: str, valid_range: Optional[tuple[int, int]] = None) -> int:
    """Get an integer input from the user with validation."""
    while True:
        try:
            value = int(input(prompt))
            if valid_range and not (valid_range[0] <= value <= valid_range[1]):
                print(f"  Please enter a value between {valid_range[0]} and {valid_range[1]}")
                continue
            return value
        except ValueError:
            print("  Please enter a valid number.")


def get_float_input(prompt: str, valid_range: Optional[tuple[float, float]] = None) -> float:
    """Get a float input from the user with validation."""
    while True:
        try:
            value = float(input(prompt))
            if valid_range and not (valid_range[0] <= value <= valid_range[1]):
                print(f"  Please enter a value between {valid_range[0]} and {valid_range[1]}")
                continue
            return value
        except ValueError:
            print("  Please enter a valid number.")


def get_choice(prompt: str, options: list[str]) -> str:
    """Get a choice from a list of options."""
    while True:
        print(prompt)
        for i, option in enumerate(options, 1):
            print(f"  {i}. {option}")
        try:
            choice = int(input("\n  Your choice: "))
            if 1 <= choice <= len(options):
                return options[choice - 1]
            print(f"  Please enter 1-{len(options)}")
        except ValueError:
            print("  Please enter a valid number.")


def run_sensitivity_finder() -> None:
    """Interactive sensitivity recommendation wizard."""
    print_header("SENSITIVITY FINDER")
    print("  Answer a few questions and I'll recommend your ideal sensitivity.\n")

    # Get game
    games = list(GAME_YAW_VALUES.keys())
    game = get_choice("  Which game?", games)

    # Get DPI
    print(f"\n  Common DPI values: {COMMON_DPI_VALUES}")
    dpi = get_int_input("  Your mouse DPI: ", (100, 16000))

    # Get mousepad size
    mousepad_cm = get_float_input(
        "  Mousepad width in cm (measure it, or guess ~30-45cm): ",
        (10.0, 120.0),
    )

    # Get playstyle
    playstyle = get_choice(
        "\n  How do you play?",
        ["aggressive", "balanced", "precision", "controller_convert"],
    )

    # Calculate recommendation
    result = recommend_sensitivity(playstyle, mousepad_cm, dpi, game)

    print_header("YOUR RECOMMENDED SENSITIVITY")
    print(f"  Game:           {game}")
    print(f"  DPI:            {dpi}")
    print(f"  Playstyle:      {playstyle}")
    print(f"  Mousepad:       {mousepad_cm} cm")
    print()
    print(f"  ★ Recommended:  {result['recommended_sensitivity']}")
    print(f"    Range:        {result['range_low']} — {result['range_high']}")
    print(f"    cm/360:       {result['cm_per_360']} cm")
    print(f"    eDPI:         {result['edpi']}")

    if result["mousepad_constraint"]:
        print()
        print("  ⚠ NOTE: Your mousepad is on the small side for your playstyle.")
        print("    Consider a larger mousepad (40cm+) for more comfortable low-sens play.")

    print()
    print("  TIP: Start at the recommended value. Play 5 games. If you're")
    print("  overshooting, lower it 5-10%. If undershooting, raise it 5-10%.")
    print("  Then LOCK IT IN and don't change it for at least 2 weeks.")


def run_converter() -> None:
    """Interactive sensitivity converter between games."""
    print_header("SENSITIVITY CONVERTER")
    print("  Convert your sensitivity between games.\n")

    games = list(GAME_YAW_VALUES.keys())

    source_game = get_choice("  Convert FROM which game?", games)
    source_sens = get_float_input(
        f"  Your {source_game} sensitivity: ",
        (0.001, 100.0),
    )

    target_game = get_choice("\n  Convert TO which game?", games)

    dpi = get_int_input("  Your mouse DPI: ", (100, 16000))

    result = convert_sensitivity(source_game, source_sens, target_game, dpi)

    print_header("CONVERTED SENSITIVITY")
    print(f"  {result['source_game']}: {result['source_sensitivity']}")
    print(f"  → {result['target_game']}: {result['target_sensitivity']}")
    print(f"  cm/360: {result['cm_per_360']} cm (same in both games)")
    print(f"  DPI: {result['dpi']}")


def run_analyzer() -> None:
    """Analyze your current sensitivity."""
    print_header("SENSITIVITY ANALYZER")
    print("  Analyze your current sensitivity settings.\n")

    games = list(GAME_YAW_VALUES.keys())
    game = get_choice("  Which game?", games)
    sens = get_float_input(f"  Your {game} sensitivity: ", (0.001, 100.0))
    dpi = get_int_input("  Your mouse DPI: ", (100, 16000))

    cm360 = calculate_cm_per_360(dpi, sens, game)
    edpi = calculate_edpi(dpi, sens)

    print_header("ANALYSIS")
    print(f"  Game:      {game}")
    print(f"  Sens:      {sens}")
    print(f"  DPI:       {dpi}")
    print(f"  eDPI:      {round(edpi, 1)}")
    print(f"  cm/360:    {round(cm360, 1)} cm")

    # Categorize the sensitivity
    if cm360 < 20:
        category = "VERY HIGH (twitchy, mostly wrist aiming)"
    elif cm360 < 35:
        category = "HIGH (fast, wrist + some arm)"
    elif cm360 < 50:
        category = "MEDIUM (balanced, arm + wrist)"
    elif cm360 < 65:
        category = "LOW (precise, mostly arm aiming)"
    else:
        category = "VERY LOW (extremely precise, full arm movement)"

    print(f"  Category:  {category}")

    # Show equivalent in other games
    print("\n  Equivalent sensitivity in other games:")
    for other_game in games:
        if other_game != game:
            equiv_sens = cm360_to_game_sensitivity(cm360, dpi, other_game)
            print(f"    {other_game}: {round(equiv_sens, 4)}")


def export_settings(filename: str = "my_sensitivity.json") -> None:
    """Export sensitivity profile to a JSON file."""
    print_header("EXPORT SETTINGS")

    games = list(GAME_YAW_VALUES.keys())
    game = get_choice("  Which game?", games)
    sens = get_float_input(f"  Your {game} sensitivity: ", (0.001, 100.0))
    dpi = get_int_input("  Your mouse DPI: ", (100, 16000))

    cm360 = calculate_cm_per_360(dpi, sens, game)

    profile = {
        "primary_game": game,
        "sensitivity": sens,
        "dpi": dpi,
        "cm_per_360": round(cm360, 1),
        "edpi": round(calculate_edpi(dpi, sens), 1),
        "all_games": {},
    }

    for g in games:
        profile["all_games"][g] = round(cm360_to_game_sensitivity(cm360, dpi, g), 4)

    with open(filename, "w") as f:
        json.dump(profile, f, indent=2)

    print(f"\n  ✓ Saved to {filename}")
    print(f"    Your equivalent sensitivities across all games are included.")


def main() -> None:
    """Main entry point — presents the menu and runs the selected tool."""
    print_header("SENSITIVITY CALCULATOR")
    print("  Your one-stop tool for finding, analyzing, and converting")
    print("  mouse sensitivity across games.\n")

    while True:
        mode = get_choice(
            "\n  What would you like to do?",
            [
                "Find my ideal sensitivity",
                "Convert sensitivity between games",
                "Analyze my current sensitivity",
                "Export my sensitivity profile",
                "Quit",
            ],
        )

        if mode == "Find my ideal sensitivity":
            run_sensitivity_finder()
        elif mode == "Convert sensitivity between games":
            run_converter()
        elif mode == "Analyze my current sensitivity":
            run_analyzer()
        elif mode == "Export my sensitivity profile":
            export_settings()
        elif mode == "Quit":
            print("\n  GG! Happy gaming.\n")
            break


if __name__ == "__main__":
    main()
