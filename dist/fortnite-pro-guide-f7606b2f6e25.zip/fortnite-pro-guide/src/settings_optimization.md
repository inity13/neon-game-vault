# Settings Optimization Guide

> Get every possible frame. Reduce input lag. See enemies clearer. This guide covers everything.

## Table of Contents
1. [Video Settings](#video-settings)
2. [Audio Settings](#audio-settings)
3. [Input Settings](#input-settings)
4. [Keybind Optimization](#keybind-optimization)
5. [System-Level Tweaks](#system-level-tweaks)

---

## Video Settings

### Priority: FPS > Visual Quality

In competitive play, higher FPS = lower input lag = faster reactions. Target **at minimum** 144 FPS for competitive, 60 FPS for casual.

### Recommended Video Settings

| Setting | Competitive | Balanced | Quality |
|---------|------------|----------|---------|
| Window Mode | Fullscreen | Fullscreen | Fullscreen |
| Resolution | 1920×1080 | 1920×1080 | 1920×1080 |
| Frame Rate Limit | 240 or Unlimited | 165 | 60 |
| 3D Resolution | 100% | 100% | 100% |
| View Distance | Medium | Far | Epic |
| Shadows | Off | Medium | High |
| Anti-Aliasing | Off | Medium | High |
| Textures | Low | Medium | High |
| Effects | Low | Medium | High |
| Post Processing | Low | Medium | High |

### Why These Settings?

```
  FPS IMPACT BY SETTING:
  
  Shadows:        ████████████████████ (-40% FPS if Epic)
  Effects:        ██████████████ (-25% FPS if Epic)
  Post Processing:████████████ (-20% FPS if Epic)
  View Distance:  ██████ (-10% FPS if Epic)
  Anti-Aliasing:  ████████ (-15% FPS if Epic)
  Textures:       ████ (-5% FPS if Epic)
  
  ↑ Turn these OFF/LOW first for biggest FPS gains
```

**Shadows OFF is the single biggest competitive advantage.** Removing shadows:
- Gives you 30-40% more FPS
- Makes players easier to spot (no shadow hiding)
- Reduces visual clutter in build fights

**View Distance on Medium** — Players render at the same distance regardless of this setting. It only affects structures and terrain detail at extreme distances.

### Resolution Tricks

If you need more FPS, consider dropping to 1600×900 or 1280×720 before lowering 3D resolution. A full-resolution lower-res image looks better than a downscaled higher-res image.

```
  RESOLUTION vs FPS GAIN:
  
  1920×1080 (native): Baseline
  1600×900:           +20-30% FPS
  1280×720:           +50-70% FPS
  
  Note: Many competitive players use 1600×900 for the FPS boost
  while maintaining decent visual clarity.
```

---

## Audio Settings

### Sound Settings

| Setting | Recommended | Why |
|---------|-------------|-----|
| Master Volume | 60-80% | Protect your ears during long sessions |
| Music Volume | 0% | Distracting, adds no value in fights |
| Sound Effects | 100% | Footsteps, gunshots, build sounds |
| Voice Chat | 50-70% | Hear teammates without them drowning out game audio |
| Visualize Sound Effects | Personal preference | Shows sound direction on HUD |

### Audio Equipment Recommendations

```
  BEST FOR COMPETITIVE:
  1. Wired headphones (no wireless delay)
  2. Over-ear design (noise isolation)
  3. Open-back for soundstage (hearing direction)
  
  AVOID:
  × Speakers (can't hear directional audio)
  × Cheap earbuds (no bass for footsteps)
  × Bluetooth (adds 20-200ms audio delay)
```

### Sound Priority

What to listen for (in order of importance):
1. **Footsteps** — Enemy position and distance
2. **Building sounds** — What they're placing, how fast
3. **Gunshots** — Weapon type and direction
4. **Chest sounds** — Loot location (early game only)
5. **Storm sounds** — Storm proximity

---

## Input Settings

### Mouse Sensitivity

**The most personal setting in the game.** There's no "best" sensitivity, but there are ranges.

| Style | DPI | In-Game Sens | eDPI | Best For |
|-------|-----|-------------|------|----------|
| Low | 400 | 8-10% | 32-40 | Aim-heavy, tracking |
| Medium | 800 | 5-7% | 40-56 | Balanced (most players) |
| High | 1600 | 3-4% | 48-64 | Fast building, flick shots |

**eDPI = DPI × In-Game Sensitivity**

> Use the `sensitivity_calculator.py` script to find your ideal sensitivity based on your mouse and playstyle.

### Finding Your Sensitivity

**The PSA Method (Perfect Sensitivity Approximation):**

1. Set sensitivity so you can do a 360° turn with one full mousepad swipe
2. Play 3 games
3. If you're **overshooting** targets → lower sensitivity by 10%
4. If you're **undershooting** targets → raise sensitivity by 10%
5. Repeat until it feels natural

```
  SENSITIVITY FINDING PROCESS:
  
  Start high → Too twitchy? → Lower 10%
                             → Better? → Play 5 more games
                                        → Still overshooting? → Lower 5% more
                                        → Undershooting now? → Raise 2-3%
                                        → Feels right? → LOCK IT IN
```

**CRITICAL:** Once you find your sensitivity, **do not change it.** Muscle memory takes 1-2 weeks to build. Constantly changing sensitivity resets your progress.

### Build & Edit Sensitivity Multiplier

| Setting | Recommended Range |
|---------|------------------|
| Build Mode Multiplier | 1.5x - 2.0x |
| Edit Mode Multiplier | 1.3x - 1.8x |

Higher multipliers let you build/edit faster but require more precision. Start at 1.5x and increase as you get comfortable.

---

## Keybind Optimization

### Core Principles

1. **Every build piece should be one keypress** — No cycling through pieces
2. **Use mouse side buttons** for frequently used actions
3. **Keep movement keys (WASD) fingers free** during building

### Recommended Keybinds

| Action | Default | Recommended | Why |
|--------|---------|-------------|-----|
| Wall | - | Q | Index finger, fastest access |
| Floor | - | Mouse 5 | Thumb, doesn't move WASD hand |
| Ramp | - | Mouse 4 | Thumb, instant access |
| Cone | - | T / V | Easy reach from WASD |
| Edit | G | F | Much closer to WASD |
| Confirm Edit | Mouse 1 | Mouse 1 | Fastest confirmation |
| Reset Edit | - | Mouse wheel down | Instant reset, no delay |
| Trap | - | T / 5 | Less frequent, further key OK |
| Weapon Slot 1 | 1 | 1 | Number row fine for weapons |
| Weapon Slot 2 | 2 | 2 | |
| Weapon Slot 3 | 3 | 3 | |
| Weapon Slot 4 | 4 | Z or X | Easier reach than 4 |
| Weapon Slot 5 | 5 | C or V | Easier reach than 5 |
| Crouch | Ctrl | L-Ctrl or C | Need fast crouch for peeking |
| Sprint | Shift | Auto-Sprint ON | Free up your pinky |
| Use/Interact | E | E | Standard |

### The Finger Map

```
  KEYBOARD LAYOUT (left hand home position):
  
       [1][2][3][4][5]     ← Weapon slots
  [TAB][Q][W][E][R][T]    ← Q=Wall, E=Interact, R=Reload
  [CAPS][A][S][D][F][G]   ← F=Edit, WASD=Movement
  [SHFT][Z][X][C][V][B]   ← Z/X/C=Extra weapon slots
  [CTRL]      [SPACE]     ← Ctrl=Crouch, Space=Jump
  
  RIGHT HAND (Mouse):
  [M4] = Ramp    [M5] = Floor
  [M1] = Shoot   [M2] = Aim
  [WHEEL] = Reset Edit
```

---

## System-Level Tweaks

### Windows Settings

| Setting | Where | Recommendation |
|---------|-------|---------------|
| Game Mode | Settings → Gaming | ON |
| Hardware-accelerated GPU scheduling | Settings → Display → Graphics | ON (if available) |
| Mouse acceleration | Control Panel → Mouse → Pointer Options | OFF (uncheck "Enhance pointer precision") |
| Power Plan | Control Panel → Power Options | High Performance |
| Background apps | Settings → Privacy → Background apps | OFF for unnecessary apps |

### GPU Driver Settings

**For NVIDIA (via NVIDIA Control Panel):**
| Setting | Value |
|---------|-------|
| Power Management Mode | Prefer Maximum Performance |
| Texture Filtering Quality | High Performance |
| Low Latency Mode | Ultra |
| Max Pre-Rendered Frames | 1 |
| Vertical Sync | Off |
| Threaded Optimization | On |

**For AMD (via Radeon Software):**
| Setting | Value |
|---------|-------|
| Anti-Lag | Enabled |
| Radeon Boost | Enabled |
| Image Sharpening | Enabled (70-80%) |
| VSync | Off |
| Frame Rate Target Control | Match monitor refresh + 3 |

### Reducing Input Lag

```
  INPUT LAG SOURCES:
  
  Mouse → USB Polling → OS → Game Engine → GPU Render → Display
  
  Optimize EACH step:
  1. Mouse: Use 1000Hz polling rate (1ms)
  2. USB: Use USB 3.0 port, not hub
  3. OS: Disable mouse acceleration, use Game Mode
  4. Game: Use low latency mode, cap FPS at monitor refresh + 3
  5. GPU: Use NVIDIA Reflex or AMD Anti-Lag
  6. Display: Use low response time mode, disable VSync
```

---

*Performance is a competitive advantage. A player with 240 FPS and 5ms input lag will beat an equally skilled player with 60 FPS and 50ms input lag in fast-paced fights.*
