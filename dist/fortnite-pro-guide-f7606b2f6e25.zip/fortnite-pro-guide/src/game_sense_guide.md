# Game Sense Guide — Thinking Like a Pro

> Mechanics get you kills. Game sense gets you wins.

## What Is Game Sense?

Game sense is the ability to make the right decision at the right time based on incomplete information. It's:
- Knowing when to push and when to hold
- Predicting where enemies will be
- Managing resources (health, mats, ammo) for the long game
- Positioning yourself to survive, not just to fight

---

## The Decision Framework

Every second in a BR game, you're making decisions. Here's the framework pros use:

```
  CURRENT SITUATION
        │
        ▼
  ┌─────────────────┐
  │ Do I NEED to     │
  │ fight right now? │
  ├────────┬────────┤
  │  YES   │   NO   │
  └───┬────┴───┬────┘
      │        │
      ▼        ▼
  ┌────────┐ ┌──────────┐
  │ FIGHT  │ │ Can I get │
  │(see    │ │ an easy   │
  │ combat │ │ advantage?│
  │ rules) │ ├─────┬────┤
  └────────┘ │ YES │ NO │
             └──┬──┴──┬─┘
                │     │
                ▼     ▼
           ┌──────┐ ┌──────┐
           │ENGAGE│ │ROTATE│
           │smart │ │quietly│
           └──────┘ └──────┘
```

### When You NEED to Fight
- Enemy is blocking your rotation path
- Storm is pushing you into them
- They've seen you and are pushing
- You're in a box and they're breaking in

### When You DON'T Need to Fight
- You can rotate around them without being seen
- You're low on mats or health
- Third parties are nearby and will push the fight
- You're already in a good zone position

---

## Positioning Tiers

### Height Advantage

```
  HEIGHT ADVANTAGE:
  
  HIGH GROUND (BEST):
  ┌─────────┐
  │  YOU ↓  │  ← Can see everything, shoot down
  └────┬────┘
       │
  ┌────┴────┐
  │ ENEMY ↑ │  ← Has to look up, exposed while building
  └─────────┘
  
  Why it matters:
  - You see more of their body (bigger target)
  - They see less of yours (smaller target)
  - Gravity helps your shots, hurts theirs
  - You control when to engage
```

### Cover Priority

```
  BEST COVER:
  1. Natural terrain (hills, rocks) — Can't be destroyed
  2. Brick/metal builds — Takes time to break
  3. Wood builds — Fast to place, but breaks easily
  4. No cover — You're dead
  
  ┌─────┐
  │ROCK │  Natural cover = infinite HP
  │     │  You can peek left/right without using mats
  │  @  │
  └─────┘
```

---

## Combat IQ

### The Third-Party Rule

> In any fight, assume a third team is watching and waiting for both of you to be weak.

```
  YOUR FIGHT:           THIRD PARTY:
  
  You ←→ Enemy          ??? watching from 100m away
  
  After fight:
  You (75 HP, no mats)  Third party: (200 HP, max mats)
                         → They push → You're dead
```

**Counter-strategies:**
1. **End fights fast** — Don't drag out a fight. 15 seconds max if possible.
2. **Box and heal** immediately after a kill. Don't loot first.
3. **Be aware** of gunshot sounds during your fight. If you hear shooting nearby, someone's coming.
4. **Use the third party** — If you see two teams fighting, wait for one to get knocked and push the survivor.

### Damage Trading

Every shot you take should deal MORE damage than you receive. If you're taking 50-50 trades (you hit them, they hit you), you're playing wrong.

```
  GOOD TRADE:                 BAD TRADE:
  
  You: peek → 100 dmg → hide  You: stand in open → 80 dmg
  Enemy: 0 dmg to you         Enemy: 80 dmg to you
  
  Net: +100 for you            Net: 0 (both took damage)
```

**How to win trades:**
- **Peek and shoot** — Don't stand in the open. Use edits to create quick peek windows.
- **Right-hand peek** — Your character model leans right. Peek from your right side for less exposure.
- **Pre-aim** — Know where the enemy is before you peek, so you fire immediately.

### The Right-Hand Peek Advantage

```
  RIGHT PEEK (GOOD):         LEFT PEEK (BAD):
  
  ┌────┐                     ┌────┐
  │    │  Only your head      │    │  Half your body
  │    │  is exposed          │    │  is exposed
  │    @ ←→ →                 @ → ←│
  │    │                     │    │
  └────┘                     └────┘
```

Your character model holds their weapon on the right side. When you peek from the right side of cover, only your head is visible. From the left side, your entire torso is exposed.

---

## Storm Management

### Storm Damage by Phase

| Phase | Damage/Tick | Total Time | Notes |
|-------|-------------|------------|-------|
| 1 | 1 HP/tick | 3:00 | Barely hurts, loot freely |
| 2 | 1 HP/tick | 2:30 | Still manageable with heals |
| 3 | 2 HP/tick | 2:00 | Getting dangerous |
| 4 | 5 HP/tick | 1:30 | Will kill you fast |
| 5 | 8 HP/tick | 1:00 | Sprint or die |
| 6+ | 10 HP/tick | 0:30 | You're dead if you're in it |

### Storm Rotation Decision Tree

```
  Storm is closing in. What do you do?
  │
  ├── Are you already in zone?
  │   ├── YES → Hold position. Let others come to you.
  │   └── NO → How far are you from zone?
  │       ├── Close (< 200m) → Walk in, save mats for fights
  │       ├── Medium (200-500m) → Rotate immediately, build as needed
  │       └── Far (> 500m) → SPRINT. Use vehicles. Accept storm damage.
  │
  └── Is anyone between you and zone?
      ├── YES → Can you go around them?
      │   ├── YES → Go around. Avoid the fight.
      │   └── NO → Push through fast. Don't stop to fight.
      └── NO → Clear path. Rotate confidently.
```

---

## Resource Management

### The Material Budget

Think of materials as a resource you spend:

| Situation | Material "Cost" |
|-----------|----------------|
| Basic 1×1 box | ~30 mats |
| Full box fight | ~200-500 mats |
| 90s (5 layers) | ~50 mats |
| Tunnel (5 tiles) | ~100 mats |
| Full build fight (aggressive) | ~300-800 mats |

**Budget rules:**
- **Early game:** Collect 300+ mats of each type before rotating
- **Mid game:** Try to maintain 500+ mats of at least one type
- **Late game (competitive):** You need 1500+ total mats for tunneling
- **After every fight:** Farm immediately to replenish

### Ammo Management

| Ammo Type | Minimum to Carry | Comfortable Amount |
|-----------|------------------|-------------------|
| Light | 120 | 200+ |
| Medium | 90 | 150+ |
| Heavy | 12 | 24+ |
| Shells | 15 | 25+ |
| Rockets | 6 | 12+ |

---

## Endgame Strategy

### When There Are 10 Players Left

```
  PRIORITY LIST:
  
  1. ✅ Be IN zone, not rotating TO zone
  2. ✅ Have max mats (or close to it)
  3. ✅ Have full health + shields
  4. ✅ Have a loadout you're comfortable with
  5. ✅ Know where at least 2-3 other players are
  6. ✅ Have natural cover or a strong build
```

### When There Are 5 Players Left

- **Stop taking unnecessary fights.** Every fight drains resources.
- **Track other players.** Sound cues, build sounds, gunshots.
- **Hold your position.** Let others fight each other.
- **Only push** if someone is one-shot or if you have overwhelming advantage.

### When There Are 2 Players Left (1v1)

```
  Pre-Fight Checklist:
  ┌──────────────────────────────┐
  │ □ Full shields? (200 HP)     │
  │ □ Mats available? (300+)     │
  │ □ Shotgun loaded?            │
  │ □ Know their position?       │
  │ □ Have height advantage?     │
  └──────────────────────────────┘
  
  If YES to all → Push aggressively
  If NO to any → Play defensive, make them come to you
```

---

## Common Mistakes (And How to Fix Them)

| Mistake | Why Players Do It | The Fix |
|---------|-------------------|---------|
| W-keying every fight | Adrenaline, wanting kills | Ask "do I NEED this fight?" before pushing |
| Building too high | Trying to always get height | 3 layers max. Higher = more fall damage risk |
| Not healing after fights | Rush to loot | Box up → heal → THEN loot |
| Panic building | Getting shot scares you | Practice building under pressure in creative |
| Tunnel vision | Focused on one enemy | Check surroundings every 3-5 seconds |
| Over-peeking | Wanting to finish the kill | One shot, duck. One shot, duck. Repeat. |
| Not farming | Think it's boring | Farm while rotating, hit every tree/rock you pass |
| Changing sensitivity | Think the sens is the problem | Lock it in. The problem is practice, not settings. |

---

*Game sense develops with experience. You can't learn it from a guide alone — but you CAN learn the framework for making better decisions. Apply these principles every game and you'll see results within a week.*
