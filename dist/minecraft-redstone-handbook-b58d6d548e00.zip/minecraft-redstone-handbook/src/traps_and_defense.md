# Traps & Defense — Protect Your Base

---

## Trap #1: TNT Landmine

```
  SURFACE:          UNDERGROUND:
  ┌────┐            ┌────┐
  │PRPL│ ← Pressure │PRPL│
  ├────┤   plate    ├────┤
  │SAND│            │TNT │ ← TNT under the sand
  ├────┤            ├────┤
  │    │            │TNT │ ← Stack for more damage
  └────┘            └────┘
```

Sand/gravel falls when TNT explodes below, creating a crater.

## Trap #2: Arrow Hallway

```
  SIDE VIEW:
  
  [D]  .  .  .  .  .  [D]     D = Dispenser (with arrows)
   █  .  .  .  .  .   █      █ = Solid block
  [D]  .  .  .  .  .  [D]     . = Walkway
   █  .  .  .  .  .   █
  [D]  .  .  .  .  .  [D]
   █  .  .  .  .  .   █
  
  Pressure plate at entrance triggers all dispensers via redstone.
  Player walks in → arrows from both sides.
```

## Trap #3: Hidden Pitfall

```
  BEFORE:                AFTER (triggered):
  ┌────────────┐        ┌────────────┐
  │ P  ████████│        │ P         │
  │    ████████│  →     │     ▼▼▼▼ │  ← Pistons retract floor
  │    ████████│        │          │
  └────────────┘        └────┬─────┘
                              │ FALL
                              ▼
                         [LAVA / DEEP PIT]
  
  P = Pressure plate (triggers the trap)
  █ = Floor blocks on sticky pistons
```

## Trap #4: Lava Curtain

```
  [D] [D] [D] [D]    D = Dispenser filled with lava buckets
   .   .   .   .
   .   .   .   .     Trigger = tripwire across doorway
   .   .   .   .     Dispensers dump lava → wall of lava falls
   ▓   ▓   ▓   ▓     ▓ = Lava streams
  
  Use a clock circuit to toggle dispensers:
  - Pulse 1: Dispensers place lava
  - Pulse 2: Dispensers pick lava back up (reset)
```

## Trap #5: Suffocation Trap

```
  [P→] .  .  [←P]     P = Sticky piston with block
   █   .  .   █
  [P→] .  .  [←P]     When triggered, pistons extend
   █   .  .   █       → blocks close in → player suffocates
  
  TRIGGER:
  Pressure plate → redstone → all pistons fire simultaneously
```

## Trap #6: Cobweb Trap + Cactus

```
  TOP VIEW:
  
  █ . . . . . █
  . C W W W C .    C = Cactus (on sand)
  . W . . . W .    W = Cobweb
  . W . P . W .    P = Pressure plate trigger
  . W . . . W .    █ = Solid walls
  . C W W W C .
  █ . . . . . █
  
  Player triggers plate → falls into cobweb area
  Cobwebs slow them to a crawl
  Cactus around edges deals contact damage
  They can't escape before dying
```

## Trap #7: Fake Floor (Carpet on String)

```
  SIDE VIEW:
  
  Looks normal:           What's underneath:
  ┌────────────┐          ┌────────────┐
  │ CARPET     │          │ CARPET     │
  │ STRING     │          │ STRING ──→ │ triggers dispenser/piston
  │            │          │     ↓↓↓    │
  │            │          │   [PIT]    │
  └────────────┘          └────────────┘
  
  String can hold carpet tiles.
  When player walks on carpet, they break the string.
  String breaking = block update = observer detects = trap fires.
```

---

## Defense Systems

### Perimeter Alarm

```
  TRIPWIRE across all entrances:
  
  [HOOK]────string────string────string────[HOOK]
     │                                        │
     └───────────●───●───[NOTE BLOCK]────────┘
                         plays sound when
                         someone crosses
```

### Auto-Arrow Turret

```
  [OBSERVER] → [DISPENSER with arrows]
       │             ↑
       │         facing outward
       │
  Detects any block change
  (player placing/breaking blocks nearby)
  → fires arrows at the area
  
  Add a clock for continuous firing:
  [OBSERVER]─[REPEATER]─┐
       ↑                  │
       └──────────────────┘
       (creates a loop = continuous pulses)
```

### Iron Door Airlock

```
  Two iron doors, only one can be open at a time:
  
  [DOOR 1] ← Button 1
     │
  [CHAMBER]    ← Small room between doors
     │
  [DOOR 2] ← Button 2
  
  Wire so Button 1 opens Door 1 AND closes Door 2
  And Button 2 opens Door 2 AND closes Door 1
  
  Uses RS Latch to remember which door should be open.
```

---

*Always test your traps in creative mode first. A trap that kills you instead of the intruder is just embarrassing.*
