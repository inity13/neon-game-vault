# Automatic Farms — Set It and Forget It

> Build once, harvest forever. These designs are tested and optimized.

---

## Farm #1: Automatic Sugar Cane Farm

**Difficulty:** ⭐ (Beginner)
**Resources needed:** 8 pistons, 8 observers, water, redstone dust, building blocks
**Output:** ~120 sugar cane per hour

### How It Works
Observers detect when sugar cane grows to 3 blocks tall, then pistons break the middle block. Items fall into water stream → hopper → chest.

### Schematic (Top View, One Module)

```
  LAYER 1 (Ground level):
  
  W = Water, S = Sand/Dirt, H = Hopper, C = Chest
  
  ┌───────────────────────┐
  │ C  H  W  W  W  W  W  │
  │ .  .  S  .  S  .  S  │  ← Sugar cane grows on sand
  │ .  .  █  .  █  .  █  │  ← Solid blocks behind
  └───────────────────────┘
  
  LAYER 2 (One block up):
  
  P = Piston (facing sugar cane), O = Observer (facing sugar cane)
  
  ┌───────────────────────┐
  │ .  .  .  .  .  .  .  │
  │ .  .  .  .  .  .  .  │  ← Sugar cane grows here
  │ .  .  P  .  P  .  P  │  ← Pistons push cane
  └───────────────────────┘
  
  LAYER 3 (Two blocks up):
  
  ┌───────────────────────┐
  │ .  .  .  .  .  .  .  │
  │ .  .  .  .  .  .  .  │
  │ .  .  O  .  O  .  O  │  ← Observers detect growth
  └───────────────────────┘
```

### Build Steps
1. Dig a trench 1 deep, 1 wide for water collection
2. Place hopper at one end → chest
3. Place water at the other end (flows toward hopper)
4. Place sand blocks next to water for sugar cane
5. Place pistons behind sand, facing the cane
6. Place observers above pistons, facing the cane
7. Connect observer outputs to pistons (they auto-connect vertically)
8. Plant sugar cane on sand

---

## Farm #2: Automatic Wheat/Carrot/Potato Farm

**Difficulty:** ⭐⭐ (Intermediate)
**Resources needed:** 1 villager (farmer), hoppers, chests, water, farmland
**Output:** ~400 items per hour

### How It Works
A farmer villager automatically plants and harvests crops. When their inventory is full, they throw items at another villager — but we intercept with hoppers.

### Schematic (Side View)

```
  ┌─────────────────────────────┐
  │  [FARMER VILLAGER]          │
  │   walks on farmland         │
  │  ┌─────────────────────┐    │
  │  │  F  F  F  F  F  F   │    │  F = Farmland
  │  │  W        W         │    │  W = Water (under slab)
  │  │  F  F  F  F  F  F   │    │
  │  └─────────┬───────────┘    │
  │            │                 │
  │     [HOPPER MINECART]       │  ← Under farmland, catches drops
  │            │                 │
  │      [HOPPER] → [CHEST]     │
  └─────────────────────────────┘
```

### Top View (9×9 farm module)

```
  █ █ █ █ █ █ █ █ █
  █ F F F F F F F █
  █ F F F F F F F █
  █ F F F F F F F █
  █ F F F W F F F █  ← Water in center under a slab
  █ F F F F F F F █
  █ F F F F F F F █
  █ F F F F F F F █
  █ █ █ █ █ █ █ █ █
  
  Below the farmland: rail with hopper minecart
  Below the rail: hopper → chest
```

### Key Details
- The farmer villager needs to have seeds in their inventory
- They'll plant crops, wait for growth, harvest, then replant
- Place a composter near the farmer — this assigns them the "farmer" profession
- Light the farm with torches/glowstone (crops need light level 8+)
- Build walls 2 blocks high around the farm to keep the villager contained

---

## Farm #3: Iron Golem Farm

**Difficulty:** ⭐⭐⭐ (Advanced)
**Resources needed:** 3 villagers, 3 beds, zombie, water, lava, hoppers
**Output:** ~300 iron ingots per hour

### How It Works
Villagers scared by a zombie spawn iron golems. Golems fall into a kill chamber (lava), and hoppers collect the drops.

```
  SIDE VIEW:
  
  ┌─────────────────────────┐
  │   😱 😱 😱              │  ← 3 Villagers (scared)
  │   🛏 🛏 🛏              │  ← 3 Beds
  │                          │
  │         🧟               │  ← Zombie (name-tagged so it won't despawn)
  │   ┌─────────────┐       │
  │   │   SPAWN     │       │  ← Iron golems spawn on this platform
  │   │   AREA      │       │
  │   └──────┬──────┘       │
  │          │ water push    │
  │          ▼               │
  │   ┌──────────────┐      │
  │   │  🔥 LAVA 🔥  │      │  ← Kill chamber
  │   └──────┬───────┘      │
  │          │               │
  │   [HOPPER] → [CHEST]    │  ← Collection
  └─────────────────────────┘
```

### Critical Details
- Zombie MUST be name-tagged (otherwise it despawns)
- Zombie must be behind glass/trapdoors (villagers need to see it but be safe)
- Villagers need line of sight to the zombie AND access to beds
- Spawn platform must be within 16 blocks of villagers
- Water streams push golems off spawn platform into lava
- Golems have 100 HP — lava kills them in ~15 seconds

---

## Farm #4: Mob Grinder (XP Farm)

**Difficulty:** ⭐⭐ (Intermediate)
**Resources needed:** Water, signs, trapdoors, hoppers
**Output:** ~300 XP per hour + mob drops

### How It Works
Dark rooms spawn hostile mobs. Water pushes them to a central hole. They fall and take damage. You finish them off for XP.

```
  TOP VIEW (one spawning platform):
  
  ┌──────────────────────────────┐
  │                              │
  │  W→→→→→→→→→→→→→→→→↓        │
  │  W→→→→→→→→→→→→→→→→↓        │
  │  W→→→→→→→→→→→→→→→→↓        │
  │  W→→→→→→→→→→→→→→→→↓        │  W = Water source
  │                    ↓  ← HOLE │  → = Water flow direction
  │  W→→→→→→→→→→→→→→→→↓        │  ↓ = Drop into hole
  │  W→→→→→→→→→→→→→→→→↓        │
  │  W→→→→→→→→→→→→→→→→↓        │
  │  W→→→→→→→→→→→→→→→→↓        │
  │                              │
  └──────────────────────────────┘
  
  SIDE VIEW:
  
  ┌──────────┐
  │ DARK ROOM│  ← Mobs spawn here (no light)
  │    W→→→↓ │
  └────────┬─┘
           │
           │  22 blocks fall (leaves mobs at 1 HP)
           │
           ▼
      ┌────────┐
      │  YOU   │  ← Hit once to kill, get XP
      │  HERE  │
      └────────┘
      [HOPPER] → [CHEST]  ← Auto-collects drops
```

### Fall Distance Guide

| Fall Height | Damage | Result |
|-------------|--------|--------|
| 22 blocks | 19 HP | Mobs at 1 HP (one-hit kill) |
| 23 blocks | 20 HP | Kills most mobs (no XP!) |
| 24+ blocks | Lethal | All mobs die (no XP!) |

**Use exactly 22 blocks** for XP farming. Mobs survive at 1 HP and you get XP from the killing blow.

---

## Farm #5: Auto Smelter (Furnace Array)

**Difficulty:** ⭐⭐ (Intermediate)
**Resources needed:** Furnaces, hoppers, chests
**Output:** Smelts items automatically, speed scales with furnace count

```
  SIDE VIEW (one smelter unit):
  
  [INPUT CHEST]
       │
  [HOPPER] ← feeds raw items
       │
  [FURNACE]  ← [HOPPER] ← [FUEL CHEST]
       │
  [HOPPER]
       │
  [OUTPUT CHEST]
```

### Scaled Array (8 furnaces for 8x speed)

```
  TOP VIEW:
  
  [INPUT CHEST]──[H]──[H]──[H]──[H]──[H]──[H]──[H]──[H]
                  │    │    │    │    │    │    │    │
                 [F]  [F]  [F]  [F]  [F]  [F]  [F]  [F]
                  │    │    │    │    │    │    │    │
                 [H]  [H]  [H]  [H]  [H]  [H]  [H]  [H]
                  │    │    │    │    │    │    │    │
  [OUTPUT CHEST]─[H]──[H]──[H]──[H]──[H]──[H]──[H]──[H]
  
  H = Hopper, F = Furnace
  Top row hoppers point DOWN into furnaces
  Bottom row hoppers point SIDEWAYS into output line
  Fuel hoppers feed from the side into each furnace
```

---

## Farm #6: Automatic Wool Farm (Per Color)

**Difficulty:** ⭐ (Beginner)
**Resources needed:** 1 sheep, observer, dispenser, shears, hopper, grass block
**Output:** ~60 wool per hour per sheep

```
  SIDE VIEW:
  
  [OBSERVER] ← watches grass block
       │
  [DISPENSER] ← contains shears, faces sheep
       │
  ┌────┴────┐
  │  🐑     │  ← Sheep on grass block
  │  GRASS  │  ← When sheep eats grass, observer fires
  └────┬────┘
  [HOPPER] → [CHEST]
```

### How it works:
1. Sheep stands on grass block
2. Sheep eats grass (block turns to dirt)
3. Observer detects the block change
4. Observer sends pulse to dispenser
5. Dispenser uses shears on sheep → wool drops
6. Hopper collects wool
7. Grass regrows → cycle repeats

---

## Farm #7: Pumpkin/Melon Auto Farm

**Difficulty:** ⭐ (Beginner)  
**Resources:** Observers, pistons, hoppers, water

```
  TOP VIEW (one row):
  
  █  O  P  .  S  W  S  .  P  O  █
  
  █ = Solid block
  O = Observer (facing the empty spot where pumpkin grows)
  P = Piston (facing the empty spot)
  . = Empty (pumpkin/melon grows here)
  S = Farmland with stem planted
  W = Water (hydrates farmland)
  
  SIDE VIEW:
  
  [O] [P→] [.] [S] [W] [S] [.] [←P] [O]
                 │               │
                 └───[HOPPER]───┘
                         │
                      [CHEST]
```

When pumpkin/melon grows, observer detects it → piston fires → breaks the fruit → item falls into hopper below.

---

## Farm #8: Chicken Cooker (Food Farm)

**Difficulty:** ⭐ (Beginner)
**Resources:** Hopper, dispenser, lava, slab, chest
**Output:** ~120 cooked chicken per hour

```
  SIDE VIEW:
  
  ┌─────────────┐
  │   🐔 🐔 🐔  │  ← Adult chickens (trapped on hopper)
  │  [HOPPER]   │  ← Collects eggs from chickens
  └──────┬──────┘
         │
  [DISPENSER]  ← Shoots eggs downward
         │
  ┌──────┴──────┐
  │   🐣 🐣     │  ← Baby chickens hatch from eggs
  │   [SLAB]    │  ← Slab: babies fit under, adults don't
  │   🔥 LAVA   │  ← Lava on slab: kills adults when they grow up
  │             │
  │  [HOPPER]  │  ← Collects cooked chicken + feathers
  └──────┬──────┘
      [CHEST]
```

### How it works:
1. Adult chickens lay eggs → fall into hopper
2. Hopper feeds dispenser
3. Dispenser shoots eggs → some hatch into baby chickens
4. Babies are small enough to stand under the slab
5. When babies grow into adults → they touch lava on the slab
6. Lava cooks them → drops cooked chicken
7. Hopper collects the cooked chicken

---

*Each farm can be expanded by duplicating modules side by side. Start small, verify it works, then scale up.*
