# Elevators — Going Up

---

## Elevator #1: Bubble Column (Easiest)

**Difficulty:** ⭐ | **Speed:** Fast | **No redstone needed!**

```
  SIDE VIEW:
  
  ┌──┐ ← Open top
  │↑↑│ ← Bubble column (soul sand = UP)
  │↑↑│
  │↑↑│
  │↑↑│
  │↑↑│    Water source blocks in EVERY space
  │↑↑│    Soul Sand at bottom = pushes up
  │SS│ ← Soul Sand
  └──┘
  
  For DOWN: Replace Soul Sand with Magma Block
  ┌──┐
  │↓↓│ ← Bubbles pull you down
  │↓↓│
  │MM│ ← Magma Block
  └──┘
```

### Build Steps
1. Build a 1×1 shaft as tall as needed
2. Place Soul Sand at the bottom
3. Fill EVERY block with water source (use kelp trick: plant kelp all the way up, then break it — converts flowing water to sources)
4. Step in at the bottom → shoots you up instantly

### The Kelp Trick
```
  Problem: Placing water sources one by one is tedious
  Solution:
  1. Place ONE water source at top → let it flow down
  2. Plant kelp from bottom to top (kelp converts flowing → source)
  3. Break all kelp
  4. Now every block is a water source!
  5. Place Soul Sand at bottom → instant bubble column
```

---

## Elevator #2: Piston Elevator

**Difficulty:** ⭐⭐⭐ | **Speed:** Medium | **Compact**

```
  SIDE VIEW (going up):
  
  Step 1:        Step 2:        Step 3:
  ┌────┐        ┌────┐         ┌────┐
  │    │        │    │         │ @  │ ← player pushed up
  │    │        │ @──┤←piston  │    │
  │ @  │        │    │         │    │
  │────│←floor  │────│         │────│
  └────┘        └────┘         └────┘
  
  Piston pushes player up one block at a time.
  Sequence: floor rises → piston pushes → new floor → repeat
```

### Wiring (Per Level)

```
  TOP VIEW of one level:
  
  [P→] @ .      P = Sticky piston (pushes player from behind)
   █  .  .       @ = Player standing here
   ●  R  ●      ● = Redstone dust
                 R = Repeater (timing)
  
  Signal comes from below, fires piston, 
  then passes up to next level with delay.
```

---

## Elevator #3: Slime Block Launcher

**Difficulty:** ⭐⭐ | **Speed:** VERY FAST | **Fun**

```
  SIDE VIEW:
  
     @ ← player launched into the air!
     ↑
     ↑
     ↑
  ┌─────┐
  │SLIME│ ← Slime block
  │ [P↑]│ ← Piston fires upward
  └─────┘
  
  Player stands on slime block.
  Piston fires → slime bounces player upward.
  More pistons = more height.
```

### Multi-Stage Launcher

```
  Stack slime + pistons for extreme height:
  
       @  ← LAUNCH!
       ↑
  ┌────┴────┐
  │  SLIME  │  ← Top slime catches and re-bounces
  │  [P↑]   │
  ├─────────┤
  │  SLIME  │  ← Middle bounce
  │  [P↑]   │
  ├─────────┤
  │  SLIME  │  ← First bounce
  │  [P↑]   │
  └─────────┘
  
  Fire pistons in sequence (bottom first, then middle, then top)
  using repeater delays. Player bounces higher each time.
```

### Landing System

What goes up must come down. Build a safe landing:

```
  LANDING OPTIONS:
  
  1. Water pool:     2. Slime blocks:    3. Cobwebs:
  ┌────────┐        ┌────────┐          ┌────────┐
  │WWWWWWWW│        │SSSSSSSS│          │CCCCCCCC│
  │ 1 deep │        │ bounce │          │ slow   │
  └────────┘        └────────┘          └────────┘
  
  Water = no fall damage if at least 1 deep
  Slime = bounces (fun but may overshoot)
  Cobwebs = slow descent (boring but safe)
```

---

## Elevator #4: Honey Block Elevator

**Difficulty:** ⭐⭐ | **Speed:** Slow but steady | **Silent**

```
  SIDE VIEW:
  
  Player sticks to honey and slides down slowly:
  
  │HH│ ← Honey blocks on wall
  │HH│
  │HH│    Player touches honey →
  │HH│    slides down at safe speed
  │HH│    (no fall damage)
  │HH│
  └──┘
  
  For going UP: Use piston + honey block to create
  a sticky platform that rises.
```

### Honey vs Slime

| Property | Honey | Slime |
|----------|-------|-------|
| Sticks to players | ✓ | ✓ (bounces) |
| Slows movement | ✓ | ✗ |
| Prevents fall damage | ✓ (slides) | ✓ (bounces) |
| Pushed by pistons | ✓ | ✓ |
| Sticks to each other | ✗ | ✗ |
| Sound | Silent | Boing! |

---

## Choosing the Right Elevator

| Need | Best Choice | Why |
|------|------------|-----|
| Simple, works in survival | Bubble Column | No redstone, just water + soul sand |
| Compact, any height | Piston Elevator | Fits in 2x2, works for any height |
| Speed + fun | Slime Launcher | Fastest, most entertaining |
| Stealth | Honey Elevator | Silent, hidden easily |
| Going DOWN safely | Bubble Column (magma) | Or just a water pool at the bottom |

---

*The bubble column elevator is the best for most situations. It's fast, cheap, and requires zero redstone knowledge. Use the others when you want style points.*
