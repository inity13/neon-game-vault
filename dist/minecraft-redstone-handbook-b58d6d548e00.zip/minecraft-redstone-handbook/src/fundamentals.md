# Redstone Fundamentals

> Everything you need to understand before building anything with redstone.

## Table of Contents
1. [What Is Redstone?](#what-is-redstone)
2. [Power Sources](#power-sources)
3. [Signal Transmission](#signal-transmission)
4. [Components](#components)
5. [Tick Timing](#tick-timing)
6. [Block Update Detection](#block-update-detection)

---

## What Is Redstone?

Redstone is Minecraft's electrical wiring system. It lets you:
- Automate tasks (farming, smelting, sorting)
- Build machines (doors, elevators, traps)
- Create logic circuits (like a real computer!)

Think of it like this:
```
  REAL WORLD          MINECRAFT
  ─────────           ─────────
  Wire             →  Redstone dust
  Battery          →  Redstone torch / block
  Switch           →  Lever / button / pressure plate
  Light bulb       →  Redstone lamp
  Motor            →  Piston
  Timer            →  Repeater / comparator
```

---

## Power Sources

### Active Power Sources (Always On)

| Source | Signal Strength | Notes |
|--------|----------------|-------|
| Redstone Block | 15 | Can be pushed by pistons! |
| Redstone Torch | 15 | Inverts signal (NOT gate) |
| Daylight Sensor | 0-15 | Varies with time of day |

### Triggered Power Sources (Player Activated)

| Source | Signal Strength | Duration | Notes |
|--------|----------------|----------|-------|
| Lever | 15 | Toggle (stays on/off) | Most reliable switch |
| Button (Stone) | 15 | 10 ticks (1 second) | Short pulse |
| Button (Wood) | 15 | 15 ticks (1.5 seconds) | Slightly longer |
| Pressure Plate (Stone) | 15 | While entity is on it | Players + mobs |
| Pressure Plate (Wood) | 15 | While entity is on it | + items + arrows |
| Pressure Plate (Heavy) | 1-15 | While entities on it | Strength = entity count |
| Pressure Plate (Light) | 1-15 | While entities on it | More sensitive |
| Tripwire Hook | 15 | While string is triggered | Good for traps |
| Observer | 15 | 1 tick pulse | Detects block changes |
| Target Block | 1-15 | 4 ticks | Strength = accuracy |

### Comparator-Read Sources

| Source | Signal Strength | What It Reads |
|--------|----------------|---------------|
| Chest | 0-15 | Fullness (items inside) |
| Furnace | 0-15 | Fuel + smelting progress |
| Brewing Stand | 0-15 | Bottles in slots |
| Hopper | 0-15 | Items inside |
| Cake | 0-14 | Slices remaining |
| Cauldron | 0-3 | Water level |
| Composter | 0-8 | Fill level |
| Item Frame | 0-8 | Rotation of item |
| Lectern | 1-15 | Page of book |
| Jukebox | 1-15 | Which disc is playing |

---

## Signal Transmission

### Redstone Dust

Dust carries signal up to 15 blocks, losing 1 strength per block.

```
  Signal strength at each position:
  
  [SOURCE]─15─14─13─12─11─10──9──8──7──6──5──4──3──2──1─[DEAD]
              ↑                                           ↑
         Full power                                   No power
```

**Dust placement rules:**
- Dust on a block powers the block BELOW it
- Dust goes up 1 block (must have air above)
- Dust goes down 1 block (falls off edge)
- Dust does NOT go up through solid blocks

```
  DUST GOING UP:                DUST GOING DOWN:
  
       ●  ← dust                ●  ← dust
      ┌─┐                       │
      │ │  ← block              └─┐
  ●───┘ │                        │ │  ← block
  ↑     └─                       │ └───●
  dust                            ↑
                                  dust falls down
```

### Repeaters

Repeaters do 3 things:
1. **Refresh signal** — Output is always strength 15
2. **Add delay** — 1-4 ticks (0.1-0.4 seconds)
3. **Isolate direction** — Signal only goes one way

```
  [SOURCE]──●●●●●●●●●●●●●●●──[REPEATER]──●●●●●●●●●●●●●●●──
  15 ......... signal fading ... 1   →  15 .... signal renewed
```

**Repeater delay settings** (right-click to cycle):
```
  1 tick:  ▶─    (0.1 seconds)
  2 ticks: ▶──   (0.2 seconds)
  3 ticks: ▶───  (0.3 seconds)
  4 ticks: ▶──── (0.4 seconds)
```

### Comparators

The most complex redstone component. Two modes:

**Compare Mode (front torch OFF):**
```
  SIDE INPUT ──→ ┌───┐
                 │ C │──→ OUTPUT
  REAR INPUT ──→ └───┘
  
  If REAR ≥ SIDE: Output = REAR signal strength
  If REAR < SIDE: Output = 0
```

**Subtract Mode (front torch ON):**
```
  SIDE INPUT ──→ ┌───┐
                 │ C │──→ OUTPUT = REAR - SIDE
  REAR INPUT ──→ └───┘
  
  Output = max(0, REAR - SIDE)
```

---

## Components

### Pistons

| Type | Pushes | Pulls | Push Limit | Sticky |
|------|--------|-------|------------|--------|
| Piston | ✓ | ✗ | 12 blocks | No |
| Sticky Piston | ✓ | ✓ | 12 blocks | Yes |

```
  PISTON (retracted):     PISTON (extended):
  ┌────┐                  ┌────┬─┐
  │ ▶  │                  │ ▶  │ │ ← pushes block
  └────┘                  └────┴─┘
```

**Can't push:**
- Obsidian, bedrock, end portal frames
- Extended pistons
- Enchanting tables, anvils
- Anything with a tile entity (chests, signs, banners, etc.)

### Hoppers

Move items between containers. 1 item every 4 ticks (0.4 seconds).

```
  CHEST (source)
    │
    ▼
  [HOPPER] ──→ CHEST (destination)
    │
    └── Points in the direction it outputs to
```

**Key behaviors:**
- Pulls from container ABOVE it
- Pushes to container it POINTS AT
- Powered hopper = LOCKED (stops transferring)
- Can feed into other hoppers (chain them)

### Dispensers vs Droppers

| | Dispenser | Dropper |
|---|-----------|---------|
| **Fires** projectiles | ✓ | ✗ |
| **Drops** items | ✓ (if not fireable) | ✓ (always) |
| **Places** water/lava | ✓ | ✗ |
| **Equips** armor | ✓ | ✗ |
| **Uses** flint & steel | ✓ | ✗ |
| **Feeds** into containers | ✗ | ✓ |

---

## Tick Timing

### What Is a Redstone Tick?

1 redstone tick = 0.1 seconds = 2 game ticks

```
  TIME:  0.0s   0.1s   0.2s   0.3s   0.4s   0.5s
         │      │      │      │      │      │
  TICKS: 0      1      2      3      4      5
```

### Component Delays

| Component | Delay | Notes |
|-----------|-------|-------|
| Redstone dust | 0 ticks | Instant (but has update order) |
| Repeater (1 setting) | 1 tick | Minimum delay |
| Repeater (4 setting) | 4 ticks | Maximum delay |
| Comparator | 1 tick | In both modes |
| Piston (extend) | 0 ticks* | Instant but 1-tick to retract |
| Piston (retract) | 1 tick | |
| Observer | 1 tick pulse | 1 tick on, then off |
| Torch | 1 tick | To turn on or off |
| Note block | 0 ticks | Instant |
| Redstone lamp | 0 tick on / 2 tick off | Turns off with delay |

*Pistons extend "instantly" but the animation takes 1.5 ticks visually.

### Building a Clock

A clock sends pulses at regular intervals. Here's a simple 4-tick clock:

```
  TOP VIEW:
  
  ┌──[REPEATER 2-tick]──┐
  │                      │
  ●──[REPEATER 2-tick]──●
  
  Total loop: 4 ticks = 0.4 seconds per pulse
```

**Common clock speeds:**

| Clock Type | Period | Use Case |
|------------|--------|----------|
| Observer clock | 2 ticks | Fastest, for rapid firing |
| 2-repeater | 4 ticks | Dispensers, droppers |
| 4-repeater | 8 ticks | Moderate speed |
| Hopper clock | Variable | Adjustable, use for long delays |
| Daylight clock | 24000 ticks | Once per day |

---

## Block Update Detection (BUD)

A BUD switch detects when a neighboring block changes state without being directly powered.

```
  HOW BUD WORKS:
  
  1. Piston is in a "should be powered" state
     but hasn't received an update yet
  
  2. When ANY neighboring block changes, the
     piston checks its power → realizes it
     should fire → extends
  
  This lets you detect:
  - Block placement/destruction nearby
  - Water/lava flow changes
  - Plant growth
  - Snow accumulation
```

### Simple BUD Switch

```
  SIDE VIEW:
  
  [REDSTONE TORCH]
       │
  ┌────┴────┐
  │  BLOCK  │
  ├─────────┤
  │ PISTON ▶│──→ (detects block changes above piston)
  └─────────┘
```

The piston is quasi-powered (powered but not updated). When a block update happens nearby, the piston fires.

---

*Understanding these fundamentals is essential before building anything. Every machine in this handbook uses these concepts. If something isn't working, come back here and check your signal strength, timing, and component behavior.*
