# Logic Gates — The Building Blocks of Redstone

> Every redstone machine, no matter how complex, is built from these simple gates.

---

## NOT Gate (Inverter)

**What it does:** Output is ON when input is OFF, and vice versa.

**Truth table:**
| Input | Output |
|-------|--------|
| OFF | ON |
| ON | OFF |

**Build (simplest):**
```
  SIDE VIEW:
  
  INPUT ──→ [BLOCK] ──→ OUTPUT
                │
            [TORCH]  ← torch on side of block
  
  When input powers the block, the torch turns OFF.
  When input is off, the torch stays ON.
```

**Layer-by-layer:**
```
  Layer 1 (ground):
  ● ● ● ● ●
  ↑ dust   ↑ dust (output)
  
  Layer 2:
        █       ← solid block
        T       ← torch on block (facing output)
```

**Use cases:** Inverted doors, "everything off" switches, part of other gates

---

## OR Gate

**What it does:** Output is ON if ANY input is ON.

**Truth table:**
| Input A | Input B | Output |
|---------|---------|--------|
| OFF | OFF | OFF |
| ON | OFF | ON |
| OFF | ON | ON |
| ON | ON | ON |

**Build:**
```
  TOP VIEW:
  
  INPUT A ──●──┐
                ├──●── OUTPUT
  INPUT B ──●──┘
  
  Just merge two redstone dust lines. That's it.
```

**Use cases:** Multiple switches controlling one door, any "either/or" logic

---

## AND Gate

**What it does:** Output is ON only if ALL inputs are ON.

**Truth table:**
| Input A | Input B | Output |
|---------|---------|--------|
| OFF | OFF | OFF |
| ON | OFF | OFF |
| OFF | ON | OFF |
| ON | ON | ON |

**Build:**
```
  TOP VIEW:
  
  INPUT A ──→ [BLOCK A] ──T──┐
                              ├──●── OUTPUT
  INPUT B ──→ [BLOCK B] ──T──┘
  
  T = torch on block (each is a NOT gate)
  Both torches merge into one wire → another NOT gate
  
  Complete circuit:
  
  INPUT A ──→ █──T──┐
                    ├──→ █──T──→ OUTPUT
  INPUT B ──→ █──T──┘
```

This is really: NOT(NOT A OR NOT B) = A AND B (De Morgan's law!)

**Layer-by-layer (3 wide):**
```
  Layer 1 (ground):
  ● . ●    ← input A (left), input B (right)
  . . .
  . ● .    ← merged dust
  . . .
  . ● .    ← output
  
  Layer 2 (blocks + torches):
  █ . █    ← solid blocks
  T . T    ← torches (pointing inward toward center)
  . . .
  . █ .    ← solid block
  . T .    ← torch (pointing toward output)
```

**Use cases:** Two-key locks, security systems, conditional triggers

---

## NOR Gate

**What it does:** Output is ON only if NO inputs are ON. (Inverted OR)

**Truth table:**
| Input A | Input B | Output |
|---------|---------|--------|
| OFF | OFF | ON |
| ON | OFF | OFF |
| OFF | ON | OFF |
| ON | ON | OFF |

**Build:**
```
  TOP VIEW:
  
  INPUT A ──●──┐
                ├──→ [BLOCK] ──T──→ OUTPUT
  INPUT B ──●──┘
  
  Just an OR gate followed by a NOT gate (torch on block).
```

**Use cases:** "All clear" indicators, alarm systems

---

## NAND Gate

**What it does:** Output is OFF only if ALL inputs are ON. (Inverted AND)

**Truth table:**
| Input A | Input B | Output |
|---------|---------|--------|
| OFF | OFF | ON |
| ON | OFF | ON |
| OFF | ON | ON |
| ON | ON | OFF |

**Build:**
```
  TOP VIEW:
  
  INPUT A ──→ [BLOCK] ──T──┐
                            ├──●── OUTPUT
  INPUT B ──→ [BLOCK] ──T──┘
  
  Same as the first half of an AND gate, but WITHOUT the final inverter.
  Each torch inverts its input, then they merge (OR).
  NOT A OR NOT B = NAND (De Morgan's law again!)
```

**Use cases:** Default-on systems that disable when conditions are met

---

## XOR Gate (Exclusive OR)

**What it does:** Output is ON if inputs are DIFFERENT.

**Truth table:**
| Input A | Input B | Output |
|---------|---------|--------|
| OFF | OFF | OFF |
| ON | OFF | ON |
| OFF | ON | ON |
| ON | ON | OFF |

**Build (comparator method — compact):**
```
  TOP VIEW:
  
  INPUT A ──→ [COMPARATOR A] ──→ OUTPUT
                    ↑
  INPUT B ──→ ●──●──┘ (side input)
                │
                └──→ [COMPARATOR B] ──→ OUTPUT
                          ↑
  INPUT A ──→ ●──●──●──●──┘ (side input)
  
  Two comparators in subtract mode, outputs merged.
```

**Build (torch method — larger but no comparators):**
```
  Layer 1:
  A ● . . ● . ● O
  . . . . . . . .
  B ● . . ● . . .
  
  Layer 2:
  . . █ . . . . .
  . . T . █ . . .
  . . . . T . . .
  
  (A and B are inputs, O is output)
  Uses 4 torches and careful wiring.
```

**Use cases:** Toggle switches (press button to flip state), alternating systems

---

## XNOR Gate (Exclusive NOR)

**What it does:** Output is ON if inputs are the SAME.

**Truth table:**
| Input A | Input B | Output |
|---------|---------|--------|
| OFF | OFF | ON |
| ON | OFF | OFF |
| OFF | ON | OFF |
| ON | ON | ON |

**Build:** XOR gate + NOT gate on the output.

**Use cases:** Combination locks (all switches must match the code)

---

## Pulse Circuits

### Monostable Circuit (Pulse Generator)

Converts a continuous signal into a single short pulse.

```
  INPUT (lever) ──→ [REPEATER] ──→ [BLOCK] ──T──→ OUTPUT (pulse)
                         ↑              │
                         └──────────────┘
  
  When input turns ON:
  1. Signal goes through repeater (delayed)
  2. Torch turns off
  3. But the initial signal already passed → one pulse
```

### Pulse Extender

Makes a short pulse last longer.

```
  INPUT ──→ [REPEATER 4-tick] ──→ [REPEATER 4-tick] ──→ OUTPUT
  
  Chain repeaters to extend: each adds 1-4 ticks of delay.
  Total extension = sum of all repeater delays.
```

### T Flip-Flop (Toggle)

Converts a button press into a toggle (on/off state).

```
  BUTTON ──→ [PULSE GENERATOR] ──→ [DROPPER] ⇄ [DROPPER]
                                        │
                                   [COMPARATOR] ──→ OUTPUT
  
  How it works:
  - Two droppers face each other, one has an item
  - Each pulse moves the item to the other dropper
  - Comparator reads if the item is there → outputs signal
  - Press button: item moves → output toggles
```

---

## RS Latch (Memory)

Stores a bit of information. Has SET and RESET inputs.

```
  SET ──→ [BLOCK] ──T──────┐
                            ├──→ OUTPUT (Q)
  RESET ──→ [BLOCK] ──T──┐ │
                          └─┼──→ OUTPUT (NOT Q)
                            │
  (Cross-connected torches) │
```

**Truth table:**
| Set | Reset | Output |
|-----|-------|--------|
| ON | OFF | ON (latched) |
| OFF | OFF | Holds last state |
| OFF | ON | OFF (reset) |
| ON | ON | Undefined (avoid!) |

**Use cases:** Memory cells, lock states, door open/close tracking

---

## Combination Lock Example

Using XNOR gates to check if multiple levers match a code:

```
  CODE:    ON  OFF  ON  ON  (hidden, set by builder)
  
  LEVER 1 ──→ [XNOR] ──┐
                        │
  LEVER 2 ──→ [XNOR] ──┼──→ [AND GATE] ──→ DOOR OPENS
                        │
  LEVER 3 ──→ [XNOR] ──┤
                        │
  LEVER 4 ──→ [XNOR] ──┘
  
  Each XNOR checks: does this lever match the code?
  AND gate checks: do ALL levers match?
  Only when all 4 match → door opens.
  
  4 levers = 16 possible combinations
  6 levers = 64 combinations
  8 levers = 256 combinations
```

---

*Master these gates and you can build anything. Every complex machine is just a combination of these basic circuits.*
