# Advanced Machines — Automate Everything

---

## Machine #1: Item Sorter

Automatically sorts items into labeled chests. One of the most useful machines in the game.

### How It Works
```
  INPUT                SORTING MODULE              OVERFLOW
  ──────              ──────────────              ────────
  
  Items flow through hopper line →
  Each module checks for ONE item type →
  If match: item drops into chest below →
  If no match: continues to next module →
  Unsorted items end up in overflow chest
  
  [INPUT CHEST]
       │
  [H]→[H]→[H]→[H]→[H]→[H]→[OVERFLOW CHEST]
       │    │    │    │    │
      [H]  [H]  [H]  [H]  [H]  ← Filter hoppers
       │    │    │    │    │
      [C]  [C]  [C]  [C]  [C]  ← Sorted chests
   Diamond Iron Gold Coal Wood
```

### One Sorting Module (Side View)

```
  ──[HOPPER (top line)]──→
           │
     [HOPPER (filter)]  ← Contains: 1 target item + filler items
           │
     [COMPARATOR]──→[REDSTONE TORCH]──→[HOPPER LOCK]
           │                                   │
     [CHEST]                             (locks top hopper
                                          when empty, unlocks
                                          when filter matches)
```

### Filter Hopper Setup

This is the critical part. The filter hopper must contain:
- **Slot 1:** The item you want to sort (e.g., 1 diamond)
- **Slots 2-5:** 1 filler item each (renamed items work best — they won't stack with anything)

```
  FILTER HOPPER CONTENTS:
  ┌────┬────┬────┬────┬────┐
  │ 💎 │ F  │ F  │ F  │ F  │
  │ x1 │ x1 │ x1 │ x1 │ x1 │
  └────┴────┴────┴────┴────┘
  💎 = Item to sort
  F  = Filler (renamed item that won't match anything)
  
  WHY: Comparator reads the hopper's fullness.
  With this setup, signal = 1 (barely anything).
  When matching items enter, signal = 2+
  → comparator triggers → unlocks the output hopper
  → matching items flow down into the chest.
```

---

## Machine #2: Automatic Smelter Array

8 furnaces working in parallel. Smelts 8x faster than a single furnace.

```
  TOP VIEW:
  
  [INPUT]─[H]─[H]─[H]─[H]─[H]─[H]─[H]─[H]
               │    │    │    │    │    │    │    │
              [F]  [F]  [F]  [F]  [F]  [F]  [F]  [F]
               │    │    │    │    │    │    │    │
  [OUTPUT]─[H]─[H]─[H]─[H]─[H]─[H]─[H]─[H]
  
  [FUEL]──[H]──┼────┼────┼────┼────┼────┼────┼
               ↓    ↓    ↓    ↓    ↓    ↓    ↓    ↓
              [F]  [F]  [F]  [F]  [F]  [F]  [F]  [F]
  
  H = Hopper, F = Furnace
  
  Top line distributes raw items → into furnaces (from above)
  Fuel line feeds each furnace (from the side)
  Bottom line collects smelted items (from below)
```

### Key Details
- Items distribute evenly because hoppers transfer one item at a time to the next
- Use coal blocks as fuel (9x longer than coal, more efficient per slot)
- The last furnace in line gets items last — build extras if needed

---

## Machine #3: Clock Circuits

### Hopper Clock (Adjustable Timer)

```
  [HOPPER A] ⇄ [HOPPER B]
       │              │
  [COMPARATOR]   [COMPARATOR]
       │              │
       ●──── OUTPUT ──●
  
  Items bounce between the two hoppers.
  More items = shorter cycle time.
  Comparator reads when items arrive → pulse.
```

**Timing table:**
| Items in System | Cycle Time |
|----------------|------------|
| 1 item | ~4 seconds |
| 5 items | ~2 seconds |
| 10 items | ~1 second |
| 20 items | ~0.5 seconds |
| Full stack (64) | ~0.2 seconds |

### Repeater Clock (Fixed Speed)

```
  [R→]─●─[R→]─●─┐
  ↑               │
  └───●─[←R]─●──┘
  
  R = Repeater (set to desired delay)
  Total period = sum of all repeater delays × 2
  
  Example: 4 repeaters at 4-tick = 16 tick cycle (1.6 seconds)
```

### Observer Clock (Fastest)

```
  [O→] [←O]     Two observers facing each other
   │      │      They detect each other's state change
   └──────┘      → infinite loop → 2-tick clock
  
  Attach output redstone to either observer's back.
```

---

## Machine #4: Automatic Storage System

Combines item sorter + chest labeling + overflow management.

### Architecture

```
  [INPUT HOPPER LINE]
  ┌──────────────────────────────────────────┐
  │ Sort → Sort → Sort → Sort → ... → Overflow│
  │  │       │       │       │              │   │
  │ [D]     [D]     [D]     [D]           [D]  │
  │ [D]     [D]     [D]     [D]           [D]  │
  └──────────────────────────────────────────┘
  
  Each 'Sort' = sorting module (see Machine #1)
  [D] = Double chest (connected by hopper underneath sorter)
  
  Categories:
  Module 1-3:   Building blocks (stone, wood, dirt, etc.)
  Module 4-6:   Ores & minerals (iron, gold, diamond, etc.)
  Module 7-9:   Food & farming (wheat, carrots, etc.)
  Module 10-12: Combat (swords, armor, arrows, etc.)
  Module 13+:   Miscellaneous
  Overflow:     Everything that doesn't match a filter
```

### Expansion Tips
- Build in a straight line for easy expansion
- Leave space for new modules at the end
- Put the overflow chest at the END of the line (catch-all)
- Label chests with item frames for visual identification

---

## Machine #5: Automatic Crop Replanter

Using dispensers + observers to auto-harvest and replant.

```
  SIDE VIEW:
  
  [OBSERVER] watches crop below
       │
  [DISPENSER] contains bone meal
       │
  ┌────┴────┐
  │  CROP   │  ← When crop is fully grown:
  │ FARMLAND│     Observer detects → dispenser fires water
  └────┬────┘     Water breaks crop → items drop
  [HOPPER] → [CHEST]    Farmland stays → crop can be replanted
```

### Full Auto Version (with Villager)
```
  [VILLAGER FARMER]
       │ plants + harvests
       ▼
  [FARMLAND with CROPS]
       │ items fall
       ▼
  [HOPPER MINECART on RAIL]
       │ collects items
       ▼
  [HOPPER] → [CHEST]
```

---

## Machine #6: Redstone Computer (Concept)

Yes, you can build a working computer in Minecraft. Here's the architecture:

```
  ┌──────────────────────────────────┐
  │          REDSTONE CPU            │
  ├─────────┬─────────┬──────────────┤
  │  ALU    │ MEMORY  │   CONTROL    │
  │(logic   │(RS      │  (clock +    │
  │ gates)  │ latches)│   sequencer) │
  ├─────────┴─────────┴──────────────┤
  │          I/O                      │
  │  Input: Levers    Output: Lamps  │
  └──────────────────────────────────┘
  
  ALU = Arithmetic Logic Unit
    → Uses AND, OR, XOR gates for math
    → Can add, subtract, compare numbers
  
  MEMORY = Storage
    → RS Latches store bits (0 or 1)
    → 8 latches = 1 byte = values 0-255
  
  CONTROL = Brain
    → Clock ticks through program steps
    → Decoder reads instruction → activates correct circuit
  
  This is REAL computing. Same principles as actual CPUs.
  Just... made of blocks. And very, very large.
```

**Realistic expectations:**
- 4-bit adder: ~100 blocks, 30 minutes to build
- 8-bit calculator: ~1000 blocks, several hours
- Full computer with programs: 10,000+ blocks, weeks/months

---

*These machines are the endgame of redstone engineering. Once you can build an item sorter and auto-smelter, you've mastered the practical side. Everything beyond that is just showing off (and that's half the fun).*
