# Hidden Doors — Secret Entrances and Piston Doors

---

## Door #1: 2×1 Piston Door (Flush)

**Difficulty:** ⭐ (Beginner) | **Blocks used:** 2 sticky pistons, 2 redstone, 1 button/lever

The simplest hidden door. Two blocks retract into the wall.

```
  CLOSED:                    OPEN:
  ┌──┬──┬──┐                ┌──┬──┬──┐
  │  │██│  │                │  │  │  │
  │  │██│  │                │  │  │  │
  └──┴──┴──┘                └──┴──┴──┘
       ↑ door blocks              ↑ blocks pulled into walls
  
  TOP VIEW (mechanism):
  
  [P→]██[←P]     P = Sticky piston
    ↑      ↑      ██ = Door blocks
   ●─[LEVER]─●    ● = Redstone dust
```

### Build Steps
1. Place 2 sticky pistons facing each other, 2 blocks apart
2. Place door blocks on the piston faces
3. Run redstone from a lever to both pistons
4. Flip lever → pistons retract → door opens

---

## Door #2: 2×2 Piston Door (Flush)

**Difficulty:** ⭐⭐ (Intermediate) | **Blocks:** 4 sticky pistons, repeaters, redstone

```
  FRONT VIEW:
  ┌──┬──┐
  │██│██│  ← top pair (pulled up by pistons above)
  │██│██│  ← bottom pair (pulled down by pistons below)
  └──┴──┘
  
  SIDE VIEW (mechanism):
  
       [P↓]        ← Sticky piston pulling top block up
        ██          ← Top door block
        ██          ← Bottom door block
       [P↑]        ← Sticky piston pulling bottom block down
  
  Both sides mirror this arrangement.
```

### Wiring (Top View)

```
  Layer at piston level:
  
  ● ● [R→] ● ● [P] █ [P] ● ● [←R] ● ●
                      │
                   [LEVER]
  
  R = Repeater (adds delay so pistons fire in sequence)
  P = Sticky piston
  █ = Door block
```

### Timing
Bottom pistons fire first (pull blocks down), then top pistons fire (pull blocks up). Use repeaters to create the 1-tick delay between them.

---

## Door #3: 3×3 Piston Door

**Difficulty:** ⭐⭐⭐ (Advanced) | **A classic challenge build**

```
  FRONT VIEW:
  ┌──┬──┬──┐
  │██│██│██│
  │██│  │██│  ← Center column uses different mechanism
  │██│██│██│
  └──┴──┴──┘
  
  Opening sequence:
  
  Step 1:         Step 2:         Step 3:
  ┌──┬──┬──┐     ┌──┬──┬──┐     ┌──┬──┬──┐
  │██│██│██│     │  │██│  │     │  │  │  │
  │██│  │██│     │  │  │  │     │  │  │  │
  │██│██│██│     │  │██│  │     │  │  │  │
  └──┴──┴──┘     └──┴──┴──┘     └──┴──┴──┘
  
  Side blocks    Top/bottom      Center column
  retract        retract         retracts
```

### Layer-by-Layer Build Guide

**Layer 1 (Bottom, below door):**
```
  . . . . . . . . .
  . █ P P P P P █ .    P = Piston (facing up)
  . . . . . . . . .    █ = Solid block
  . █ ● ● ● ● ● █ .    ● = Redstone
  . . . . . . . . .
```

**Layer 2 (Door level - bottom row):**
```
  . . . . . . . . .
  . P ██ ██ ██ P .      P = Piston (facing inward)
  . . . . . . . . .    ██ = Door blocks
  . . . . . . . . .
```

**Layer 3 (Door level - middle row):**
```
  . . . . . . . . .
  . P ██ . ██ P .       Middle has gap (or door frame)
  . . . . . . . . .
```

**Layer 4 (Door level - top row):**
```
  . . . . . . . . .
  . P ██ ██ ██ P .
  . . . . . . . . .
```

**Layer 5 (Above door):**
```
  . . . . . . . . .
  . █ P P P P P █ .    P = Piston (facing down)
  . . . . . . . . .
  . █ ● ● ● ● ● █ .
  . . . . . . . . .
```

---

## Door #4: Jeb Door (Seamless 2×2)

**Difficulty:** ⭐⭐⭐ (Advanced) | **Named after a famous game developer's design**

The blocks retract into the floor and ceiling, making the door completely invisible when closed.

```
  CLOSED (invisible):     OPEN:
  ┌──┬──┬──┐              ┌──┬──┬──┐
  │██│██│██│              │██│  │██│
  │██│██│██│              │██│  │██│
  │██│██│██│              │██│  │██│
  └──┴──┴──┘              └──┴──┴──┘
       ↑ Can't tell                ↑ Door is open
       where door is
```

### Mechanism (Side View)

```
  Step 1: Pull blocks back     Step 2: Pull blocks up/down
  
  [P←]██ → [P←]  ██           [P←]    [P↑]
  [P←]██ → [P←]  ██           [P←]    ██  ← pulled up
                                        ██  ← pulled down
                               [P←]    [P↓]
```

Uses a 2-step sequence:
1. Sticky pistons pull door blocks BACK (into the wall)
2. Second set of pistons pulls blocks UP and DOWN (out of sight)

---

## Door #5: Hidden Bookshelf Door

**Difficulty:** ⭐⭐ (Intermediate) | **Perfect for secret rooms**

A bookshelf that swings open when you pull a hidden lever.

```
  CLOSED:                         OPEN:
  ┌──────────────────┐           ┌──────────────────┐
  │ 📚 📚 📚 📚 📚  │           │ 📚 📚    📚 📚  │
  │ 📚 📚 📚 📚 📚  │           │ 📚 📚    📚 📚  │
  │ 📚 📚 📚 📚 📚  │           │ 📚 📚    📚 📚  │
  └──────────────────┘           └──────────────────┘
                                          ↑ gap appears
```

### Build
Uses sticky pistons behind the bookshelf wall. Middle 2 bookshelves are on pistons that retract when activated.

### Hidden Activation Methods

| Method | Stealth Level | How |
|--------|--------------|-----|
| Lever behind painting | ★★★★★ | Place lever, then painting over it |
| Item frame rotation | ★★★★★ | Comparator reads item frame rotation |
| Hidden button | ★★★★ | Button on matching block color |
| Pressure plate | ★★★ | Under carpet (but anyone can trigger) |
| Daylight sensor | ★★★ | Opens at night automatically |
| Armor stand | ★★★★★ | Push armor stand on pressure plate |

### Item Frame Secret Switch

```
  WALL:
  ┌──────────┐
  │ 📖       │  ← Item frame with book
  │          │     Rotate book to specific position
  └──────────┘     = secret switch!
  
  BEHIND WALL:
  [ITEM FRAME] → [COMPARATOR] → signal strength depends on rotation
                                 → only correct rotation = correct signal
                                 → feeds into comparator check → opens door
```

---

## Door #6: 4×4 Vault Door

**Difficulty:** ⭐⭐⭐⭐⭐ (Expert) | **Mega project, impressive result**

```
  FRONT VIEW:
  ┌──┬──┬──┬──┐
  │██│██│██│██│
  │██│██│██│██│
  │██│██│██│██│
  │██│██│██│██│
  └──┴──┴──┴──┘
  
  Opening sequence (spiral retraction):
  
  Frame 1:       Frame 2:       Frame 3:       Frame 4:
  ┌──┬──┬──┬──┐ ┌──┬──┬──┬──┐ ┌──┬──┬──┬──┐ ┌──┬──┬──┬──┐
  │  │  │  │  │ │  │  │  │  │ │  │  │  │  │ │  │  │  │  │
  │██│██│██│██│ │  │██│██│  │ │  │  │  │  │ │  │  │  │  │
  │██│██│██│██│ │  │██│██│  │ │  │  │  │  │ │  │  │  │  │
  │██│██│██│██│ │██│██│██│██│ │  │██│██│  │ │  │  │  │  │
  └──┴──┴──┴──┘ └──┴──┴──┴──┘ └──┴──┴──┴──┘ └──┴──┴──┴──┘
  
  Outer ring     Next ring       Inner ring      Fully open
  retracts       retracts        retracts
```

This is a massive build requiring 20+ pistons, careful timing with repeaters, and significant space behind the wall. Follow the same principles as the 3×3 door but scaled up with layered timing.

**Tips for 4×4:**
- Build it in creative mode first to test the timing
- Use repeater chains to create the wave-like opening effect
- Each ring of blocks needs its own piston circuit with different delays
- Total opening time: ~1.5-2 seconds with proper timing

---

*Start with the 2×1 door to understand the basics, then work your way up. Every door uses the same principles — just more pistons and more careful timing.*
