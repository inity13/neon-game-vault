# Minecraft Redstone Handbook — Engineering Guide

> Master the logic of Minecraft. Build circuits, farms, hidden doors, traps, and elevators from scratch.

## What's Inside

- **Redstone Fundamentals** — Signal strength, tick timing, power sources, and how redstone actually works
- **Logic Gates** — AND, OR, NOT, XOR, NAND — build any circuit from these building blocks
- **Automatic Farms** — Sugar cane, wheat, iron golem, mob grinder designs with full schematics
- **Hidden Doors** — Piston doors from 2x1 to 4x4, jeb doors, flush designs
- **Traps & Defense** — TNT traps, arrow dispensers, lava floors, hidden pitfalls
- **Elevators** — Piston elevators, bubble columns, slime block launchers
- **Advanced Machines** — Item sorters, automatic smelters, clock circuits

## Quick Preview

### Redstone Signal Strength

Redstone signal travels 15 blocks from a power source, losing 1 strength per block:

```
[LEVER]─●─●─●─●─●─●─●─●─●─●─●─●─●─●─●
 15    14 13 12 11 10  9  8  7  6  5  4  3  2  1
 ← STRONG                              WEAK →
```

To extend signal, use a **repeater** every 15 blocks:
```
[LEVER]─●─●─●─●─●─●─●─●─●─●─●─●─●─●─●─[REPEATER]─●─●─●─●─●...
```

### Basic Logic Gates

| Gate | Inputs | Output | Minecraft Build |
|------|--------|--------|----------------|
| NOT | 1 | Inverts signal | Torch on block |
| AND | 2 | Both on → on | Two torches into one |
| OR | 2 | Either on → on | Two wires merge |
| XOR | 2 | One (not both) → on | Subtractor circuit |

*Full build schematics with layer-by-layer diagrams inside.*

## Files Included

| File | Description |
|------|-------------|
| `src/fundamentals.md` | Complete redstone mechanics reference |
| `src/logic_gates.md` | All logic gates with build diagrams |
| `src/automatic_farms.md` | 8 farm designs with schematics |
| `src/hidden_doors.md` | 6 door designs from simple to complex |
| `src/traps_and_defense.md` | 7 trap designs for base defense |
| `src/elevators.md` | 4 elevator designs for vertical transport |
| `src/advanced_machines.md` | Item sorters, smelters, clocks |
| `examples/signal_calculator.py` | Python tool to calculate signal paths |

## How to Use

1. **New to redstone?** Start with `src/fundamentals.md` — learn how signals work
2. **Know the basics?** Jump to `src/logic_gates.md` for the building blocks
3. **Want to build something specific?** Go straight to the relevant guide
4. **Use the signal calculator** to plan complex circuits before building

## License

MIT License — See LICENSE file.
