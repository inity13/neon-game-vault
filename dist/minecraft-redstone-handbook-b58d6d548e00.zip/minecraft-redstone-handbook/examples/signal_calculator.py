#!/usr/bin/env python3
"""
Redstone Signal Path Calculator

Calculates signal strength along a redstone path, accounting for
repeaters, comparators, and distance. Helps plan complex circuits
before building them in-game.

Usage:
    python3 signal_calculator.py

Author: Game Vault
License: MIT
"""

from typing import Optional


# =============================================================================
# CONSTANTS
# =============================================================================

MAX_SIGNAL_STRENGTH: int = 15
DUST_DECAY_PER_BLOCK: int = 1
REPEATER_OUTPUT_STRENGTH: int = 15


# =============================================================================
# SIGNAL PATH MODELING
# =============================================================================

class Component:
    """Represents a redstone component in a circuit path."""

    def __init__(self, name: str, component_type: str, distance_from_prev: int = 1):
        """Initialize a component.

        Args:
            name: Display name for this component
            component_type: One of 'source', 'dust', 'repeater', 'comparator',
                          'torch', 'lamp', 'piston', 'observer'
            distance_from_prev: Blocks of dust between this and the previous component
        """
        self.name = name
        self.component_type = component_type
        self.distance_from_prev = distance_from_prev

    def __repr__(self) -> str:
        return f"Component({self.name}, {self.component_type})"


def calculate_signal_path(
    components: list[Component],
    initial_strength: int = MAX_SIGNAL_STRENGTH,
) -> list[dict[str, int | str]]:
    """Calculate signal strength at each point along a redstone path.

    Simulates signal propagation through a series of components,
    accounting for distance decay and component behavior.

    Args:
        components: List of Component objects in order from source to end
        initial_strength: Starting signal strength (default 15)

    Returns:
        List of dicts with 'component', 'input_strength', 'output_strength',
        and 'status' for each component in the path
    """
    results: list[dict[str, int | str]] = []
    current_strength = initial_strength

    for i, comp in enumerate(components):
        # Calculate signal after traveling through dust to this component
        if i > 0:
            signal_after_travel = current_strength - (comp.distance_from_prev * DUST_DECAY_PER_BLOCK)
        else:
            signal_after_travel = current_strength

        input_strength = max(0, signal_after_travel)

        # Calculate output based on component type
        match comp.component_type:
            case "source":
                output = initial_strength
            case "dust":
                # Dust just passes the signal through (already decayed)
                output = input_strength
            case "repeater":
                # Repeaters refresh to 15 IF they receive any signal
                output = REPEATER_OUTPUT_STRENGTH if input_strength > 0 else 0
            case "comparator_compare":
                # In compare mode, outputs rear signal if rear >= side
                # (simplified: just passes through)
                output = input_strength
            case "comparator_subtract":
                # In subtract mode, outputs rear - side
                # (simplified: just passes through with some loss)
                output = max(0, input_strength - 1)
            case "torch":
                # Torch inverts: if input > 0, output = 0. If input = 0, output = 15
                output = 0 if input_strength > 0 else MAX_SIGNAL_STRENGTH
            case "lamp" | "piston":
                # These are endpoints — they activate if signal > 0
                output = input_strength  # passes signal through for chain
            case "observer":
                # Observer outputs a 1-tick pulse at strength 15
                output = MAX_SIGNAL_STRENGTH
            case _:
                output = input_strength

        status = "ACTIVE" if output > 0 else "DEAD"
        if comp.component_type in ("lamp", "piston") and input_strength > 0:
            status = "POWERED"
        elif comp.component_type in ("lamp", "piston"):
            status = "UNPOWERED"

        results.append({
            "component": comp.name,
            "type": comp.component_type,
            "distance": comp.distance_from_prev,
            "input_strength": input_strength,
            "output_strength": output,
            "status": status,
        })

        current_strength = output

    return results


def print_signal_path(results: list[dict]) -> None:
    """Pretty-print the signal path analysis."""
    print("\n" + "=" * 70)
    print("  SIGNAL PATH ANALYSIS")
    print("=" * 70)
    print(f"\n  {'Component':<25} {'Type':<15} {'Dist':<6} {'In':<5} {'Out':<5} {'Status'}")
    print(f"  {'─' * 25} {'─' * 15} {'─' * 6} {'─' * 5} {'─' * 5} {'─' * 10}")

    for r in results:
        # Visual signal bar
        bar = "█" * r["output_strength"] + "░" * (MAX_SIGNAL_STRENGTH - r["output_strength"])
        print(
            f"  {r['component']:<25} {r['type']:<15} {r['distance']:<6} "
            f"{r['input_strength']:<5} {r['output_strength']:<5} {r['status']}"
        )

    # Print visual path
    print(f"\n  Signal visualization:")
    print(f"  ", end="")
    for r in results:
        strength = r["output_strength"]
        if strength > 10:
            char = "●"  # strong
        elif strength > 5:
            char = "◐"  # medium
        elif strength > 0:
            char = "○"  # weak
        else:
            char = "✕"  # dead

        # Show distance with dashes
        if r["distance"] > 1:
            print("─" * (r["distance"] - 1), end="")
        print(char, end="")

    print()

    # Check for issues
    dead_signals = [r for r in results if r["output_strength"] == 0 and r["type"] not in ("torch",)]
    if dead_signals:
        print(f"\n  ⚠ WARNING: Signal dies at: ", end="")
        print(", ".join(r["component"] for r in dead_signals))
        print("    → Add a repeater before these points to refresh the signal!")


def interactive_builder() -> None:
    """Interactive circuit path builder."""
    print("\n" + "=" * 70)
    print("  INTERACTIVE CIRCUIT BUILDER")
    print("=" * 70)
    print("\n  Build your circuit component by component.")
    print("  The calculator will show signal strength at each point.\n")

    components: list[Component] = []
    component_types = [
        "source", "dust", "repeater", "torch",
        "comparator_compare", "comparator_subtract",
        "lamp", "piston", "observer",
    ]

    # First component is always a source
    components.append(Component("Power Source", "source", 0))
    print("  ✓ Added: Power Source (strength 15)\n")

    while True:
        print("  Add component:")
        for i, ct in enumerate(component_types[1:], 1):  # skip 'source'
            print(f"    {i}. {ct}")
        print(f"    0. Done (calculate path)")

        try:
            choice = int(input("\n  Choice: "))
        except ValueError:
            print("  Invalid input.")
            continue

        if choice == 0:
            break

        if not (1 <= choice <= len(component_types) - 1):
            print(f"  Please enter 0-{len(component_types) - 1}")
            continue

        comp_type = component_types[choice]

        name = input(f"  Name for this {comp_type} (or Enter for default): ").strip()
        if not name:
            name = f"{comp_type}_{len(components)}"

        try:
            dist = int(input("  Blocks of dust before this component (1-15): "))
            dist = max(1, min(15, dist))
        except ValueError:
            dist = 1

        components.append(Component(name, comp_type, dist))
        print(f"  ✓ Added: {name} ({comp_type}, {dist} blocks away)\n")

    if len(components) > 1:
        results = calculate_signal_path(components)
        print_signal_path(results)
    else:
        print("  No components added!")


def demo_circuits() -> None:
    """Show example circuit calculations."""
    print("\n" + "=" * 70)
    print("  EXAMPLE CIRCUITS")
    print("=" * 70)

    # Example 1: Simple long wire
    print("\n  --- Example 1: Long wire without repeater ---")
    components = [
        Component("Lever", "source", 0),
        Component("Dust (5 blocks)", "dust", 5),
        Component("Dust (5 blocks)", "dust", 5),
        Component("Dust (5 blocks)", "dust", 5),
        Component("Lamp", "lamp", 1),
    ]
    results = calculate_signal_path(components)
    print_signal_path(results)

    # Example 2: Wire with repeater
    print("\n\n  --- Example 2: Long wire WITH repeater ---")
    components = [
        Component("Lever", "source", 0),
        Component("Dust (10 blocks)", "dust", 10),
        Component("Repeater", "repeater", 1),
        Component("Dust (10 blocks)", "dust", 10),
        Component("Lamp", "lamp", 1),
    ]
    results = calculate_signal_path(components)
    print_signal_path(results)

    # Example 3: NOT gate
    print("\n\n  --- Example 3: NOT gate (inverter) ---")
    components = [
        Component("Lever (ON)", "source", 0),
        Component("Dust (3 blocks)", "dust", 3),
        Component("Torch (inverts)", "torch", 1),
        Component("Output dust", "dust", 3),
        Component("Lamp", "lamp", 1),
    ]
    results = calculate_signal_path(components)
    print_signal_path(results)

    # Example 4: Repeater chain
    print("\n\n  --- Example 4: Long-distance repeater chain ---")
    components = [
        Component("Lever", "source", 0),
        Component("Repeater 1", "repeater", 14),
        Component("Repeater 2", "repeater", 14),
        Component("Repeater 3", "repeater", 14),
        Component("Redstone Lamp", "lamp", 5),
    ]
    results = calculate_signal_path(components)
    print_signal_path(results)


def main() -> None:
    """Main menu."""
    print("\n" + "=" * 70)
    print("  REDSTONE SIGNAL CALCULATOR")
    print("=" * 70)
    print("\n  Plan your redstone circuits before building them!\n")

    while True:
        print("  Options:")
        print("    1. Interactive Circuit Builder")
        print("    2. See Example Circuits")
        print("    3. Quick Check: Will signal reach X blocks?")
        print("    4. Quit")

        try:
            choice = int(input("\n  Choice: "))
        except ValueError:
            continue

        match choice:
            case 1:
                interactive_builder()
            case 2:
                demo_circuits()
            case 3:
                try:
                    dist = int(input("  Distance in blocks: "))
                    strength = MAX_SIGNAL_STRENGTH - dist
                    if strength > 0:
                        print(f"  ✓ Signal reaches! Strength at {dist} blocks: {strength}/15")
                    else:
                        repeaters_needed = (dist - 1) // 14 + 1
                        print(f"  ✕ Signal dies at 15 blocks. You need {repeaters_needed} repeater(s).")
                except ValueError:
                    print("  Invalid number.")
            case 4:
                print("\n  Happy building!\n")
                break


if __name__ == "__main__":
    main()
