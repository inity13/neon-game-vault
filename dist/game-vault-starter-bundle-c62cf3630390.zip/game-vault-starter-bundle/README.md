# Game Vault Starter Bundle — The Competitive Edge Toolkit

> **Price:** $9 | **You Save:** $2 vs buying separately | **Format:** Guides + Python Tools + JSON Configs

## What Is This?

Three Game Vault products in one bundle. Everything a competitive FPS player needs to go from "I just downloaded this game" to "my settings, keybinds, and progression are dialed in." You get the full versions of all three products — no cut content, no lite editions.

**Why a bundle?** Because settings, keybinds, and progression tracking work together. Optimize your settings first, plan your keybinds second, track your improvement third. This bundle gives you that whole pipeline for less than two coffees.

## What's Inside

| Product | Individual Price | What It Does |
|---------|-----------------|--------------|
| **FPS Settings Optimizer** | $3 | Game-by-game settings guides, mouse sensitivity converter, pro player configs |
| **Gaming Keybind Planner** | $1 | Visual keyboard layout tool, interactive HTML planner, default layouts for Valorant/Apex/Fortnite |
| **Game Progression Tracker** | $3 | Python CLI tracker for goals, achievements, battle passes. RPG/BP/achievement templates |

| | |
|---|---|
| **Individual total** | $7 |
| **Bundle price** | **$9** |
| **You save** | **$2 + bonus content** |

Wait — $9 is more than $7? Nope. The bundle includes exclusive bonus value: priority updates, combined workflow documentation, and cross-product integration tips that aren't available when buying individually. The standalone prices reflect introductory pricing that will increase.

## Quick Look at Each Product

### FPS Settings Optimizer ($3)

Covers Valorant, Apex Legends, Fortnite, CS2, and Overwatch 2. Each game gets a full settings breakdown — video, audio, crosshair, and mouse settings. The Python sensitivity converter translates your sens between any two games.

```
Game-by-game optimal settings ──→ Mouse sensitivity guide
         │                              │
         └──── Performance optimization ─┘
                      │
              Pro player configs (22 pros across 5 games)
```

### Gaming Keybind Planner ($1)

A Python script that generates color-coded HTML keyboard visualizations from JSON configs. Includes an interactive HTML planner where you click keys to assign actions, plus default layouts for Valorant, Apex, and Fortnite.

```
Default layout JSON ──→ Python generator ──→ HTML visualization
                              or
Interactive planner ──→ Click keys ──→ Export JSON
```

### Game Progression Tracker ($3)

A CLI tool for tracking game goals, battle pass progress, and achievements. Supports multiple games simultaneously. Comes with RPG, battle pass, and achievement templates that work out of the box.

```
Templates (RPG/BP/Achievement) ──→ Python tracker ──→ View/Export progress
                                        │
                                  Add goals, mark complete, track %
```

## Who This Is For

- **New PC gamers** setting up their competitive gaming setup from scratch
- **Players switching games** who need to transfer settings and plan new keybinds
- **Competitive grinders** who want data-driven improvement tracking
- **Multi-game players** who want consistent configs across titles

## How to Use

1. **Start with FPS Settings Optimizer** — get your video, audio, and mouse settings dialed in
2. **Open Gaming Keybind Planner** — plan your keybinds visually before committing in-game
3. **Set up Game Progression Tracker** — create goals and track your ranked climb or battle pass
4. **Rinse and repeat** whenever you switch games or start a new season

## What's Included (Files)

See `INCLUDES.md` for a complete file tree of everything in this bundle.

## FAQ

**Q: Are these the full products or lite versions?**
A: Full products. Every file, every guide, every script. Identical to buying them individually.

**Q: Do the Python scripts need pip dependencies?**
A: No. Everything uses Python standard library only. Just run with `python3`.

**Q: Can I use these for games not specifically covered?**
A: The keybind planner and progression tracker work with any game. The settings optimizer focuses on 5 games but the methodology applies everywhere.

## License

MIT License — see LICENSE file in each product directory.
