# Game Vault Starter Bundle — Complete Contents

> 3 products, 18 files total

---

## 1. FPS Settings Optimizer

Optimal settings, sensitivity tools, and pro configs for competitive FPS games.

```
fps-settings-optimizer/
├── LICENSE
├── README.md
├── src/
│   ├── optimal_settings.md          # Game-by-game settings (Valorant, Apex, Fortnite, CS2, OW2)
│   ├── mouse_sensitivity_guide.md   # DPI, eDPI, cm/360 comprehensive guide
│   ├── performance_optimization.md  # OS tweaks, GPU settings, network optimization
│   └── sensitivity_converter.py     # Python CLI: convert sens between games, calc eDPI
└── examples/
    └── pro_settings.json            # 22 pro player settings across 5 games
```

**Highlights:**
- 5 games covered with full video/audio/mouse settings
- Sensitivity converter supports all major FPS titles
- Pro player configs include TenZ, Aceu, Mongraal, s1mple, and 18 more

---

## 2. Gaming Keybind Planner

Visual keyboard layout tool for planning and sharing keybinds.

```
gaming-keybind-planner/
├── LICENSE
├── README.md
├── src/
│   ├── keybind_planner.py           # Python script: JSON → HTML keyboard visualization
│   └── default_layouts/
│       ├── valorant.json            # Default Valorant keybinds
│       ├── apex.json                # Default Apex Legends keybinds
│       └── fortnite.json            # Default Fortnite keybinds
├── demo/
│   └── index.html                   # Interactive HTML planner (click keys, export JSON)
└── preview/
    └── keyboard_layout.html         # Static preview: sample Valorant layout
```

**Highlights:**
- Interactive HTML planner — no server or internet required
- Color-coded keys by category (movement, combat, abilities, weapons, utility, comms)
- Export/import layouts as JSON for sharing or backup

---

## 3. Game Progression Tracker

CLI tool for tracking goals, battle passes, and achievements across games.

```
game-progression-tracker/
├── LICENSE
├── README.md
├── src/
│   ├── tracker_template.py          # Python CLI: create/track/view/export progression
│   └── templates/
│       ├── rpg_tracker.json         # Template for RPG progression (quests, levels, gear)
│       ├── battle_pass_tracker.json # Template for battle pass tracking (tiers, XP, rewards)
│       └── achievement_tracker.json # Template for achievement/trophy hunting
└── examples/
    └── sample_progression.json      # Filled-out Elden Ring example
```

**Highlights:**
- Argparse CLI with interactive mode — create trackers, add goals, mark complete
- Templates for RPG, battle pass, and achievement tracking
- Export to JSON for backup or sharing progress with friends

---

## Total File Count

| Product | Files |
|---------|-------|
| FPS Settings Optimizer | 7 |
| Gaming Keybind Planner | 8 |
| Game Progression Tracker | 7 |
| **Total** | **22** |

All files included. No lite versions, no cut content.
