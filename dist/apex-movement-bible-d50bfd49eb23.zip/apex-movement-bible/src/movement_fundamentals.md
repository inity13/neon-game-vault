# Movement Fundamentals — The Foundation of Every Movement God

## Table of Contents
1. [Why Movement Matters](#why-movement-matters)
2. [Sprint Mechanics](#sprint-mechanics)
3. [Slide Jumping](#slide-jumping)
4. [Bunny Hopping](#bunny-hopping)
5. [Momentum Management](#momentum-management)
6. [Air Strafing Basics](#air-strafing-basics)
7. [Climbing & Mantling](#climbing--mantling)
8. [Common Mistakes](#common-mistakes)

---

## Why Movement Matters

Here's the uncomfortable truth: **aim is capped, movement isn't.**

Your aim hits a ceiling based on your hardware, reaction time, and mouse control.
But movement tech? There's always another level. The best Apex players in the world
are still discovering new movement techniques years after launch.

```
THE FIGHT EQUATION:

  Player A: 90% aim accuracy, basic movement
  Player B: 70% aim accuracy, advanced movement

  Result: Player B wins 7/10 fights.

  WHY?
  - Player B is harder to hit (30-40% fewer shots land)
  - Player B controls positioning (forces unfavorable angles)
  - Player B escapes bad situations (resets the fight)
  - Player B closes distance faster (dictates engagement range)
```

Movement isn't just about looking cool. It directly translates to:
- **Taking less damage** (harder to track = fewer hits landed on you)
- **Better positioning** (faster rotations = better angles)
- **More escape options** (wall bounces = directions enemies don't expect)
- **Higher confidence** (knowing you can escape makes you play smarter)

---

## Sprint Mechanics

Sprinting seems basic, but there are details most players miss.

### How Sprint Works in Apex

```
SPEED VALUES (units per second):
  Walking:         144 u/s
  Sprinting:       299 u/s   (2.08x walking)
  Slide (flat):    346 u/s   (decays over time)
  Slide (downhill): 460+ u/s (can exceed sprint speed significantly)
  Slide-jump:      ~350 u/s  (maintains slide speed in the air)
```

### Auto-Sprint vs. Hold-to-Sprint

| Method | Pros | Cons |
|--------|------|------|
| Auto-sprint | One less key to hold, less finger fatigue | Can accidentally sprint when you want to walk quietly |
| Hold-to-sprint | Full control over when you sprint | Extra key to manage during fights |

**Our recommendation:** Use **auto-sprint ON**. The benefits outweigh the downsides.
When you need to walk silently, crouch-walk instead — it's quieter than regular walking anyway.

### Sprint Canceling

Sprinting locks you out of shooting for a brief moment. This matters in close-range fights.

```
SPRINT → SHOOT DELAY:

  Sprint + Fire: ~130ms delay before first shot
  Walk + Fire:   ~0ms delay (instant)
  
  WHAT THIS MEANS:
  - Don't sprint around corners in buildings
  - Don't sprint when you expect contact
  - Sprint BETWEEN fights, not DURING fights
  
  EXCEPTION:
  - Slide-canceling lets you maintain speed without the sprint delay
  - Jump → Slide → Jump = fast movement + instant weapon access
```

---

## Slide Jumping

Slide jumping is the FIRST advanced movement technique you should master. It's simple,
it's effective, and literally every good Apex player does it constantly.

### What Is a Slide Jump?

A slide jump combines a slide with a jump to maintain momentum. Instead of running
from A to B, you chain slide-jumps to move significantly faster.

```
REGULAR MOVEMENT:
  Run ──────────────────────────► Slow, predictable
  Speed: 299 u/s constant

SLIDE JUMPING:
  Run → Slide → Jump → Slide → Jump → Slide → Jump ──►
  Speed: 299 → 346 → 350 → 346 → 350 → repeat
  
  YOU'RE ~15-20% FASTER and way harder to hit.
```

### How to Slide Jump

```
INPUT SEQUENCE:
  1. Sprint forward (hold W)
  2. Press Crouch (C or Left Ctrl)      — starts the slide
  3. IMMEDIATELY press Jump (Space)      — launches you forward
  4. When you land, repeat from step 2
  
  TIMING:
  ─── Sprint ───┃ Slide ┃ Jump ───── Air ─────┃ Land ┃ Slide ┃ Jump ──
                  ↑ Crouch  ↑ Space                     ↑ Crouch  ↑ Space
                  
  The gap between Crouch and Space should be ~50-100ms.
  Too fast: you jump without sliding (waste of height)
  Too slow: you lose momentum (the slide decays)
```

### Slide Jump Settings

**Crouch setting matters here:**

| Setting | How It Works | Best For |
|---------|-------------|----------|
| Hold to Crouch | Crouch while held, stand when released | Slide-jumping (release after jump) |
| Toggle Crouch | Press once to crouch, press again to stand | General gameplay |

**Pro tip:** Many movement players use **Hold to Crouch** because it makes slide-jumping
more fluid — you naturally uncrouch when you release the key mid-jump.

### Flat vs Downhill Slide Jumps

Slide jumps on slopes are **significantly faster** than on flat ground.

```
FLAT GROUND:
  Slide speed: 346 u/s → decays to ~200 u/s over 1.5s
  Jump speed:  ~350 u/s (preserves current slide speed)

DOWNHILL:
  Slide speed: 346 u/s → ACCELERATES up to 460+ u/s
  Jump speed:  Preserves the boosted speed!
  
  THIS IS WHY: Smart players take downhill paths whenever possible.
  Even a slight downhill slope gives you free speed.

UPHILL:
  Slide speed: 346 u/s → decays to ~100 u/s FAST
  Jump speed:  Barely moves you forward
  
  RULE: Never slide uphill. Sprint + jump is faster going up.
```

---

## Bunny Hopping

Bunny hopping (b-hopping) in Apex is NOT like CS2. You won't gain infinite speed.
But it's still incredibly useful for one thing: **maintaining speed while healing.**

### What Bunny Hopping Does in Apex

```
NORMAL HEALING:
  Pop a heal → Locked to walking speed (144 u/s)
  Enemy: "Free kill, thanks"
  
BUNNY HOP HEALING:
  Pop a heal → Slide → Jump → Air strafe → Land → Jump → Repeat
  You maintain ~250-300 u/s while healing
  Enemy: "Why won't this person stand still??"
```

### How to Bunny Hop

```
INPUT SEQUENCE:
  1. Sprint forward and build momentum
  2. Start your heal (syringe, cell, etc.)
  3. Slide (Crouch) → Jump
  4. In the air: let go of W, hold A or D
  5. Move your mouse slightly in the direction you're strafing
  6. When you land, jump again IMMEDIATELY
  7. Alternate between A and D each hop
  
  TIMING:
  ─ Sprint ─┃ Heal ┃ Slide+Jump ┃ Air (hold A, mouse left) ┃ Jump ┃ Air (hold D, mouse right) ┃ Jump ─
              ↑ Pop heal   ↑ Crouch+Space                      ↑ Space                            ↑ Space
  
  KEY RULE: Do NOT hold W during bunny hops.
  W overrides the air strafe and kills your momentum.
```

### Why You Lose Speed (Common Mistakes)

```
❌ HOLDING W:
   W input fights against your strafe direction.
   Your speed drops from 300 → 200 → 150 → walking speed.
   FIX: Release W the moment you start the first hop.

❌ JUMPING TOO LATE:
   Each frame on the ground = friction = speed loss.
   If you wait even 100ms after landing, you lose ~30 u/s.
   FIX: Jump on the EXACT frame you touch the ground.

❌ NOT MOVING THE MOUSE:
   Air strafing requires mouse input + strafe key together.
   Just holding A without moving the mouse = no strafe.
   FIX: Gently sweep your mouse in the strafe direction.

❌ OVER-ROTATING THE MOUSE:
   Moving the mouse too fast makes you spiral and lose speed.
   FIX: Slow, smooth mouse movements. Think "steering a boat."
```

---

## Momentum Management

The secret to advanced movement is understanding that **speed is a resource**.
You earn it, spend it, and conserve it.

### Speed Sources

```
SOURCE              | SPEED GAINED    | HOW TO USE
────────────────────|─────────────────|────────────────────────
Downhill slide      | +100-160 u/s    | Always take hills, even small ones
Jump pad            | +600-800 u/s    | Time your exit for max distance
Gravity cannon      | +500+ u/s       | Aim your launch angle
Zipline             | Variable        | Jump off for momentum redirects
Octane stim         | +40% speed      | Stack with slide-jump for insane speed
Pathfinder grapple  | +400-600 u/s    | Grapple + jump = slingshot
Wraith portal exit  | Maintains entry | Enter fast, exit fast
Bangalore passive   | +40% speed      | Getting shot = free speed boost
```

### Speed Drains

```
DRAIN               | SPEED LOST      | HOW TO AVOID
────────────────────|─────────────────|────────────────────────
Uphill movement     | -50-100 u/s     | Slide-jump over small hills
Running into walls  | All momentum    | Jump before hitting walls
Stopping to shoot   | All momentum    | Hipfire while moving
Not jump-padding    | Wasted speed    | Always chain movements
Hitting objects     | Depends on size | Learn the map geometry
```

### The Golden Rule of Momentum

```
NEVER STOP MOVING.

Even in a fight, even when looting, even when healing.
Every time you stop, you pay a "startup tax" to get back to full speed.
The startup tax: ~0.5 seconds to reach sprint speed from standing.

0.5 seconds in Apex = 100+ damage from a competent enemy.
```

---

## Air Strafing Basics

Air strafing is moving your character left or right while in the air.
It's the foundation of tap-strafing and wall-bouncing (covered in other guides).

### How Air Strafing Works

In Apex (Source engine), you can influence your air direction using strafe keys + mouse movement.

```
REGULAR JUMP (no air strafe):
  
  Jump ──→ ──→ ──→ ──→ Land
  (Straight line, predictable, easy to shoot)

AIR STRAFE LEFT:
  
  Jump ──→ ──↗ ──↑ ──↖ Land
  (Curved path, harder to predict, dodge bullets)
  
  INPUT: Hold A + move mouse left (slowly!)

AIR STRAFE RIGHT:
  
  Jump ──→ ──↘ ──↓ ──↙ Land  
  (Same thing, opposite direction)
  
  INPUT: Hold D + move mouse right (slowly!)
```

### Air Strafe Rules

```
RULE 1: Release W before strafing.
  W and A/D at the same time = no strafe, just diagonal movement.
  
RULE 2: Mouse movement direction must match strafe key.
  Holding A? Mouse goes left.
  Holding D? Mouse goes right.
  Mismatch = loss of speed.
  
RULE 3: Smooth mouse movement, not jerky.
  Think of it as gently steering, not flicking.
  Faster mouse ≠ more strafe. There's a sweet spot.
  
RULE 4: You can switch strafe direction mid-air.
  A + mouse left → D + mouse right = S-curve in the air.
  This is the beginning of tap-strafe tech.
```

---

## Climbing & Mantling

Climbing in Apex has hidden mechanics that most players never learn.

### Climb Heights

```
REGULAR CLIMB:
  Max height: ~5.5 meters (about 2 stories)
  Speed: Moderate
  
  HOW: Walk or sprint into a wall, hold jump.
  Your character grabs the wall and pulls up.

ENHANCED CLIMB (since Season 12):
  Max height: ~7 meters with proper technique
  Speed: Slightly slower
  
  HOW: Sprint into wall → hold jump → hold forward
  You climb higher than the default max.
```

### Climb Tricks

```
SILENT CLIMB:
  Normal climbing makes a loud "scraping" sound.
  To climb silently: tap jump repeatedly instead of holding it.
  Each tap moves you up slightly without the full climbing audio.
  Best for: Flanking enemies above you.

CLIMB CANCEL → SHOTGUN:
  Start climbing a wall → Press crouch to cancel mid-climb.
  You pop up above the wall edge briefly.
  Fire a shotgun shot → drop back down.
  Repeat. Enemies can't predict when you'll peek.

LEDGE GRAB MOMENTUM:
  If you climb to a ledge while holding a strafe key,
  you maintain horizontal momentum when you reach the top.
  This lets you roll over ledges instead of stopping at the top.
```

---

## Common Mistakes

### The 7 Movement Sins

```
SIN 1: Running in straight lines
  FIX: Always slide-jump. ALWAYS. Make it muscle memory.

SIN 2: Sliding uphill
  FIX: Sprint + jump uphill, slide + jump downhill.

SIN 3: Holding W during air movement
  FIX: Release W the moment you leave the ground (for advanced tech).

SIN 4: Standing still while looting
  FIX: Spam crouch while in the loot menu. Jiggle behind cover.

SIN 5: Running through open areas at sprint speed
  FIX: Slide-jump through open areas — faster AND harder to hit.

SIN 6: Using the same movement pattern every fight
  FIX: Mix up left/right strafes, crouch timing, and jump timing.

SIN 7: Ignoring terrain
  FIX: Plan routes that use downhill slides and natural cover.
```

### Movement Speed Reference Card

```
ACTION                    | SPEED (u/s) | NOTES
──────────────────────────|─────────────|──────────────────────
Standing                  | 0           | Don't do this
Walking                   | 144         | Use for silent flanks only
Crouching                 | 72          | Half walk speed
Sprinting                 | 299         | Default movement
Slide (flat start)        | 346         | Decays quickly
Slide (downhill)          | 346-460+    | Gets FASTER on slopes
Slide-jump                | ~350        | Preserves slide speed
Bunny hop                 | 250-350     | Depends on execution
Zipline                   | 350-750     | Varies by angle
Gravity cannon            | 500+        | Free speed
Jump pad                  | 600-800     | Best speed source
Pathfinder grapple launch | 400-600+    | Highest player-controlled speed
```

---

*Next up: Character Movement Tips → How each Legend's abilities change the movement game.*
