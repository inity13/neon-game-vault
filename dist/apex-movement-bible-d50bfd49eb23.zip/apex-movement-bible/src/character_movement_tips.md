# Character Movement Tips — Per-Legend Movement Abilities

## Table of Contents
1. [Movement Tier List](#movement-tier-list)
2. [S-Tier Movement Legends](#s-tier-movement-legends)
3. [A-Tier Movement Legends](#a-tier-movement-legends)
4. [B-Tier Movement Legends](#b-tier-movement-legends)
5. [C-Tier & Situational Legends](#c-tier--situational-legends)
6. [Team Movement Combos](#team-movement-combos)

---

## Movement Tier List

Not all Legends are created equal when it comes to movement. Some have movement
built into their DNA. Others have zero mobility tools. Pick your main wisely.

```
MOVEMENT TIER LIST (Current Meta):

  S TIER ████████████████████ (Movement is their identity)
  ├── Pathfinder    — Grapple slingshot, zipline creation
  ├── Octane        — Stim speed boost, jump pad launcher
  └── Valkyrie      — VTOL jets, full team skylaunch

  A TIER ████████████████ (Strong movement utility)
  ├── Wraith        — Phase walk (invincible reposition)
  ├── Horizon       — Gravity lift (vertical mobility)
  ├── Ash           — Phase breach (long-range teleport)
  └── Bangalore     — Double-time passive (speed on getting shot at)

  B TIER ████████████ (Decent movement tools)
  ├── Loba          — Bracelet teleport (mid-range reposition)
  ├── Mad Maggie    — Wrecking ball speed boost
  ├── Revenant      — Wall climb passive (enhanced vertical)
  └── Conduit       — Tactical speed utility

  C TIER ████████ (Limited or no movement tools)
  ├── Lifeline, Gibraltar, Caustic, Wattson
  ├── Fuse, Seer, Bloodhound, Crypto
  └── Newcastle, Catalyst, Rampart, Mirage
```

> **Important:** Movement tier ≠ overall tier. Legends like Gibraltar and Caustic
> are top-tier competitive picks despite having zero mobility. This list ONLY ranks
> movement ability.

---

## S-Tier Movement Legends

### Pathfinder — The Grapple God

Pathfinder has the highest movement ceiling of any Legend. His grapple turns every
surface into a launchpad.

#### Grapple Slingshot (Must-Learn Technique)

The grapple slingshot is the most satisfying movement tech in the entire game.
It lets you fly across the map at absurd speeds.

```
HOW IT WORKS:

  1. Aim grapple at a surface (rock, building, terrain)
  2. Fire grapple → it connects and pulls you
  3. As you start swinging, LOOK 90° AWAY from the grapple point
  4. Jump right as you pass the grapple point
  5. You launch in the direction you're looking at insane speed

  DIAGRAM (top-down view):
  
       Grapple point
            *
           /|
          / |  Grapple pulls you in
         /  |
        /   |
       /    |
      @─────┤  ← You look THIS way (perpendicular)
      ↓
   You launch this direction at 400-600+ u/s

  THE KEY: Look perpendicular to the grapple line.
  Looking straight at the grapple = you just pull to it (slow).
  Looking sideways = you SLINGSHOT past it (fast).
```

#### Grapple + Slide Jump Combo

```
SEQUENCE:
  1. Grapple a surface above and ahead of you
  2. As you fly through the air, look at your landing spot
  3. The MOMENT you touch ground: Slide → Jump
  4. You carry the grapple momentum into a slide-jump
  5. Chain into air strafes or wall bounces

  SPEED: You can hit 600+ u/s and maintain 400+ through the chain.
  This is how Path mains cross the map faster than anyone.
```

#### Zipline Tech

Pathfinder's ultimate creates a zipline. But the real tech is how you USE ziplines:

```
ZIPLINE SUPER JUMP:
  1. Ride the zipline
  2. Jump off (Space)
  3. IMMEDIATELY re-attach (interact key)
  4. Jump off again at the peak of your detach arc
  5. Repeat — each jump goes higher than the last

  This turns a horizontal zipline into a vertical launcher.
  Great for: Getting over cover, dodging shots, reaching high ground.

ZIPLINE STRAFE:
  While on a zipline, you can:
  - Jump off + air strafe + re-attach
  - This makes you nearly impossible to hit
  - Alternate between left and right strafes
  - Enemies see a zig-zagging target on a zipline
```

### Octane — Speed Demon

Octane's movement is simpler than Pathfinder's but consistently powerful.
His stim gives an instant 40% speed boost.

#### Stim + Slide Jump

```
THIS IS THE BREAD AND BUTTER:

  Stim → Sprint → Slide → Jump → Slide → Jump → ...
  
  Speed breakdown:
    Normal sprint:        299 u/s
    Stimmed sprint:       419 u/s  (+40%)
    Stimmed slide-jump:   ~480 u/s
    Stimmed downhill:     550+ u/s  (FAST)
    
  HEALTH COST: Each stim costs 20 HP over 6 seconds.
  WORTH IT: Almost always. Speed = survival.
  
  EXCEPTION: Don't stim below 30 HP. One shot will knock you.
```

#### Jump Pad Tech

```
JUMP PAD BASICS:
  Walk onto pad:  Low arc, short distance (~50m)
  Slide onto pad: High arc, long distance (~80m)
  Jump onto pad:  Highest arc, longest distance (~100m)

JUMP PAD + DOUBLE JUMP:
  While in the air from a jump pad, press Jump again for a double jump.
  This lets you change direction mid-flight.
  
  USES:
  - Double jump backwards to fake out enemies
  - Double jump sideways to curve around cover
  - Double jump at the apex for maximum distance

JUMP PAD TAP-STRAFE:
  1. Slide onto jump pad (high launch)
  2. At the peak, tap-strafe (W scroll + A/D)
  3. Double jump in a new direction
  4. You've completely changed trajectory mid-air
  
  This is one of the hardest movement combos in the game.
  Master it and you can land behind enemies who think you're
  flying over them.
```

### Valkyrie — The Sky Queen

Valkyrie's VTOL jets give her the most consistent vertical mobility in the game.
Her ult is the only ability that fully repositions an entire team.

#### VTOL Jet Management

```
FUEL MANAGEMENT:
  Max fuel:        100 units
  Burn rate:       10 units/second (full thrust)
  Regen rate:      10 units/second (grounded)
  Full refuel:     10 seconds from empty
  
  NEVER fly until empty. Always keep 20-30% reserve.
  Running out of fuel mid-air = you're a sitting duck falling.

EFFICIENT FLYING:
  Don't hold jets constantly. Tap them in bursts.
  
  Hold jets:     ████████████████████  (drains fast, constant speed)
  Tap jets:      ██░░██░░██░░██░░██░░  (uses 40% less fuel, same distance)
  
  Tap method: Hold jets for 0.3s, release for 0.3s, repeat.
  You maintain most of your altitude while using way less fuel.
```

#### Valk + Slide Jump Combos

```
VALK HOVER STRAFE:
  1. Slide-jump off high ground
  2. Activate jets briefly at the peak
  3. Strafe left/right while jetting
  4. Deactivate jets and drop
  5. You covered more distance and were harder to hit

VALK VERTICAL PEEK:
  1. Stand behind cover
  2. Tap jets to rise above cover
  3. Fire a shotgun shot at the apex
  4. Drop back behind cover immediately
  5. Enemies can't track the brief popup
  
  Similar to a crouch-peek but VERTICAL.
```

---

## A-Tier Movement Legends

### Wraith — Phase Shift Queen

Wraith's tactical is a get-out-of-jail card. Phase walk makes you invincible
and invisible for a brief window.

```
PHASE WALK MOVEMENT:

  Activation: 1.25 second wind-up (you're vulnerable!)
  Duration:   4 seconds of phase
  Speed:      +30% movement speed while phasing
  Cooldown:   25 seconds
  
  KEY USES:
  - Escape a losing fight → reposition and heal
  - Cross open ground safely
  - Rotate through enemy fire
  - Phase into a building → exit through portal

PHASE + PORTAL COMBO:
  1. Place portal entrance
  2. Phase walk immediately
  3. Sprint to desired location (you're invincible)
  4. Place portal exit
  
  Your team now has a safe rotation path.
  This is THE competitive Wraith combo.
```

### Horizon — Gravity Lift

```
GRAVITY LIFT USES:

  Height:   ~30 meters (about 3-4 stories)
  Duration: 10 seconds active
  Cooldown: 20 seconds
  
  STRAFE ON TOP:
  When you reach the top of the lift, you float briefly.
  While floating, you have FULL air accuracy.
  Strafe left/right while beaming enemies below.
  
  SPEED BOOST LANDING:
  Horizon's passive: soft landing = no slow when falling.
  This means you can drop from ANY height and immediately
  slide-jump with zero speed penalty.
  
  COMBO: Gravity lift up → beam enemy → drop off edge →
         land with no slow → slide-jump toward them.
```

### Ash — Phase Breach

```
PHASE BREACH USES:

  Range:    ~75 meters (solid teleport distance)
  Type:     One-way portal (you go, enemies can follow briefly)
  Cooldown: 120 seconds (ultimate ability)
  
  AGGRESSIVE PUSH:
  1. Spot enemy team healing behind cover
  2. Phase breach BEHIND their cover
  3. You're now in their faces before they react
  
  ESCAPE TOOL:
  1. Losing a fight
  2. Phase breach to high ground or behind a wall
  3. Heal up and re-engage on your terms
```

### Bangalore — Double-Time Passive

```
DOUBLE-TIME:
  Trigger: Getting shot at (bullets passing near you)
  Bonus:   +40% sprint speed for 2 seconds
  Cooldown: Triggers on each near-miss
  
  THIS IS LOWKEY BROKEN FOR MOVEMENT:
  - Getting shot at MAKES YOU FASTER
  - Stack this with slide-jumping = nearly impossible to hit
  - The speed boost helps you reach cover when caught in the open
  
  SMOKE + MOVEMENT:
  Pop smoke → sprint through it → enemies can't see you
  Your double-time activates if they blind-fire at the smoke.
  You're fast AND invisible. Free reposition.
```

---

## B-Tier Movement Legends

### Loba — Bracelet Teleport

```
BRACELET RANGE:  ~70 meters (thrown like a grenade)
CAST TIME:       ~1.5 seconds (animation lock after teleport)
COOLDOWN:        30 seconds

PROS:
  - Instant reposition to high ground, rooftops, windows
  - Can throw through windows to enter buildings
  - Works vertically (throw up to reach roofs)

CONS:
  - Long animation lock after teleport (can't shoot)
  - Bracelet trail visible to enemies (they know where you went)
  - Doesn't work in some areas (ring edge, certain terrain)

BEST USE: Repositioning between fights, not during them.
```

### Revenant — Enhanced Climbing

```
REVENANT WALL CLIMB:
  Regular legend climb:  ~5.5 meters
  Revenant climb:        ~8-9 meters (almost unlimited with Shadow form)
  
  Revenant can also CROUCH-WALK FASTER than other legends.
  Crouch speed: 72 u/s → 108 u/s (Revenant)
  
  FLANK ROUTES:
  Revenant can climb walls that other legends can't reach.
  This opens up flank routes that enemies don't expect.
  
  Every time you see a tall wall or building, think:
  "Can I climb this to get a surprise angle?"
  The answer is usually yes.
```

---

## C-Tier & Situational Legends

These Legends have little to no movement tech, but they can still use ALL the
universal movement techniques (slide-jumping, b-hopping, wall-bouncing, etc.).

```
LEGEND             | MOVEMENT TOOL    | NOTES
───────────────────|──────────────────|────────────────────────
Lifeline           | None             | Focus on positioning, not speed
Gibraltar           | Gun Shield       | Absorbs 50 damage (helps survive while slow)
Caustic            | None             | His gas slows enemies (makes THEM slow instead)
Wattson            | None             | Zone control instead of mobility
Bloodhound         | Ult speed boost  | 40% speed in Beast of the Hunt
Seer               | None             | Info legend, position with knowledge
Fuse               | None             | Grenade trajectory = zone control
Crypto             | Drone mobility   | Not personal movement
Newcastle          | Shield dash      | Short-range charge, decent in fights
Catalyst           | None             | Wall placement for blocking paths
Rampart            | None             | Stationary defense legend
Mirage             | Decoy movement   | Confuse enemies about which "you" is moving
```

> **Pro tip for C-tier mains:** You can't outrun S-tier movement Legends.
> Instead, focus on POSITIONING — be where you need to be before the fight starts.
> Movement tech is about getting there first. Game sense is about knowing where "there" is.

---

## Team Movement Combos

Movement isn't just solo. These combos work when your squad coordinates:

```
COMBO: "THE HIGHWAY" (Octane + Pathfinder)
  Octane places jump pad → team launches
  Pathfinder places zipline from landing spot to next position
  Result: Your team crosses the map in 10 seconds.

COMBO: "THE ELEVATOR" (Horizon + Valkyrie)
  Horizon places gravity lift inside a building
  Valk ults from the top of the gravity lift
  Result: Full team skylaunch from inside a building.

COMBO: "THE ESCAPE POD" (Wraith + Ash)
  Wraith places portal entrance, phases to safety
  Ash phase-breaches to a completely different location
  Team: Portal to Wraith, then Ash breach further away
  Result: Team teleports across the entire POI in seconds.

COMBO: "THE BLITZ" (Octane + Bangalore + Bloodhound)
  Bangalore smokes the path → Bloodhound ults (sees through smoke)
  Octane stim + jump pad through the smoke
  Result: Team pushes through smoke at max speed with full vision.
```

---

*Next up: Advanced Techniques → Superglides, zip jumps, and edge boosts.*
