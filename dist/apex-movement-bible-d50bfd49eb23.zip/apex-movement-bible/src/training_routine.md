# Training Routine — Daily Practice Drills for Movement Mastery

## Table of Contents
1. [How Practice Works](#how-practice-works)
2. [Beginner Routine (Week 1-2)](#beginner-routine-week-1-2)
3. [Intermediate Routine (Week 3-6)](#intermediate-routine-week-3-6)
4. [Advanced Routine (Week 7+)](#advanced-routine-week-7)
5. [Firing Range Workout Maps](#firing-range-workout-maps)
6. [Progress Tracking](#progress-tracking)
7. [Common Plateaus & How to Break Them](#common-plateaus--how-to-break-them)

---

## How Practice Works

Let's keep it real: reading about movement and actually DOING movement are
completely different things. You can understand every technique in this guide
and still fail every superglide attempt in-game.

**Movement is muscle memory.** Your brain needs to stop "thinking" about the
inputs and start "doing" them automatically. That takes repetition.

```
THE LEARNING CURVE:

  Conscious Incompetence (Day 1-3):
  ─────────────────────────────────
  "I know what a superglide is but I can't do it."
  You understand the technique but your hands don't cooperate.
  THIS STAGE SUCKS. Everyone goes through it. Don't quit.

  Conscious Competence (Day 4-14):
  ────────────────────────────────
  "I can do it if I focus really hard."
  You hit the technique sometimes, but it takes 100% concentration.
  Not usable in real fights yet. Keep drilling.

  Unconscious Competence (Week 3+):
  ─────────────────────────────────
  "I didn't even think about it, my hands just did it."
  Muscle memory kicks in. You superglide without thinking.
  NOW you can use it in actual games. This is the goal.

  TIME REQUIRED (per technique):
  ┌───────────────────┬──────────────────┬────────────────────┐
  │ Technique         │ Time to "Can Do" │ Time to "Automatic"│
  ├───────────────────┼──────────────────┼────────────────────┤
  │ Slide-jump        │ 30 minutes       │ 1-2 days           │
  │ Air strafe        │ 1-2 hours        │ 3-5 days           │
  │ Bunny hop         │ 2-3 hours        │ 1 week             │
  │ Wall bounce       │ 1-2 days         │ 1-2 weeks          │
  │ Tap-strafe        │ 2-3 days         │ 2-3 weeks          │
  │ Superglide        │ 3-7 days         │ 3-4 weeks          │
  │ Chain combos      │ 1-2 weeks        │ 1-2 months         │
  └───────────────────┴──────────────────┴────────────────────┘
```

### The 15-Minute Rule

You don't need to grind for 2 hours in the Firing Range. In fact, long sessions
lead to mental fatigue, and you start reinforcing bad habits.

```
OPTIMAL PRACTICE:

  ✅ 15-20 minutes of focused drills BEFORE each play session
  ✅ Practice one technique per session until it clicks
  ✅ Take breaks if frustrated (frustration = bad practice)
  
  ❌ 2-hour Firing Range grinds (you zone out after 30 min)
  ❌ Practicing 5 techniques at once (learn nothing properly)
  ❌ Skipping practice "because I'll just do it in games"
```

---

## Beginner Routine (Week 1-2)

**Goal:** Master slide-jumping, basic air strafes, and bunny hopping.
**Time:** 15 minutes before each play session.
**Location:** Firing Range.

### Day 1-3: Slide-Jump Foundation

```
DRILL 1: Slide-Jump Laps (5 minutes)
─────────────────────────────────────
  Start at the weapon racks in the Firing Range.
  Sprint → Slide → Jump. Sprint → Slide → Jump.
  Do a full lap around the firing range using ONLY slide-jumps.
  
  FOCUS ON:
  - Smooth rhythm (slide and jump should feel like one motion)
  - No pauses between landing and the next slide
  - Maintaining a straight line
  
  GOAL: Complete 3 laps without any "normal" running.

DRILL 2: Directional Slide-Jumps (5 minutes)
─────────────────────────────────────────────
  Slide-jump but curve left for 3 jumps, then curve right for 3.
  This builds the air strafe muscle memory alongside slide-jumping.
  
  PATTERN:
  Jump-Left, Jump-Left, Jump-Left, Jump-Right, Jump-Right, Jump-Right
  
  FOCUS ON:
  - Releasing W before strafing
  - Matching mouse direction to strafe key (A = mouse left)
  - Smooth curves, not jerky turns

DRILL 3: Uphill/Downhill Awareness (5 minutes)
───────────────────────────────────────────────
  Find the slopes in the Firing Range.
  Slide-jump downhill: feel the speed boost.
  Sprint-jump uphill: feel the difference.
  
  GOAL: Your brain should start automatically choosing downhill paths.
```

### Day 4-7: Air Strafe & Bunny Hop

```
DRILL 4: Figure-Eight Air Strafes (5 minutes)
─────────────────────────────────────────────
  Pick two objects in the Firing Range, about 30m apart.
  Slide-jump from one to the other using air strafes to curve.
  
  PATTERN (top-down view):
  
  [Object A]          [Object B]
       ↖            ↗
         ╲        ╱
           ╲    ╱
            ╲ ╱
             ✕
            ╱ ╲
          ╱     ╲
        ╱         ╲
       ↙            ↘
  [Object A]          [Object B]
  
  Make a figure-8 pattern using only slide-jumps and air strafes.
  GOAL: 5 smooth figure-eights without stopping.

DRILL 5: Bunny Hop Healing (5 minutes)
──────────────────────────────────────
  Pick up a syringe or shield cell.
  Sprint → Slide → Jump → Start healing → Bunny hop.
  
  FOCUS ON:
  - NOT holding W during the hops
  - Alternating A and D each hop
  - Gentle mouse movements matching strafe direction
  
  GOAL: Complete one full syringe heal (5 seconds) while b-hopping
        without losing all your speed.

DRILL 6: Sprint Speed Comparison (5 minutes)
────────────────────────────────────────────
  Race yourself:
  1. Sprint from point A to point B normally → time it
  2. Slide-jump from A to B → time it
  3. Slide-jump with air strafes from A to B → time it
  
  Feel the speed difference. This cements WHY you practice.
```

---

## Intermediate Routine (Week 3-6)

**Goal:** Learn wall bounces and tap-strafes. Start chaining.
**Time:** 15-20 minutes before each play session.
**Location:** Firing Range.

### Week 3-4: Wall Bounces

```
DRILL 7: Basic Wall Bounce Reps (5 minutes)
──────────────────────────────────────────
  Find a flat wall in the Firing Range.
  Sprint → Slide → Jump into wall → Jump off wall.
  
  REPS: 30 attempts.
  TRACK: How many successful bounces out of 30?
  
  TARGET:
  Week 3: 10/30 successful (you're learning)
  Week 4: 20/30 successful (getting consistent)
  
  TIPS:
  - Approach at ~30-45° angle, not straight at the wall
  - Jump BEFORE hitting the wall, not after
  - Don't hold any directional keys when bouncing

DRILL 8: Wall Bounce + Direction Change (5 minutes)
──────────────────────────────────────────────────
  Wall bounce, but choose a specific direction to land.
  Place 3 markers (legends or items) in different spots.
  Bounce off the wall and try to land on a specific marker.
  
  This builds spatial awareness for using wall bounces in fights.

DRILL 9: Wall Bounce Chain (5 minutes)
─────────────────────────────────────
  Find a corridor or two nearby walls.
  Bounce off Wall A → bounce off Wall B → bounce off Wall A.
  
  GOAL: 3 consecutive bounces without touching the ground normally.
  This is HARD at first. Even 2 in a row is progress.
```

### Week 5-6: Tap-Strafes

```
DRILL 10: Scroll Wheel Tap-Strafe (5 minutes)
────────────────────────────────────────────
  SETUP: Bind Jump to Scroll Wheel Down (keep Space too).
  
  Sprint → Slide → Jump → Release W → Hold A → Scroll wheel → 
  Mouse left.
  
  REPS: 30 attempts.
  TRACK: How many resulted in a noticeable direction change?
  
  FOCUS: The direction change, not the magnitude.
  Even a 30° turn mid-air is a successful tap-strafe.
  You'll get sharper angles with practice.

DRILL 11: 90° Tap-Strafe (5 minutes)
───────────────────────────────────
  Same as above, but aim for a sharp 90° turn.
  
  Use a wall as a reference: slide-jump toward a wall,
  then tap-strafe to end up running parallel to it.
  
  GOAL: Consistent 90° turns within 2 meters of the wall.

DRILL 12: Tap-Strafe Off Surfaces (5 minutes)
────────────────────────────────────────────
  Slide-jump → tap-strafe → land → IMMEDIATELY slide-jump again.
  
  Practice maintaining speed through the strafe.
  If you lose all speed after the tap-strafe, your mouse movement
  was too aggressive. Tone it down.
```

---

## Advanced Routine (Week 7+)

**Goal:** Superglides, zip tech, and full movement chains.
**Time:** 15-20 minutes before each play session.
**Location:** Firing Range.

### Superglide Drills

```
DRILL 13: Superglide Reps on Boxes (5 minutes)
────────────────────────────────────────────
  Go to the waist-high crates near the weapon racks.
  Climb → Jump+Crouch at the top → hope for the best.
  
  REPS: 50 attempts (yes, fifty).
  
  TRACK: Successful superglides out of 50.
  
  TARGET:
  Week 7:  5/50 (10% — this is normal when learning)
  Week 8:  15/50 (30% — rhythm is forming)
  Week 10: 25/50 (50% — getting there)
  Week 12: 35/50 (70% — nearly consistent)
  
  TIP: If you're at 0/50 after multiple sessions, try capping
  your FPS to 60 temporarily. The window is wider at lower FPS.

DRILL 14: Superglide + Slide-Jump (5 minutes)
────────────────────────────────────────────
  Superglide off a box → land → immediately slide-jump.
  
  The superglide gives you ~500 u/s.
  The slide-jump should maintain ~350-400 u/s.
  
  GOAL: Carry superglide momentum through 3 slide-jumps.

DRILL 15: Superglide + Tap-Strafe (5 minutes)
────────────────────────────────────────────
  Superglide off a box → tap-strafe left or right.
  
  This is the holy combo. When you land it:
  You fly off a ledge at 500 u/s in a completely unexpected direction.
  
  GOAL: 3 successful combos in a row.
```

### Full Chain Drills

```
DRILL 16: The Obstacle Course (5-10 minutes)
──────────────────────────────────────────
  Create a movement course in the Firing Range:
  
  START → Slide-jump to Box A → Superglide off Box A →
  Tap-strafe toward Wall B → Wall bounce off Wall B →
  Air strafe to Box C → Climb Box C → Superglide off →
  Slide-jump to FINISH
  
  TIME YOURSELF. Track your personal best.
  
  WEEK 7 TARGET: Complete the course in 15 seconds.
  WEEK 10 TARGET: Complete it in 10 seconds.
  WEEK 12+ TARGET: Sub-8 seconds.

DRILL 17: Combat Movement Sim (5 minutes)
───────────────────────────────────────
  Turn on the bots in the Firing Range (interact with targets).
  
  RULES:
  - You can only use a shotgun
  - You MUST be moving at all times (no standing and shooting)
  - Kill all 3 bots using only movement + shotgun shots
  
  FOCUS: Maintaining speed while dealing damage.
  Slide-jump → shoot → wall bounce → shoot → air strafe → shoot.
```

---

## Firing Range Workout Maps

The Firing Range has specific areas perfect for movement practice.
Here's a layout guide:

```
FIRING RANGE MAP OVERVIEW:

  ┌─────────────────────────────────────────────────────┐
  │                                                     │
  │  [A] Weapon Racks — Start here. Flat, open, boxes.  │
  │      Best for: Slide-jumps, superglide boxes        │
  │                                                     │
  │  [B] Target Dummies — Three bot spawns.              │
  │      Best for: Combat movement, shooting while moving│
  │                                                     │
  │  [C] Back Wall — Tall wall with various heights.     │
  │      Best for: Wall bounces, climbing practice       │
  │                                                     │
  │  [D] Rocky Terrain — Uneven slopes and hills.        │
  │      Best for: Downhill slides, terrain awareness    │
  │                                                     │
  │  [E] Ziplines — Multiple ziplines between platforms. │
  │      Best for: Zip jumps, zip strafing               │
  │                                                     │
  └─────────────────────────────────────────────────────┘
  
  RECOMMENDED COURSE ORDER:
  A (warm up) → C (wall bounces) → D (terrain) → E (zips) → B (combat)
```

---

## Progress Tracking

Track your progress to stay motivated. Here's a simple system:

```
WEEKLY MOVEMENT SCORECARD:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Technique              | Week __ | Attempts | Success | Rate
──────────────────────|─────────|──────────|─────────|──────
Slide-jump (no pause) |         |   /30    |   /30   |   %
Air strafe (smooth)   |         |   /30    |   /30   |   %
Bunny hop (full heal) |         |   /10    |   /10   |   %
Wall bounce (basic)   |         |   /30    |   /30   |   %
Tap-strafe (90°)      |         |   /30    |   /30   |   %
Superglide            |         |   /50    |   /50   |   %
Chain combo           |         |   /10    |   /10   |   %
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Fill this out every week. Watch the numbers climb.
If a technique plateaus, see the next section.
```

### Milestone Badges

Give yourself credit for hitting these milestones:

```
🔰 MOVEMENT ROOKIE
  ✓ Can slide-jump consistently (90%+ rate)
  ✓ Can air strafe in both directions
  ✓ Can bunny hop through a full syringe heal

⚔️ MOVEMENT WARRIOR
  ✓ Can wall bounce on demand (70%+ rate)
  ✓ Can tap-strafe 90° (50%+ rate)
  ✓ Can chain slide-jump → wall bounce → air strafe

🔥 MOVEMENT DEMON
  ✓ Can superglide consistently (60%+ rate)
  ✓ Can tap-strafe off jump pads
  ✓ Can chain 3+ techniques without speed loss

👑 MOVEMENT GOD
  ✓ Can superglide + tap-strafe combo (50%+ rate)
  ✓ Can wall bounce chain 4+ times
  ✓ Can fight effectively while maintaining advanced movement
  ✓ Other players message you asking how you move like that
```

---

## Common Plateaus & How to Break Them

### "I can't hit superglides at all"

```
CHECKLIST:
  □ Is your FPS capped at 60? (wider timing window)
  □ Are you using scroll wheel for jump?
  □ Are you climbing the RIGHT height surface? (waist-to-chest)
  □ Are you pressing jump+crouch at the TOP of the mantle?
  
  IF STILL STUCK:
  1. Record yourself in slow motion (screen recorder)
  2. Watch when you press the inputs relative to the mantle
  3. You're probably pressing too early or too late
  4. Adjust by small amounts (50ms earlier/later)
```

### "My wall bounces are inconsistent"

```
COMMON ISSUES:
  
  1. Approaching at the wrong angle:
     Too steep (>60°) = you climb the wall instead of bouncing
     Too shallow (<20°) = you graze the wall and keep going
     SWEET SPOT: 30-45° approach angle
  
  2. Jumping at the wrong time:
     Jump BEFORE touching the wall, not after.
     Think of it as: jump AT the wall, not OFF the wall.
  
  3. Not releasing all directional keys:
     During the bounce, let go of W, A, S, D.
     Only use strafe keys AFTER the bounce to direct your flight.
```

### "I lose all speed after tap-strafing"

```
CAUSES:
  
  1. Mouse movement too aggressive:
     Your mouse is jerking instead of sweeping.
     FIX: Cut your mouse movement speed in half.
  
  2. Not enough W taps:
     You need 3-5 rapid W taps (or scroll inputs).
     FIX: Scroll wheel should fire 3-5 inputs per scroll.
  
  3. Releasing strafe key too early:
     Hold A or D through the ENTIRE tap-strafe.
     FIX: Hold the strafe key until you land.
```

### "I can do techniques in the Firing Range but not in games"

```
THIS IS THE #1 COMPLAINT. Here's why it happens:

  In the Firing Range:
  - Zero pressure
  - 100% focus on movement
  - No enemies, no decisions
  
  In a real game:
  - Adrenaline (hands tense up)
  - Split attention (movement + aim + awareness + comms)
  - Consequences (die = back to lobby)
  
  THE FIX: Gradual integration.
  
  STEP 1: Use basic techniques (slide-jump) in every game. ALWAYS.
          These should be 100% automatic before adding anything.
  
  STEP 2: Use wall bounces ONLY when you're not in immediate danger.
          Rotating between POIs? Wall bounce off buildings.
  
  STEP 3: Use tap-strafes in pubs (unranked). Not ranked. Not yet.
          Pubs are your real-game training ground.
  
  STEP 4: After 2+ weeks of pubs, bring techniques into ranked.
          By now they should be semi-automatic.
```

---

*You've got the knowledge. Now put in the reps. See you in the Firing Range.*
