# Advanced Techniques — Superglides, Zip Jumps & Edge Boosts

## Table of Contents
1. [Superglides](#superglides)
2. [Zipline Techniques](#zipline-techniques)
3. [Edge Boosts](#edge-boosts)
4. [Wall Bounce Chains](#wall-bounce-chains)
5. [Neo-Strafing](#neo-strafing)
6. [Punch Boosting](#punch-boosting)
7. [Gravity Cannon Tech](#gravity-cannon-tech)
8. [Combining Techniques](#combining-techniques)

---

## Superglides

The superglide is arguably the hardest consistent movement technique in Apex.
It gives you an insane burst of speed off ledges and mantles. When you nail it,
you *fly* forward. When you miss it, you just do a normal jump. High risk, high reward.

### What Is a Superglide?

A superglide exploits a 1-2 frame window at the top of a mantle/climb animation
where pressing jump + crouch simultaneously launches you forward at ~500 u/s.

```
NORMAL CLIMB:
  Climb wall → mantle on top → stand → walk
  Speed: 0 → 144 → 299 (after sprint kicks in)
  Boring. Slow. Everyone can track you.

SUPERGLIDE:
  Climb wall → hit jump+crouch on THE EXACT FRAME → LAUNCH
  Speed: 0 → 500+ u/s INSTANTLY
  You rocket off the edge like you got hit by a jump pad.
  
  Visual:
                    ╔═══════╗
                    ║       ║
  You climb up ──→  ║  TOP  ║ ──→ SUPERGLIDE ══════════════►
                    ║       ║     (500+ u/s burst)
  ══════════════════╝       ╚═════
       Wall you climbed
```

### Superglide Input Timing

This is where most people struggle. The timing window is TINY — literally 1-2 frames.

```
THE TIMING WINDOW:

  Frame timeline during mantle:
  
  ... ─ climbing ─ climbing ─ climbing ─ [MANTLE FRAME 1] ─ [MANTLE FRAME 2] ─ standing ─ ...
                                          ↑                  ↑
                                          WINDOW OPENS       WINDOW CLOSES
                                          
  You need to press Jump + Crouch during this 1-2 frame window.
  At 60 FPS:  1-2 frames = 16-33ms window
  At 144 FPS: 1-2 frames = 7-14ms window
  At 240 FPS: 1-2 frames = 4-8ms window
  
  YES, higher FPS makes it HARDER because the window is shorter in real time.
  
  THIS IS WHY: Some players cap FPS at 60 when practicing superglides.
  Once you learn the rhythm, you can do it at higher FPS too.
```

### Superglide Method: The Jump Bind Technique

```
THE EASIEST METHOD:

  Bind: Mousewheel down → Jump (in addition to Spacebar)
  Why: Scrolling the wheel fires multiple jump inputs in rapid succession.
       One of them is more likely to hit the 1-frame window.
  
  INPUT SEQUENCE:
  1. Walk toward a climbable ledge (waist-to-chest height works best)
  2. Hold forward (W) to start climbing
  3. Watch your character's hands reach the top of the ledge
  4. The MOMENT the climb animation finishes:
     - Scroll mousewheel down (rapid jump inputs)
     - Press crouch at the same time
  5. If timed right: you launch forward in a slide at 500+ u/s
  
  IF YOU MISS: You just jump normally or crouch on the ledge. No penalty.
  
  SUCCESS RATE WHEN LEARNING:
  Day 1:    ~5% hit rate    (you'll miss a lot, that's normal)
  Week 1:   ~20-30% rate    (getting the rhythm)
  Week 2:   ~40-60% rate    (muscle memory forming)
  Month 1:  ~70-80% rate    (consistent enough for real games)
  Month 3:  ~90%+ rate      (movement god status)
```

### Best Surfaces for Superglides

```
SURFACE TYPE          | DIFFICULTY  | NOTES
──────────────────────|─────────────|──────────────────────────
Waist-high boxes      | ★☆☆☆☆      | BEST for learning. Consistent height.
Chest-high walls      | ★★☆☆☆      | Standard superglide surface.
Window ledges         | ★★★☆☆      | Useful in buildings. Practice these.
Uneven terrain        | ★★★★☆      | Height varies. Harder to time.
Very tall walls       | ★★★★★      | Long climb = harder to read the end frame.

PRO TIP: Practice on the boxes in the Firing Range first.
There are waist-high crates near the weapon racks.
Do 100 superglide attempts on those before trying in a real match.
```

### Superglide + Tap-Strafe Combo

```
THE ULTIMATE MOVEMENT COMBO:

  1. Superglide off a ledge (500+ u/s burst)
  2. While in the air, tap-strafe left or right
  3. You redirect your 500 u/s momentum in a new direction
  
  This is how movement gods fly around corners at impossible speeds.
  
  Example scenario:
  
  ┌──────────────────────────────┐
  │           Enemy              │
  │             ↓                │
  │         ┌───────┐            │
  │         │ Cover │            │
  │         └───────┘            │
  │  You →  ▓▓▓▓▓▓▓ ← Wall      │
  │         (climb)              │
  │                              │
  │  Step 1: Climb the wall      │
  │  Step 2: Superglide right    │
  │  Step 3: Tap-strafe behind   │
  │          the cover           │
  │  Step 4: Enemy loses you     │
  └──────────────────────────────┘
```

---

## Zipline Techniques

Ziplines are everywhere in Apex. Most players just ride them. Movement
players turn them into launchers.

### Zipline Super Jump

```
HOW IT WORKS:
  When you detach from a zipline, you get a brief "jump" off it.
  If you immediately re-attach and jump again, each jump stacks higher.
  
  INPUT SEQUENCE:
  1. Get on zipline (interact key)
  2. Jump off (Space) — you pop up slightly
  3. Look at zipline + Interact — reattach
  4. Jump off again — you pop up HIGHER
  5. Repeat 2-4 times
  
  Each jump: ~2m → ~3.5m → ~5m → ~7m+
  
  After 3-4 jumps, you're WAY above the zipline.
  At the peak, air strafe away for a massive repositioning move.

ANTI-CAMP TOOL:
  Enemy camping the end of a zipline?
  Super jump off the zip → air strafe behind them.
  They're aiming at where you'd normally exit.
  You're behind them. Free shots.
```

### Zipline Speed Boost

```
TECHNIQUE: Zipline dash

  1. Face ALONG the zipline direction (not perpendicular)
  2. Jump onto the zipline
  3. IMMEDIATELY jump off + forward
  4. You get a speed boost in the zipline's direction
  
  Stack with a slide-jump on landing for maximum speed.
  
  This is faster than riding the zipline the whole way.
  You're basically using the zipline as a speed boost pad.
```

### Zipline Strafe Fighting

```
WHEN SOMEONE IS SHOOTING AT YOU ON A ZIPLINE:

  Don't just ride it. You're a sitting duck.
  
  INSTEAD:
  1. Jump off the zip (left)
  2. Air strafe
  3. Re-attach
  4. Jump off the zip (right)
  5. Air strafe
  6. Re-attach
  7. Repeat
  
  From the enemy's perspective, you're zig-zagging unpredictably.
  This works on every zipline in the game, not just Pathfinder's.
  
  ADVANCED: Shoot while detached.
  Jump off → shoot → reattach → jump off → shoot
  You deal damage while being nearly untouchable.
```

---

## Edge Boosts

Edge boosts exploit collision geometry at the edges of objects. When your character
clips the edge of a surface while moving, you get a brief speed burst.

### The Mechanics

```
WHY IT HAPPENS:
  The game's physics engine resolves collisions by pushing you away from
  surfaces. When you clip the EDGE of an object at the right angle, the
  push-back adds to your existing momentum instead of stopping you.
  
  Think of it like:
  - Hitting a wall head-on = STOP (momentum killed)
  - Grazing the corner of a wall = BOOST (momentum redirected + added)

VISUAL:
  ──────────────────
  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓  ← Wall
  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
  ▓▓▓▓▓▓▓▓ ← Edge
  
  @ ──→ ↗  ← You clip the edge and get boosted upward/forward
  
  RESULT: Brief speed burst of +50-100 u/s
```

### How to Practice Edge Boosts

```
STEP 1: Find a corner or edge of a building/box in the Firing Range.

STEP 2: Sprint → Slide → Jump toward the edge at a slight angle.
         Not straight at it — about 10-20° off perpendicular.

STEP 3: Your character should "clip" the edge and get nudged.

STEP 4: If you got a speed boost, you did it right.
         If you just ran into the wall, adjust your angle.

NOTE: Edge boosts are inconsistent by nature. They're not something
you plan for, but something you recognize and exploit when they happen.
Good movement players develop a "feel" for edges and instinctively
angle toward them during movement chains.
```

---

## Wall Bounce Chains

A single wall bounce is cool. Chaining 3-4 wall bounces back-to-back
in a fight? That's how clips get made.

### Basic Wall Bounce Recap

```
SINGLE WALL BOUNCE:
  1. Sprint toward a wall at ~45° angle
  2. Slide → Jump into the wall
  3. The moment you touch the wall, jump again
  4. You bounce off at the opposite angle with boosted speed
  
  Visual (top-down):
  
       Wall
  ═══════════════
       ↗  ↗
      /  /
     /  / ← Bounce direction
    /  /
   @ ←── Your approach angle
```

### Chain Bouncing Between Two Walls

```
THE CORRIDOR BOUNCE:

  Wall A                Wall B
  ══════                ══════
    ↗                      ↖
   /        YOU              \
  / ──→ Bounce 1 ──→ Bounce 2 ──→ Bounce 3
  
  INPUT:
  1. Slide-jump into Wall A → bounce off
  2. In the air, turn toward Wall B
  3. When you reach Wall B → jump off it
  4. Turn back toward Wall A
  5. Repeat
  
  Each bounce maintains most of your speed.
  You ping-pong through corridors at 400+ u/s.
  
  GREAT FOR: Indoor fights, building pushes, narrow areas.
  Enemies can't track someone bouncing off every surface.
```

### Wall Bounce + 180° Turn

```
THE FAKE-OUT:

  1. Run AWAY from the enemy
  2. Wall bounce off the nearest wall
  3. During the bounce, spin 180° (look back at the enemy)
  4. You're now flying TOWARD the enemy at high speed
  5. Shotgun them in the face
  
  The enemy expected you to keep running. Instead, you're
  in their face before they can react.
  
  This is one of the most satisfying kills in Apex.
```

---

## Neo-Strafing

Neo-strafing is a relatively new technique that lets you change direction
on the ground faster than normal strafing.

```
WHAT IT LOOKS LIKE:
  Normal strafe: A ─── D ─── A ─── D (smooth left-right movement)
  Neo-strafe:    A-D-A-D-A-D-A-D-A-D (rapid direction changes)
  
  Your character appears to vibrate side-to-side while moving forward.
  It's extremely hard to track with a mouse.

HOW TO DO IT:
  1. Bind strafe left (A) and strafe right (D) to easily alternating inputs
  2. While sprinting, rapidly alternate A and D
  3. Move your mouse in small left-right movements matching the strafes
  4. Your character jitters side-to-side while maintaining forward momentum
  
  TIMING: Switch direction every 2-3 frames (about every 20-50ms)
  
  WHEN TO USE:
  - Crossing open areas under fire
  - Close-range fights (makes your hitbox dance)
  - Running from a fight while being chased
  
  WHEN NOT TO USE:
  - While trying to aim precisely (it messes up YOUR aim too)
  - While slide-jumping (kills your momentum)
```

---

## Punch Boosting

Melee attacks in Apex give a brief lunge forward. Punch boosting exploits
this for extra speed.

```
THE BASIC PUNCH BOOST:
  1. Sprint forward
  2. Jump
  3. Melee (punch) in the air
  4. The melee lunge adds ~50 u/s to your air speed
  
  BEST USE: Getting across small gaps you can't quite make.
  The melee lunge extends your jump distance slightly.

THE TEAMMATE PUNCH BOOST:
  1. Stand behind your teammate
  2. Have them punch you
  3. You get knocked forward slightly
  4. If you're already slide-jumping, the punch adds momentum
  
  THIS IS MOSTLY A MEME. But it works in casual games for laughs.

THE DOWNED-PLAYER PUNCH:
  1. Enemy is downed near a wall
  2. Melee them → the lunge pushes you toward the wall
  3. Wall bounce off → now you're moving at high speed
  
  Useful in chaotic fights to reposition while finishing a down.
```

---

## Gravity Cannon Tech

Gravity cannons are free movement tools scattered around certain maps.
Most players just walk into them. Movement players optimize them.

```
GRAVITY CANNON BASICS:
  Walk into cannon → launched in a fixed arc
  You CAN control where you land using air strafes.

GRAVITY CANNON + AIR STRAFE:
  1. Enter cannon normally
  2. While flying, air strafe left or right
  3. You curve your trajectory significantly
  4. Land somewhere enemies don't expect
  
  Default landing zone: Where everyone lands. Enemies aim there.
  Air-strafed landing zone: 20-30 meters off to the side. Unexpected.

GRAVITY CANNON + TAP-STRAFE:
  1. Enter cannon
  2. At the PEAK of your arc, tap-strafe
  3. You can do a near-180° direction change
  4. You literally fly backwards from a gravity cannon
  
  THIS IS ADVANCED. But when you pull it off, the enemy who was
  waiting at your landing zone is now wondering where you went.

GRAVITY CANNON + WEAPON SWAP:
  You CAN swap weapons and reload while in a gravity cannon arc.
  Use the flight time to:
  - Reload your weapons
  - Swap to a shotgun for the landing
  - Pop a shield cell (if you time it right)
```

---

## Combining Techniques

The real movement gods don't use one technique at a time. They chain
everything together into fluid movement sequences.

### The Movement Chain Framework

```
LEVEL 1: Single techniques (most players get stuck here)
  Slide-jump OR wall bounce OR air strafe
  
LEVEL 2: Two-technique combos
  Slide-jump → air strafe
  Wall bounce → air strafe
  Superglide → slide-jump

LEVEL 3: Three-technique chains  
  Slide-jump → wall bounce → air strafe
  Superglide → tap-strafe → slide-jump
  Grapple → air strafe → slide-jump

LEVEL 4: Full movement sequences (movement gods)
  Slide-jump → wall bounce → 180° turn → tap-strafe →
  slide-jump → edge boost → superglide → air strafe →
  zipline jump → land → slide-jump
  
  This is what it looks like when someone "has cracked movement."
  Each technique flows into the next without any dead time.
```

### Practice Combos (Firing Range)

```
COMBO 1: "The Basics" (5 minutes)
  Slide-jump → air strafe left → land → slide-jump → air strafe right
  Repeat across the firing range. Never stop moving.
  GOAL: Zero pauses between slide-jumps.

COMBO 2: "The Wall Dance" (5 minutes)
  Find two parallel walls → wall bounce between them continuously.
  GOAL: 5 consecutive bounces without touching the ground normally.

COMBO 3: "The Ledge Launch" (5 minutes)
  Superglide off a box → slide-jump on landing → wall bounce.
  GOAL: Maintain speed through the entire chain.

COMBO 4: "The Full Send" (5 minutes)
  Slide-jump → wall bounce → 180° tap-strafe → slide-jump → 
  superglide off a ledge.
  GOAL: Hit this sequence 3 times in a row without breaking the chain.
```

### Movement Decision Tree

```
SITUATION                         → TECHNIQUE TO USE
──────────────────────────────────|─────────────────────────
Open ground, need to cross fast   → Slide-jump chain
Wall nearby, enemy shooting       → Wall bounce away
Chest-high ledge nearby           → Superglide off it
On a zipline, getting shot        → Zip strafe (jump off/on)
Need vertical position            → Climb + superglide
In a corridor, enemy at end       → Bounce between walls
Running from enemy, wall ahead    → Wall bounce 180° into shotgun
Healing while running             → Bunny hop heal
Gravity cannon available          → Cannon + air strafe to unexpected spot
Enemy holding high ground         → Wall bounce up + tap-strafe onto them
```

---

*Next up: Training Routine → Daily drills to make all of this automatic.*
