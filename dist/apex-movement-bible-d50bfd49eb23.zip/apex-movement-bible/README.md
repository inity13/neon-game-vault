# Apex Movement Bible — Master Advanced Movement Mechanics

> **Price:** $5 | **Skill Level:** Intermediate to Advanced | **Format:** Markdown Guides + JSON Configs

## What Is This?

The Apex Movement Bible is a deep-dive into the advanced movement mechanics that separate average players from movement gods. From tap-strafing to wall-bouncing to superglides, every technique is broken down frame-by-frame with input sequences, practice drills, and troubleshooting guides.

**Movement is the #1 skill that determines fights in Apex.** Aim matters, but a player with S-tier movement and B-tier aim will beat a player with S-tier aim and B-tier movement every time. This guide teaches you WHY.

## What's Included

| File | Description |
|------|-------------|
| `src/movement_fundamentals.md` | Core movement: slide-jumping, bunny hopping, momentum management |
| `src/tap_strafing.md` | Complete tap-strafe guide: basic, advanced, 180°, lurch mechanics |
| `src/wall_bouncing.md` | Wall-bounce techniques: basic, redirected, chained, combat applications |
| `src/superglides.md` | Superglide mechanics: timing windows, consistent setup, zipline supers |
| `src/advanced_techniques.md` | Fatigue slide, neo-strafe, punch boost, gravity cannon tricks |
| `src/combat_movement.md` | Movement in fights: strafe patterns, crouch spam, jiggle peeks |
| `src/practice_drills.md` | Structured practice routines from beginner to advanced |
| `examples/settings_configs.json` | Optimal movement settings and keybind recommendations |

## Quick Preview

Here's a taste from the tap-strafing guide:

### What Is a Tap-Strafe?

A tap-strafe lets you **change direction mid-air without losing speed**. Normally, turning in the air slows you down. Tap-strafing exploits a mechanic called "lurch" to redirect your momentum instantly.

```
NORMAL AIR MOVEMENT:
  Speed: 100% ──→ Turn ──→ Speed: 60%
  You slow down when you change direction. Predictable.

TAP-STRAFE:
  Speed: 100% ──→ Tap-strafe ──→ Speed: 95%+
  You keep almost all your speed. Unpredictable.

WHY IT'S POWERFUL:
  1. Dodge bullets mid-air
  2. Change direction around corners at full speed
  3. Escape situations that seem inescapable
  4. Make yourself nearly impossible to track
```

### Basic Tap-Strafe Input Sequence

```
SETUP: You must be in the air with forward momentum.

Step 1: Sprint + Slide-jump forward (build momentum)
Step 2: Release W (forward key) while in the air
Step 3: Rapidly tap W (scroll wheel recommended) while
        holding A or D (strafe direction)
Step 4: Move mouse in the direction you want to go

Timing diagram:
  ─── Ground ───┃ Air ──────────────────────
  [Sprint+Slide] [Jump]  [Tap W×5+Hold A]  [Land]
                  ↑        ↑
                  Release W  Mouse left
                  
Input breakdown (frame-by-frame):
  Frame 0:   Jump (leave ground with forward momentum)
  Frame 1-2: Release W
  Frame 3:   Hold A + start tapping W rapidly
  Frame 4-8: Continue tapping W (3-5 taps)
  Frame 9+:  Moving mouse in strafe direction
```

*The full guide covers 180° tap-strafes, tap-strafing off jump pads, combining with wall-bounces, and lurch value theory.*

## Who This Is For

- **Intermediate players** who've mastered basic movement and want the next level
- **Competitive players** preparing for ranked or tournaments
- **Movement enthusiasts** who find tech skill satisfying to master
- **Content creators** looking for flashy movement clips

## How to Use This Guide

1. **Start with `movement_fundamentals.md`** even if you think you know the basics — there are optimization details most players miss
2. **Pick ONE advanced technique** (tap-strafe, wall-bounce, OR superglide) and master it before moving to the next
3. **Use `practice_drills.md`** for structured daily practice (15-30 min)
4. **Read `combat_movement.md`** to apply movement in actual fights
5. **Apply `settings_configs.json`** settings recommendations for optimal input

## FAQ

**Q: Can I tap-strafe on controller?**
A: Traditional tap-strafing requires rapid W inputs (scroll wheel), which isn't available on controller. However, the combat movement and wall-bounce sections apply to all input methods.

**Q: Will these techniques get patched?**
A: Some (like tap-strafing) have survived multiple patch cycles and are considered features at this point. The guide notes which techniques are stable and which might change.

**Q: How long until I can do these consistently?**
A: Basic tap-strafes: 1-3 days of focused practice. Wall-bounces: 3-7 days. Superglides: 1-2 weeks for consistency. Chaining techniques: 2-4 weeks.

## License

MIT License — see LICENSE file.
