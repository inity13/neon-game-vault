# Weapon Recommendations — By Role and Budget

> The right weapon can be a bigger damage increase than a full artifact set.

---

## Weapon Selection Principles

```
RULE 1: Match the weapon's stat to the character's needs
  Base ATK + secondary stat define the weapon's identity:
  • Crit Rate/DMG weapons → DPS characters
  • ER% weapons → Support/Sub DPS
  • EM weapons → Reaction triggers
  • HP%/DEF% weapons → Scaling supports

RULE 2: Weapon passive matters as much as stats
  A weapon with a perfect passive for your character can
  outperform a weapon with better raw stats.

RULE 3: Refinement matters for 4-star weapons
  4-star weapons at R5 often match 5-star weapons at R1.
  If you have duplicates, refine!

RULE 4: F2P weapons are viable for ALL content
  You don't need gacha weapons to clear Spiral Abyss.
  Craftable and event weapons are competitive.
```

---

## Weapon Recommendations by Role

### Main DPS Weapons

```
PRIORITY: Crit Rate/DMG secondary > ATK% > EM

SWORD DPS:
  S Tier: 5★ Crit weapons (base ATK 674, Crit substat)
  A Tier: 4★ Crit weapons, battle pass weapons
  F2P:    Prototype Rancour (Physical), Amenoma Kageuchi (Elemental)
          Iron Sting (Reaction/EM), Harbinger of Dawn (budget Crit)

CLAYMORE DPS:
  S Tier: 5★ Crit weapons
  A Tier: 4★ Crit weapons, Serpent Spine (battle pass — BEST 4★)
  F2P:    Prototype Archaic (universal), Whiteblind (DEF scaling)
          Snow-Tombed Starsilver (Physical), Luxurious Sea-Lord (Burst)

POLEARM DPS:
  S Tier: 5★ Crit weapons
  A Tier: Deathmatch (battle pass), Dragon's Bane (reaction)
  F2P:    Prototype Starglitter (ER), Crescent Pike (Physical)
          White Tassel (Normal ATK), Kitain Cross Spear (EM)

BOW DPS:
  S Tier: 5★ Crit weapons
  A Tier: 4★ Crit weapons, Viridescent Hunt (battle pass)
  F2P:    Prototype Crescent (aimed shot), Hamayumi (Normal ATK)
          Slingshot (3★ but good Crit Rate!)

CATALYST DPS:
  S Tier: 5★ Crit weapons
  A Tier: 4★ Crit weapons, Solar Pearl (battle pass)
  F2P:    Mappa Mare (EM), Prototype Amber (HP/heal)
          Dodoco Tales (event), Hakushin Ring (ER)
```

### Sub DPS / Burst DPS Weapons

```
PRIORITY: ER% (if needed) > Crit > ATK% > EM

UNIVERSAL RULE:
  If your Burst isn't ready every rotation → ER% weapon
  If your Burst IS ready every rotation  → Crit/ATK weapon

TOP ER WEAPONS (any weapon type):
  5★: Various ER 5-stars (base ATK + ER secondary)
  4★: Favonius series (ER + generates energy particles on Crit)
      The Catch (polearm, FREE from fishing — incredible value!)
      Sacrificial series (ER + resets skill cooldown)
  
THE CATCH IS THE BEST FREE WEAPON IN THE GAME:
  • Free from fishing (no gacha, no crafting)
  • ER% secondary (solves energy problems)
  • +32% Burst DMG, +12% Burst Crit Rate at R5
  • Perfect for ANY polearm burst DPS
  • Seriously, go fishing. It's worth it.
```

### Support Weapons

```
PRIORITY: ER% > Support passive > HP%/DEF%

FAVONIUS SERIES (S Tier for supports):
  WHY? ER% substat + passive generates neutral energy particles
  Every weapon type has a Favonius version
  Give Crit Rate to trigger the passive (only needs ~40% CR)
  
SACRIFICIAL SERIES (S Tier for specific supports):
  WHY? ER% substat + passive resets Elemental Skill cooldown
  Double skill = double particles = way more energy
  Best on: Characters with long skill cooldowns
  
THRILLING TALES OF DRAGON SLAYERS (3★ Catalyst — S TIER!):
  WHY? Swapping to next character gives them +48% ATK for 10s
  The strongest ATK buff from a weapon in the game
  Put on ANY catalyst support. It's free and broken.
  R5 it immediately (3★ weapons are common from wishes).
```

---

## F2P Weapon Tier List

```
ABSOLUTELY MUST-HAVE (Free):
  1. The Catch (Polearm) — From fishing. Best free weapon period.
  2. Thrilling Tales R5 (Catalyst) — 3★, +48% ATK buff
  3. Harbinger of Dawn R5 (Sword) — 3★, Crit Rate + Crit DMG (off-field only)
  4. Prototype weapons (Craftable) — Good for characters without better options

BATTLE PASS WEAPONS (Paid but affordable):
  1. Serpent Spine (Claymore) — Competes with 5★ weapons
  2. Solar Pearl (Catalyst) — Great for catalyst DPS
  3. Deathmatch (Polearm) — Consistent Crit Rate
  4. Viridescent Hunt (Bow) — Crit Rate + grouping passive
  5. The Black Sword (Sword) — Crit Rate + self-healing

STARGLITTER SHOP:
  Blackcliff weapons (Crit DMG substat) — Decent option if nothing better
  Royal weapons — AVOID! The passive is a trap (bad math).
```

---

## Weapon-Character Matching Decision Tree

```
Does the character need their Burst every rotation?
├── YES → Is their ER currently below the threshold?
│         ├── YES → Use ER% weapon (Favonius/Sacrificial/ER secondary)
│         └── NO  → Use Crit/DMG weapon
│
└── NO → What's their primary damage source?
          ├── Normal/Charged Attacks → ATK% or Crit weapon
          ├── Elemental Skill → Skill-boosting passive weapon
          ├── Reactions → EM weapon
          └── Support/Buff → Support passive weapon (TTDS, Favonius)
```

---

## Weapon Level Priority

```
ALWAYS level weapons to 90. Unlike characters, weapons gain significant
base ATK from levels 80-90, and the cost is reasonable.

Level priority:
  1. Main DPS weapon → 90/90 (biggest damage increase)
  2. Sub DPS weapon → 90/90 (still important)
  3. Support weapon → 80/90 or 90/90 (less urgent)
  4. Healer weapon → 70/80 is fine (healing doesn't need high base ATK)

NEVER leave a weapon at 80. The jump to 90 is cheap relative
to the ATK increase you get.
```
