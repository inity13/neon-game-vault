# Team Archetypes — 12 Proven Team Templates

> Pick an archetype, fill the slots with your characters, and win.

---

## How to Use This Guide

Each archetype has:
- **Core Concept:** Why this team works
- **Role Slots:** What each position needs
- **Key Requirements:** What makes or breaks the team
- **Strengths & Weaknesses:** Know what you're signing up for

Fill each slot with the best character you have that fits the description.

---

## Archetype 1: Vaporize Carry

```
CONCEPT: Pyro DPS triggers Vaporize (×1.5-2.0) for massive damage.

SLOTS:
  [1] Pyro Main DPS      — Your on-field damage dealer
  [2] Hydro Off-field     — Continuous Hydro application (enables Vaporize)
  [3] Anemo Support       — Viridescent Venerer (-40% Pyro Res) + grouping
  [4] Flex (Buff/Heal)    — ATK buffer, healer, or shielder

KEY REQUIREMENTS:
  ✅ Hydro applicator must keep up with Pyro consumption
  ✅ Anemo must swirl Pyro (not Hydro) for VV debuff
  ✅ Pyro DPS needs some EM (100-200) for reaction bonus

STRENGTHS: Highest single-target damage potential
WEAKNESSES: Requires good Hydro application, rotation-sensitive
```

## Archetype 2: Melt Carry

```
CONCEPT: Cryo DPS triggers Reverse Melt (×1.5) on Pyro-aura enemies.

SLOTS:
  [1] Cryo Main DPS       — Charged attack or burst focused
  [2] Pyro Off-field       — Continuous Pyro application
  [3] Anemo/Cryo Support   — VV shred or Cryo resonance
  [4] Shielder/Healer      — Survivability (Melt teams are aggressive)

KEY REQUIREMENTS:
  ✅ Pyro applicator must be fast enough to maintain Pyro aura
  ✅ Cryo DPS's key hits must be the ones triggering Melt
  ✅ Watch ICD — not every Cryo hit will trigger Melt

STRENGTHS: Very high burst damage, great for bosses
WEAKNESSES: Hard to maintain Pyro aura, requires precise rotation
```

## Archetype 3: Freeze Team

```
CONCEPT: Permanently freeze enemies. They can't attack or move.

SLOTS:
  [1] Cryo Main DPS        — Benefits from Blizzard Strayer 4pc (+40% Crit Rate)
  [2] Hydro Off-field       — Continuous Hydro for Freeze uptime
  [3] Anemo Grouper         — Groups enemies + VV shred Cryo
  [4] Cryo Battery          — Energy + Cryo Resonance (+15% Crit)

KEY REQUIREMENTS:
  ✅ Both Cryo and Hydro application must be fast and continuous
  ✅ NO Pyro or Electro — they break Freeze!
  ✅ Cryo DPS runs Blizzard Strayer (free Crit Rate from set + resonance)

STRENGTHS: 
  • Enemies can't fight back (safety)
  • Cryo DPS gets 55%+ free Crit Rate (Blizzard + Resonance + Cryo Aura)
  • Can build all Crit DMG instead of Crit Rate
WEAKNESSES:
  • Doesn't work on bosses (most are immune to Freeze)
  • NO reaction damage (Freeze isn't a damage reaction)
  • Requires specific element pairing (no flexibility)
```

## Archetype 4: Taser (Electro-Charged)

```
CONCEPT: Electro + Hydro + Anemo for constant AOE damage and reactions.

SLOTS:
  [1] Hydro On-field       — Normal attacks apply Hydro
  [2] Electro Off-field    — Continuous Electro application
  [3] Electro Off-field #2 — More Electro + Electro resonance
  [4] Anemo Support        — VV shred + grouping + Swirl

OR (variant):
  [1] Electro On-field     — Normal attacks apply Electro
  [2] Hydro Off-field      — Continuous Hydro application
  [3] Anemo Support        — VV shred + grouping
  [4] Flex (Heal/Buffer)   — Survivability or more damage

KEY REQUIREMENTS:
  ✅ Both Electro and Hydro must be applied consistently
  ✅ Anemo character with EM build (Swirl damage is significant)
  ✅ Healer recommended (Electro-Charged doesn't crowd control)

STRENGTHS: Great AOE, many simultaneous reactions, flexible
WEAKNESSES: No crowd control, moderate single-target
```

## Archetype 5: National Team

```
CONCEPT: The "everything works" team. Reactions everywhere.

SLOTS:
  [1] Pyro Burst DPS       — High-damage Burst + Pyro application
  [2] Hydro Off-field       — Enables Vaporize
  [3] Cryo Off-field        — Enables Melt + energy battery
  [4] ATK Buffer            — Makes everyone's Burst hit harder

KEY REQUIREMENTS:
  ✅ All 4 characters have cheap, powerful Elemental Bursts
  ✅ Quickswap playstyle — everyone takes turns, no one stays on-field long
  ✅ High ER on all characters (140-200%)

STRENGTHS:
  • Works against everything (no bad matchups)
  • Doesn't need specific 5-star characters
  • Multiple reaction types = consistent damage
WEAKNESSES:
  • High ER requirements (lots of ER substats needed)
  • Rotation can feel busy/complex
  • No dedicated shielder (skill-based survival)
```

## Archetype 6: Hypercarry (One DPS + 3 Supports)

```
CONCEPT: Pour ALL your resources into one character. Everyone else exists to buff them.

SLOTS:
  [1] Main DPS             — Your best, most invested character
  [2] ATK/DMG Buffer       — Increases DPS's attack or damage%
  [3] Res Shredder/Buffer  — Reduces enemy resistance or provides more buffs
  [4] Healer/Shielder      — Keeps the carry alive and uninterrupted

KEY REQUIREMENTS:
  ✅ DPS must be VERY well built (high investment)
  ✅ Buffs must stack multiplicatively (ATK% + DMG% + Crit, not ATK% + ATK% + ATK%)
  ✅ Supports should buff first, then stay off-field

STRENGTHS: Simple rotation, one character does all the work
WEAKNESSES: If the carry dies, the team does nothing
```

## Archetype 7: Quickswap (Burst Spam)

```
CONCEPT: Everyone has a powerful Burst. Cycle through all 4, repeat.

SLOTS:
  [1] Burst DPS A          — 60-80 energy cost, high damage
  [2] Burst DPS B          — 60-80 energy cost, high damage
  [3] Burst DPS C          — Provides buffs + burst damage
  [4] Battery/Support      — Generates energy + utility

KEY REQUIREMENTS:
  ✅ 180-220% ER on everyone (you NEED Bursts every rotation)
  ✅ Short Burst animations (long cinematics waste DPS time)
  ✅ Complementary elements (reactions between Bursts)

STRENGTHS: High burst damage windows, no single point of failure
WEAKNESSES: Very ER hungry, relies on having all Bursts ready
```

## Archetype 8: Bloom Team

```
CONCEPT: Dendro + Hydro creates Dendro Cores that explode for AOE damage.

SLOTS:
  [1] Dendro Applicator    — Consistent Dendro application
  [2] Hydro Applicator     — Consistent Hydro for Bloom cores
  [3] Flex (Pyro or Electro) — Burgeon (Pyro) or Hyperbloom (Electro)
  [4] Healer               — Bloom cores damage you too!

VARIANTS:
  Hyperbloom (+ Electro): Cores become homing missiles, high single-target
  Burgeon (+ Pyro): Cores explode for bigger AOE, risky self-damage
  Pure Bloom: Just Dendro + Hydro, simpler but less optimized

KEY REQUIREMENTS:
  ✅ Whoever triggers Burgeon/Hyperbloom needs full EM build
  ✅ Healer is almost mandatory (cores deal self-damage)
  ✅ Hydro application must keep up with Dendro

STRENGTHS: Very high AOE damage, scales with EM (cheap to build)
WEAKNESSES: Self-damage from cores, complex reaction management
```

## Archetype 9: Aggravate/Spread (Quicken)

```
CONCEPT: Dendro + Electro creates Quicken state, boosting subsequent hits.

SLOTS:
  [1] Electro DPS          — Multi-hit attacks (each hit gets Aggravate bonus)
  [2] Dendro Off-field      — Maintain Quicken aura
  [3] Anemo Support         — VV shred Electro or Dendro
  [4] Flex (Buffer/Healer)  — ATK buffer or survivability

KEY REQUIREMENTS:
  ✅ DPS should have fast, multi-hit attacks (more Aggravate procs)
  ✅ EM is valuable (Aggravate bonus scales with EM)
  ✅ Dendro applicator must be consistent

STRENGTHS: Easy to play, consistent damage, no ICD issues
WEAKNESSES: Moderate damage ceiling, limited to Electro/Dendro carries
```

## Archetype 10: Physical Carry

```
CONCEPT: Physical DPS + Superconduct for -40% Physical Resistance.

SLOTS:
  [1] Physical Main DPS     — Auto-attack focused, physical damage goblet
  [2] Cryo Off-field        — For Superconduct (must be present!)
  [3] Electro Off-field     — For Superconduct (must be present!)
  [4] Buffer/Healer         — ATK buffer or survivability

KEY REQUIREMENTS:
  ✅ MUST have both Cryo AND Electro for Superconduct
  ✅ DPS builds Physical DMG% goblet (not elemental)
  ✅ Superconduct refreshed every 12 seconds

STRENGTHS: Works against any element (physical is neutral)
WEAKNESSES: Lower ceiling than reaction teams, needs specific element combo
```

## Archetype 11: Geo Core

```
CONCEPT: Geo + Geo resonance for consistent, reaction-independent damage.

SLOTS:
  [1] Geo Main DPS          — On-field Geo damage dealer
  [2] Geo Support            — Geo Resonance + energy battery
  [3] Off-field DPS          — Any element, adds extra damage
  [4] Healer/Shielder        — Activates Geo Resonance bonus

KEY REQUIREMENTS:
  ✅ Must have a shielder (Geo Resonance bonus requires shield)
  ✅ Two Geo characters for resonance (+15% DMG while shielded)
  ✅ Third slot provides reactions or additional utility

STRENGTHS: Extremely consistent (no reaction management), very tanky
WEAKNESSES: Lower damage ceiling, limited elemental reactions
```

## Archetype 12: Mono-Element

```
CONCEPT: 3-4 characters of the same element, maximizing resonance + batteries.

SLOTS:
  [1] [Element] Main DPS     — Primary damage dealer
  [2] [Element] Sub DPS      — Off-field damage of same element
  [3] [Element] Battery      — Energy generation for the team
  [4] Anemo Support          — VV shred for the main element

BEST MONO ELEMENTS:
  Mono Pyro:   +25% ATK resonance, strong element generally
  Mono Cryo:   +15% Crit Rate, works with Freeze if Hydro added
  Mono Geo:    +15% DMG while shielded, naturally tanky
  Mono Hydro:  +25% HP, good for HP-scaling characters

KEY REQUIREMENTS:
  ✅ An Anemo VV holder is almost always the 4th slot
  ✅ All characters share energy efficiently
  ✅ No reaction damage — relies on raw elemental power + buffs

STRENGTHS: Very energy-efficient, simple team building
WEAKNESSES: No reaction damage, element-locked matchups
```
