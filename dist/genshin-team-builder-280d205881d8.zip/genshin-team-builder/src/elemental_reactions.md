# Elemental Reactions — Complete Reference

> Understanding reactions is the difference between 10K and 100K damage.

---

## Reaction Categories

There are three types of elemental reactions:

```
┌───────────────────────────────────────────────────────────────┐
│  AMPLIFYING REACTIONS                                         │
│  Multiply the triggering hit's damage by 1.5× or 2.0×        │
│  Scale with: ATK, Crit, Elemental Mastery, DMG%              │
│  These are the STRONGEST reactions for raw damage.            │
│                                                               │
│  • Vaporize (Pyro + Hydro)                                    │
│  • Melt (Pyro + Cryo)                                         │
├───────────────────────────────────────────────────────────────┤
│  TRANSFORMATIVE REACTIONS                                     │
│  Deal flat damage based on character level and EM             │
│  Scale with: Level, Elemental Mastery, enemy resistance       │
│  Ignore ATK, Crit, DMG%. Useful for EM-stacking characters.  │
│                                                               │
│  • Overloaded (Pyro + Electro)                                │
│  • Electro-Charged (Electro + Hydro)                          │
│  • Superconduct (Cryo + Electro)                              │
│  • Swirl (Anemo + Pyro/Hydro/Electro/Cryo)                   │
│  • Shatter (Claymore/Geo/Plunge on Frozen)                    │
│  • Bloom/Hyperbloom/Burgeon (Dendro reactions)                │
├───────────────────────────────────────────────────────────────┤
│  SPECIAL REACTIONS                                            │
│  Create a state or effect rather than dealing direct damage   │
│                                                               │
│  • Freeze (Cryo + Hydro) — immobilizes enemies                │
│  • Crystallize (Geo + element) — creates shield pickup        │
│  • Burning (Pyro + Dendro) — continuous Pyro damage           │
│  • Quicken (Electro + Dendro) — enables Aggravate/Spread      │
└───────────────────────────────────────────────────────────────┘
```

---

## Amplifying Reactions (Deep Dive)

### Vaporize

```
VAPORIZE (Pyro ↔ Hydro):

  Hydro → Pyro trigger = FORWARD Vaporize (×2.0 damage)
  Pyro → Hydro trigger = REVERSE Vaporize (×1.5 damage)

  WHY the difference?
  The "aura" element (applied first) determines the multiplier.
  Pyro aura + Hydro trigger = 2.0× (because Hydro is "strong" vs Pyro)
  Hydro aura + Pyro trigger = 1.5× (because Pyro is "weak" vs Hydro)

  PRACTICAL USE:
  For maximum damage, you want your BIG hits to trigger the 2.0× version.
  
  Setup: Apply Pyro to enemy (with sub DPS)
  Trigger: Hit with Hydro DPS's big attack (gets 2.0× multiplier)
  
  OR (more common):
  Setup: Apply Hydro continuously (with off-field Hydro applicator)
  Trigger: Hit with Pyro DPS's charged/burst (gets 1.5×, but easier to use)
```

### Melt

```
MELT (Pyro ↔ Cryo):

  Cryo → Pyro trigger = FORWARD Melt (×2.0 damage)
  Pyro → Cryo trigger = REVERSE Melt (×1.5 damage)

  PRACTICAL USE:
  Forward Melt (2.0×) is harder to use because Pyro "eats" Cryo aura quickly.
  You need a STRONG Cryo applicator that keeps up with Pyro consumption.
  
  Reverse Melt (1.5×) is easier — Cryo doesn't eat Pyro aura as fast.
  Apply Pyro off-field, then hit with Cryo attacks.
```

### Amplifying Damage Formula

```
REACTION DAMAGE = Base Hit × Reaction Multiplier × EM Bonus

  EM Bonus = 2.78 × EM / (EM + 1400)
  
  Example: 10,000 base hit, Forward Vaporize, 200 EM
    EM Bonus = 2.78 × 200 / (200 + 1400) = 0.3475 (34.75%)
    Reaction DMG = 10,000 × 2.0 × (1 + 0.3475)
                 = 10,000 × 2.0 × 1.3475
                 = 26,950

  KEY INSIGHT: EM has diminishing returns.
    0 → 100 EM:   +0% → +17.7% (big jump!)
    100 → 200 EM: +17.7% → +34.7% (still good)
    200 → 300 EM: +34.7% → +49.3% (slowing down)
    300 → 500 EM: +49.3% → +73.5% (diminishing)
    
  SWEET SPOT: 100-300 EM for amplifying reaction carries
  Don't sacrifice Crit or ATK just for more EM past 300.
```

---

## Transformative Reactions (Deep Dive)

### Superconduct

```
SUPERCONDUCT (Cryo + Electro):

  Effect: AOE Cryo damage + reduces enemy PHYSICAL Resistance by 40%
  Duration: 12 seconds
  
  WHY IT MATTERS:
  -40% Physical Resistance is HUGE for physical damage dealers.
  If an enemy has 10% Phys Res:
    Before Superconduct: 10% Phys Res (enemies resist 10% of damage)
    After Superconduct:  -30% Phys Res (enemies TAKE 15% MORE damage)
    
  ESSENTIAL for: Physical carry teams
  USELESS for: Elemental carry teams (doesn't help elemental damage)
```

### Swirl

```
SWIRL (Anemo + Pyro/Hydro/Electro/Cryo):

  Effect: AOE damage of the swirled element + spreads that element
  
  WHY SWIRL IS THE BEST SUPPORT REACTION:
  1. Spreads elements to grouped enemies (sets up chain reactions)
  2. Anemo characters can hold 4pc Viridescent Venerer artifact set:
     → -40% Elemental Resistance to the swirled element!
     → This is THE strongest debuff in the game
  3. Swirl damage itself scales with EM (can be significant)
  
  EXAMPLE:
  Enemy has Pyro applied → Anemo character Swirls it
  → -40% Pyro Resistance on that enemy (from Viridescent 4pc)
  → Pyro DPS now deals 33% more Pyro damage to that enemy
  → This is basically a permanent +33% damage boost for your carry
  
  THIS IS WHY ANEMO SUPPORTS ARE IN EVERY META TEAM.
```

### Electro-Charged

```
ELECTRO-CHARGED (Electro + Hydro):

  Effect: Continuous Electro damage ticks + both elements coexist
  
  UNIQUE PROPERTY: Both Electro AND Hydro stay on the enemy!
  This means you can trigger a THIRD reaction:
    Electro-Charged enemy + Pyro = Vaporize AND Overloaded
    Electro-Charged enemy + Cryo = Freeze AND Superconduct
    
  This makes Electro-Charged a great "bridge" reaction for teams
  that want to enable multiple reactions at once.
```

### Dendro Reactions

```
DENDRO REACTION CHAIN:

  Dendro + Hydro = Bloom (creates Dendro Cores)
    → Cores explode after 6s for AOE Dendro damage
    → Cores + Pyro = Burgeon (stronger explosion)
    → Cores + Electro = Hyperbloom (homing missile)
    
  Dendro + Electro = Quicken (applies Quickened state)
    → Quickened + Electro = Aggravate (+flat Electro damage)
    → Quickened + Dendro = Spread (+flat Dendro damage)
    
  Dendro + Pyro = Burning (continuous Pyro damage)
    → Generally not great — hard to control

  BEST DENDRO REACTIONS:
    Hyperbloom (Dendro + Hydro + Electro): High single-target DPS
    Aggravate (Dendro + Electro): Easy to use, consistent damage
    Bloom (Dendro + Hydro): Good AOE, needs careful team building
```

---

## Reaction Priority by Team Type

```
TEAM GOAL          │ BEST REACTIONS           │ AVOID
───────────────────┼──────────────────────────┼──────────────
Single Target DPS  │ Vaporize, Melt           │ Overloaded (knockback!)
AOE DPS            │ Swirl, Overloaded, Bloom │ Superconduct
Freeze/CC          │ Freeze + Shatter         │ Anything that breaks Freeze
Physical DPS       │ Superconduct (mandatory!)│ Elemental reactions
Dendro Quickswap   │ Aggravate, Spread        │ Burning
Shield-based       │ Crystallize              │ N/A (reactions are secondary)
```

---

## Internal Cooldown (ICD) — Advanced

```
WHAT IS ICD?
  Most abilities can only trigger a reaction once every 2.5 seconds
  OR once every 3 hits, whichever comes first.
  
  This is called the "2.5s / 3-hit" rule.

WHY IT MATTERS:
  If your Pyro carry attacks 5 times in 2 seconds:
    Hit 1: Triggers Vaporize ✅ (1st hit)
    Hit 2: No reaction ❌ (ICD)
    Hit 3: Triggers Vaporize ✅ (3rd hit, resets)
    Hit 4: No reaction ❌ (ICD)
    Hit 5: No reaction ❌ (ICD, timer hasn't reset)
    
  Only 2 out of 5 hits got the reaction bonus!

EXCEPTIONS (NO ICD — every hit can react):
  Some abilities have no ICD, meaning EVERY hit triggers reactions.
  These abilities are incredibly valuable for reaction teams.
  
  Check character guides for ICD info on specific abilities.
  General rule: Charged attacks and burst hits are more likely to have no ICD.
```
