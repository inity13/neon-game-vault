# Synergy Charts — Element × Element Interaction Matrix

> Quick-reference for which elements work together and why.

---

## Master Synergy Matrix

```
How to read: Row = Element already on enemy. Column = Element you apply.
Result shows the reaction and rating (★ = power level).

          │ Pyro    │ Hydro   │ Electro │ Cryo    │ Anemo   │ Geo     │ Dendro  │
──────────┼─────────┼─────────┼─────────┼─────────┼─────────┼─────────┼─────────┤
Pyro      │ —       │Vape 2.0★│Overload │Melt 1.5★│Swirl   ★│Crystal  │Burning  │
(on enemy)│         │★★★★★    │★★★      │★★★★     │★★★★★   │★★       │★        │
──────────┼─────────┼─────────┼─────────┼─────────┼─────────┼─────────┼─────────┤
Hydro     │Vape 1.5★│ —       │EC      ★│Freeze  ★│Swirl   ★│Crystal  │Bloom   ★│
(on enemy)│★★★★     │         │★★★      │★★★★★   │★★★★★   │★★       │★★★★    │
──────────┼─────────┼─────────┼─────────┼─────────┼─────────┼─────────┼─────────┤
Electro   │Overload │EC      ★│ —       │SC      ★│Swirl   ★│Crystal  │Quicken ★│
(on enemy)│★★★      │★★★      │         │★★★★    │★★★★★   │★★       │★★★★    │
──────────┼─────────┼─────────┼─────────┼─────────┼─────────┼─────────┼─────────┤
Cryo      │Melt 2.0★│Freeze  ★│SC      ★│ —       │Swirl   ★│Crystal  │ —       │
(on enemy)│★★★★★    │★★★★★   │★★★★    │         │★★★★★   │★★       │         │
──────────┼─────────┼─────────┼─────────┼─────────┼─────────┼─────────┼─────────┤
Dendro    │Burning  │Bloom   ★│Quicken ★│ —       │ —       │ —       │ —       │
(on enemy)│★        │★★★★    │★★★★    │         │         │         │         │
──────────┴─────────┴─────────┴─────────┴─────────┴─────────┴─────────┴─────────┘

★★★★★ = Incredible synergy (build teams around this)
★★★★  = Strong synergy (great in most situations)
★★★   = Good synergy (situationally powerful)
★★    = Okay synergy (niche use)
★     = Weak synergy (generally avoid)
```

---

## Element Pair Analysis

### Pyro + Hydro (★★★★★)

```
REACTIONS: Vaporize (1.5× or 2.0× depending on order)
WHY TOP TIER: Highest consistent damage amplification in the game.
BEST FOR: Single-target DPS, boss fights, Spiral Abyss

Team structures:
  • Hydro carry + Pyro off-field → 2.0× Forward Vaporize
  • Pyro carry + Hydro off-field → 1.5× Reverse Vaporize
  • Both are meta-defining team types
```

### Cryo + Hydro (★★★★★)

```
REACTIONS: Freeze (crowd control)
WHY TOP TIER: Enemies literally cannot move or attack.
BEST FOR: AOE content, mob floors, comfortable gameplay

Team structures:
  • Cryo DPS + Hydro off-field + Anemo grouper + Cryo battery
  • Cryo DPS gets free Crit Rate from Blizzard Strayer + Resonance
  • Safest team archetype in the game
```

### Cryo + Pyro (★★★★★)

```
REACTIONS: Melt (1.5× or 2.0× depending on order)
WHY TOP TIER: 2.0× Forward Melt is the highest single-hit multiplier.
BEST FOR: Burst damage, one-shot combos, screenshot damage

Team structures:
  • Cryo burst DPS + Pyro off-field → Forward Melt (2.0× on burst)
  • Pyro carry + Cryo off-field → Reverse Melt (1.5× on auto attacks)
  • Harder to use than Vaporize but higher peak damage
```

### Electro + Dendro (★★★★)

```
REACTIONS: Quicken → Aggravate (Electro) / Spread (Dendro)
WHY STRONG: Flat damage bonus on every hit. No ICD concerns.
BEST FOR: Multi-hit Electro or Dendro carries

Team structures:
  • Electro carry + Dendro off-field + Anemo + flex
  • Every Electro hit on a Quickened enemy gets bonus damage
  • Scales with EM + Level + ATK/Crit (multiplicative!)
```

### Hydro + Dendro (★★★★)

```
REACTIONS: Bloom → Hyperbloom (+ Electro) / Burgeon (+ Pyro)
WHY STRONG: Dendro Cores deal massive AOE or single-target damage.
BEST FOR: AOE clearing, F2P-friendly (scales with EM and Level only)

Team structures:
  • Dendro + Hydro core + Electro trigger → Hyperbloom (homing missiles)
  • Dendro + Hydro core + Pyro trigger → Burgeon (big AOE explosions)
  • The trigger character builds full EM for maximum reaction damage
```

### Anemo + Anything (★★★★★)

```
REACTIONS: Swirl (spreads elements + VV shred)
WHY TOP TIER: -40% Elemental Resistance from 4pc Viridescent Venerer
BEST FOR: Every team. Seriously, every team wants an Anemo support.

The math:
  Enemy with 10% Pyro Res → After VV: -30% Pyro Res
  Damage increase: 10% resistance → -30% resistance
  Effective damage increase: ~20-25% MORE damage on every Pyro hit
  
  This is why Anemo is the best support element.
  No other element provides this kind of universal damage increase.
```

### Electro + Cryo (★★★★)

```
REACTIONS: Superconduct (-40% Physical Resistance for 12s)
WHY STRONG: Mandatory for Physical DPS teams.
BEST FOR: Physical carries (polearm, claymore auto-attackers)

Note: Useless for elemental DPS teams. The -40% only affects Physical.
```

### Electro + Hydro (★★★)

```
REACTIONS: Electro-Charged (continuous damage, both elements coexist)
WHY GOOD: Unique property — both elements stay on the enemy.
BEST FOR: Taser teams, multi-reaction setups

Special property:
  EC enemies retain both Hydro AND Electro auras.
  Add Cryo → Freeze AND Superconduct simultaneously!
  Add Pyro → Vaporize AND Overloaded simultaneously!
```

### Electro + Pyro (★★★)

```
REACTIONS: Overloaded (AOE Pyro damage + knockback)
WHY OKAY: Good AOE damage but knocks enemies away.
BEST FOR: Ranged teams, large enemies (can't be knocked back)

WARNING: Knockback is annoying for melee characters.
  You hit the enemy → they fly across the room → you chase them
  This wastes time in timed content. Avoid for Abyss melee teams.
  
EXCEPTION: Large enemies (bosses, Ruin Guards) don't get knocked back.
  Overloaded is actually great against them!
```

### Geo + Anything (★★)

```
REACTIONS: Crystallize (creates elemental shield pickup)
WHY OKAY: Provides small shields. Not a damage reaction.
BEST FOR: Geo teams that don't care about reactions.

Crystallize shields:
  • Very small damage absorption
  • Provide elemental resistance matching the crystal
  • NOT a substitute for a real shielder
  • Main purpose: trigger Geo Resonance (need to be shielded)
```

---

## Team Composition Quick Reference

```
WANT MAXIMUM DAMAGE?
  → Vaporize team (Pyro + Hydro + Anemo + flex)
  → Melt team (Cryo + Pyro + Anemo + flex)

WANT MAXIMUM SAFETY?
  → Freeze team (Cryo + Hydro + Anemo + Cryo)
  → Enemies can't attack you

WANT MAXIMUM COMFORT?
  → National variant (Pyro + Hydro + Cryo + Buffer)
  → Works against everything

WANT MAXIMUM F2P VALUE?
  → Hyperbloom team (Dendro + Hydro + Electro + Healer)
  → Scales with EM and Level, not gacha artifacts

WANT MAXIMUM PHYSICAL?
  → Superconduct team (Physical DPS + Cryo + Electro + Buffer)
  → Mandatory Cryo+Electro for the resistance shred
```

---

## Elements to NEVER Pair (Anti-Synergy)

```
❌ Pyro + Freeze team
   Pyro breaks Freeze immediately. You lose all crowd control.

❌ Electro + Freeze team
   Superconduct shatters Frozen enemies. Same problem.

❌ Geo + Reaction team
   Crystallize consumes the element you need for reactions.
   Your Vaporize team loses its Hydro aura to Geo crystals.

❌ Multiple Anemo (3+ Anemo)
   Anemo can't react with itself. No energy synergy.
   One Anemo support is plenty. Two is sometimes okay.
   Three is always a mistake.

❌ All different elements (no resonance)
   You lose resonance bonuses AND energy funneling.
   Always run at least one element pair.
```
