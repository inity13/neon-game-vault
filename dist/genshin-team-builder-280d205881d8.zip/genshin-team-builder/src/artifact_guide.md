# Artifact Guide — Sets, Stats, and Farming Efficiency

> The right artifacts turn a mediocre character into a monster.

---

## Artifact Basics

```
ARTIFACT SLOTS:
  🌸 Flower     — Always HP (main stat)
  🪶 Feather    — Always ATK (main stat)
  ⏳ Sands      — Variable main stat (ATK%, HP%, DEF%, EM, ER%)
  🏆 Goblet     — Variable main stat (Elemental DMG%, ATK%, HP%, DEF%, EM)
  👑 Circlet    — Variable main stat (Crit Rate, Crit DMG, ATK%, HP%, DEF%, EM, Healing%)

ONLY Sands, Goblet, and Circlet have choices to make.
Flower and Feather are always the same main stat.
```

---

## Main Stat Priority by Role

```
┌───────────────┬──────────┬──────────────────┬────────────┐
│ Role          │ Sands    │ Goblet           │ Circlet    │
├───────────────┼──────────┼──────────────────┼────────────┤
│ Main DPS      │ ATK%     │ Elemental DMG%   │ Crit Rate  │
│ (Reaction)    │ or EM    │                  │ or Crit DMG│
├───────────────┼──────────┼──────────────────┼────────────┤
│ Main DPS      │ ATK%     │ Physical DMG%    │ Crit Rate  │
│ (Physical)    │          │                  │ or Crit DMG│
├───────────────┼──────────┼──────────────────┼────────────┤
│ Sub DPS       │ ATK%     │ Elemental DMG%   │ Crit Rate  │
│               │ or ER%   │                  │ or Crit DMG│
├───────────────┼──────────┼──────────────────┼────────────┤
│ EM Support    │ EM       │ EM               │ EM         │
│ (Swirl/React) │          │                  │            │
├───────────────┼──────────┼──────────────────┼────────────┤
│ Buffer        │ ER%      │ (varies by buff) │ (varies)   │
│               │          │                  │            │
├───────────────┼──────────┼──────────────────┼────────────┤
│ Healer        │ HP%      │ HP%              │ Healing%   │
│ (HP-scaling)  │ or ER%   │                  │ or HP%     │
├───────────────┼──────────┼──────────────────┼────────────┤
│ Shielder      │ HP%      │ HP%              │ HP%        │
│ (HP-scaling)  │ or DEF%  │ or DEF%          │ or DEF%    │
└───────────────┴──────────┴──────────────────┴────────────┘
```

---

## Crit Rate vs. Crit DMG

```
THE GOLDEN RATIO: 1:2 (Crit Rate : Crit DMG)

  Examples:
    50% CR / 100% CD  ← Balanced (good!)
    70% CR / 140% CD  ← Balanced (great!)
    30% CR / 200% CD  ← Unbalanced (crits are huge but rare)
    80% CR / 60% CD   ← Unbalanced (crits are frequent but weak)

  WHY 1:2?
  Expected damage = ATK × (1 + CritRate × CritDMG)
  
  With 50% CR / 100% CD:
    1 + 0.50 × 1.00 = 1.50 (50% average damage increase)
    
  With 30% CR / 200% CD:
    1 + 0.30 × 2.00 = 1.60 (60% average... BUT inconsistent!)
    
  With 80% CR / 60% CD:
    1 + 0.80 × 0.60 = 1.48 (48% average — worse!)

  MINIMUM TARGETS:
    Adequate:   50% CR / 100% CD
    Good:       60% CR / 120% CD
    Great:      70% CR / 140% CD
    Cracked:    75%+ CR / 150%+ CD

  FREEZE TEAMS GET FREE CRIT:
    Blizzard Strayer 4pc: +40% CR on Frozen enemies
    Cryo Resonance: +15% CR on Cryo-affected enemies
    → Stack all Crit DMG, you get 55% free Crit Rate!
```

---

## Substat Priority

```
Substats are random — you can't control them. But you can PRIORITIZE
which artifacts to keep based on substats.

SUBSTAT VALUE TIER LIST:

  S TIER (always good):
    Crit Rate    — Best substat for DPS
    Crit DMG     — Best substat for DPS
    
  A TIER (usually good):
    ATK%         — Good for DPS and burst supports
    ER%          — Essential for supports, good for sub DPS
    EM           — Great for reaction teams
    
  B TIER (situational):
    HP%          — Good for HP-scaling characters
    DEF%         — Good for DEF-scaling characters
    ATK flat     — Small boost, worse than ATK%
    
  C TIER (usually bad):
    HP flat      — Very small boost
    DEF flat     — Very small boost

QUICK FILTER: Keep artifacts with 2+ S/A tier substats.
              Trash artifacts with 0 S/A tier substats.
```

---

## Artifact Set Recommendations

### Universal DPS Sets

```
GLADIATOR'S FINALE (4pc):
  2pc: +18% ATK
  4pc: +35% Normal Attack DMG
  Best for: Normal attack carries (sword, claymore, polearm)
  
SHIMENAWA'S REMINISCENCE (4pc):
  2pc: +18% ATK
  4pc: Use skill → +50% Normal/Charged/Plunge DMG for 10s (costs 15 energy)
  Best for: Characters who don't need their Burst often
  Warning: Energy drain can hurt Burst uptime!

EMBLEM OF SEVERED FATE (4pc):
  2pc: +20% ER
  4pc: Burst DMG% = 25% of ER (max 75%)
  Best for: Burst DPS and sub DPS characters (THE most resin-efficient domain)
  
VIRIDESCENT VENERER (4pc):
  2pc: +15% Anemo DMG
  4pc: Swirl DMG +60%, -40% enemy Elemental RES to swirled element
  Best for: EVERY Anemo support (mandatory!)
  
NOBLESSE OBLIGE (4pc):
  2pc: +20% Burst DMG
  4pc: Using Burst grants +20% ATK to all party for 12s
  Best for: Support characters who use Burst regularly
  
TENACITY OF THE MILLELITH (4pc):
  2pc: +20% HP
  4pc: Skill hits enemy → +20% ATK and +30% Shield STR for 3s
  Best for: Off-field supports with persistent skills
```

### Element-Specific Sets

```
CRIMSON WITCH OF FLAMES (4pc):
  2pc: +15% Pyro DMG
  4pc: +15% Overloaded/Burning, +40% Vaporize/Melt
  Best for: Pyro reaction carries

BLIZZARD STRAYER (4pc):
  2pc: +15% Cryo DMG
  4pc: +20% CR vs Cryo-affected, +40% CR vs Frozen
  Best for: Freeze team Cryo carries

HEART OF DEPTH (4pc):
  2pc: +15% Hydro DMG
  4pc: After Skill → +30% Normal/Charged ATK DMG for 15s
  Best for: Hydro carries with auto-attack focus

THUNDERING FURY (4pc):
  2pc: +15% Electro DMG
  4pc: +40% reaction DMG, Skill CD -1s on reaction
  Best for: Electro reaction carries

DEEPWOOD MEMORIES (4pc):
  2pc: +15% Dendro DMG
  4pc: Skill/Burst hit → -30% Dendro RES for 8s
  Best for: Dendro support (apply shred for Dendro carry)
```

---

## Farming Efficiency

### The Resin Efficiency Ranking

```
MOST EFFICIENT DOMAINS (farm these first):

  1. EMBLEM + SHIMENAWA domain
     WHY: Emblem fits almost every burst-focused character.
     Shimenawa is a good DPS set. Both pieces are useful.
     You'll NEVER waste resin here.

  2. VIRIDESCENT + MAIDEN domain
     WHY: Every Anemo character needs VV. Once you have a good
     4pc VV set, you're done farming here forever.
     (Maiden pieces are bad, but VV is essential)

  3. NOBLESSE + BLOODSTAINED domain
     WHY: Noblesse 4pc is great on many supports.
     Also, you can craft Noblesse pieces from the strongbox.

LEAST EFFICIENT:
  Crimson Witch domain — The other set is bad, and CW takes forever
  to get good pieces. Use strongbox instead!

STRONGBOX TIP:
  Turn bad artifacts into Noblesse, Gladiator, Emblem, etc.
  at the Artifact Strongbox in the crafting table.
  This is often more resin-efficient than farming a specific domain.
```

### When to Stop Farming

```
STOP FARMING WHEN:

  ✅ You have the right main stats on all 5 pieces
  ✅ Your Crit ratio is at least 50/100
  ✅ You have the correct set bonus (2pc or 4pc)
  ✅ Each piece has at least 1 good substat

DON'T try to get "perfect" artifacts. The resin cost grows exponentially:
  
  Adequate artifacts:  ~2 weeks of farming
  Good artifacts:      ~1 month of farming
  Great artifacts:     ~3 months of farming
  Perfect artifacts:   ~1 year of farming (not worth it!)

  The jump from "adequate" to "good" is 5-10% more damage.
  The jump from "good" to "perfect" is another 5-10%.
  
  That resin is better spent building another character.
```

---

## Quick Build Templates

```
TEMPLATE: Generic DPS
  Set: 4pc Best-in-Slot OR 2pc ATK/2pc Elemental DMG
  Sands: ATK% (or EM for reaction teams)
  Goblet: Elemental DMG%
  Circlet: Crit Rate (if ratio under 1:2) or Crit DMG
  Substats: Crit > ATK% > EM > ER

TEMPLATE: Burst Sub DPS
  Set: 4pc Emblem of Severed Fate
  Sands: ATK% or ER% (if Burst isn't ready each rotation)
  Goblet: Elemental DMG%
  Circlet: Crit Rate or Crit DMG
  Substats: ER (to threshold) > Crit > ATK%

TEMPLATE: Anemo Support
  Set: 4pc Viridescent Venerer (NO EXCEPTIONS)
  Sands: EM
  Goblet: EM
  Circlet: EM
  Substats: EM > ER > ATK%
  (Full EM maximizes Swirl damage)

TEMPLATE: Buffer/Support
  Set: 4pc Noblesse Oblige OR 4pc Tenacity
  Sands: ER% (or HP%/DEF% for scaling)
  Goblet: HP% or support-specific
  Circlet: HP% or Healing Bonus
  Substats: ER (to threshold) > HP%/DEF% > flat stats

TEMPLATE: Healer
  Set: 4pc Ocean-Hued Clam OR 4pc Maiden Beloved
  Sands: HP% or ER%
  Goblet: HP%
  Circlet: Healing Bonus
  Substats: ER > HP% > flat HP
```
