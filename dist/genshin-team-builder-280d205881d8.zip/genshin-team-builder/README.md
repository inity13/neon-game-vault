# Genshin Team Builder — Master Team Compositions & Build Optimization

> **Price:** $5 | **Skill Level:** All Levels | **Format:** Markdown Guides + JSON Data

## What Is This?

The Genshin Team Builder is a comprehensive guide to building effective teams, understanding elemental synergies, optimizing artifact sets, and choosing the right weapons for every character archetype. Stop randomly throwing four characters together — learn the science behind team building.

**This guide uses generic archetypes and original analysis.** Character names reference in-game elements and roles rather than specific meta snapshots, so the principles remain useful across patches.

## What's Included

| File | Description |
|------|-------------|
| `src/team_building_fundamentals.md` | Core concepts: roles, energy, rotations, elemental gauge theory |
| `src/elemental_reactions.md` | Complete reaction guide with damage formulas and priority charts |
| `src/team_archetypes.md` | 12 proven team archetypes with role slots and example compositions |
| `src/artifact_guide.md` | Artifact set recommendations, stat priority, substats, and farming efficiency |
| `src/weapon_recommendations.md` | Weapon tier lists by role with F2P and premium options |
| `src/synergy_charts.md` | Element-by-element synergy matrices and resonance bonuses |
| `examples/team_templates.json` | 20 team templates in structured data format |

## Quick Preview

Here's a taste from the team building fundamentals:

### The 4-Role Framework

Every great team fills four roles. Not every character fills exactly one role — some flex across two or even three. But if your team is missing a role, you'll feel it.

```
┌──────────────────────────────────────────────────────────┐
│                    THE 4 ROLES                            │
├────────────┬─────────────────────────────────────────────┤
│ MAIN DPS   │ On-field most of the time. Deals the bulk  │
│ (Carry)    │ of your damage. Selfish — wants field time. │
│            │ Example: Claymore user with charged attacks  │
├────────────┼─────────────────────────────────────────────┤
│ SUB DPS    │ Deals damage while OFF-field. Uses burst    │
│ (Off-field)│ or skill then swaps out. Efficient!         │
│            │ Example: Deployable turret or persistent AoE │
├────────────┼─────────────────────────────────────────────┤
│ SUPPORT    │ Provides buffs, debuffs, crowd control, or  │
│ (Utility)  │ energy particles. The force multiplier.     │
│            │ Example: ATK buffer, resistance shredder     │
├────────────┼─────────────────────────────────────────────┤
│ HEALER/    │ Keeps you alive. Shields prevent stagger,   │
│ SHIELDER   │ heals recover HP. Pick based on content.    │
│            │ Example: Healing burst or damage-absorbing   │
│            │ shield                                       │
└────────────┴─────────────────────────────────────────────┘
```

### Quick Element Reaction Cheatsheet

| Trigger | Applied To | Reaction | Type |
|---------|-----------|----------|------|
| Pyro | Hydro | Vaporize (×1.5) | Amplifying |
| Hydro | Pyro | Vaporize (×2.0) | Amplifying |
| Pyro | Cryo | Melt (×2.0) | Amplifying |
| Cryo | Pyro | Melt (×1.5) | Amplifying |
| Electro | Hydro | Electro-Charged | Transformative |
| Any | Frozen | Shatter | Transformative |

*The full guide covers all reactions, internal cooldowns, elemental gauge units, and how to optimize reaction ownership for maximum damage.*

## Who This Is For

- **New players** (AR 20-45) trying to understand why some teams work and others don't
- **Mid-game players** (AR 45-55) optimizing for Spiral Abyss
- **Theory-crafting enthusiasts** who want to understand the math behind team building
- **F2P players** looking to maximize value from the characters they have

## How to Use This Guide

1. **Start with `team_building_fundamentals.md`** to understand the role framework
2. **Read `elemental_reactions.md`** to understand WHY certain combinations are strong
3. **Browse `team_archetypes.md`** to find a template that matches your characters
4. **Use `artifact_guide.md`** and `weapon_recommendations.md` to gear your team
5. **Reference `synergy_charts.md`** when building around a new character
6. **Load `examples/team_templates.json`** into your own tracker or spreadsheet

## FAQ

**Q: Will this be outdated when new characters release?**
A: The guide teaches PRINCIPLES, not just meta picks. Roles, reactions, and artifact logic don't change. New characters slot into existing archetypes.

**Q: I'm F2P — is this useful for me?**
A: Absolutely. Every section includes F2P weapon options, and the team archetypes section has budget alternatives for every slot.

**Q: Does this cover Spiral Abyss specifically?**
A: The team archetypes and rotation guides are designed with Abyss-level content in mind. The artifact and weapon priorities also target endgame optimization.

## License

MIT License — see LICENSE file.
