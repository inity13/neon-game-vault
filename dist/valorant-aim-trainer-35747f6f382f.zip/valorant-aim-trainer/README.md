# Valorant Aim Trainer — Crosshair Configs + Warmup Routines

> Your aim is a skill, not a talent. Train it systematically and you'll climb ranks faster than anyone.

## What's Inside

- **Aim Fundamentals** — Crosshair placement, flicking vs tracking, micro-adjustments
- **Custom Crosshair Configs** — 15+ crosshair codes organized by playstyle and agent role
- **Warmup Routines** — 5/10/15-minute routines for before ranked games
- **Sensitivity Guide** — Finding and locking in your perfect sensitivity
- **Agent-Specific Aim Tips** — How aim requirements change per agent role
- **Progress Tracking** — Weekly improvement tracker template

## Quick Preview

### Crosshair Placement Priority

The single biggest aim improvement you can make is **crosshair placement** — keeping your crosshair at head level where enemies will appear.

```
  BAD PLACEMENT:              GOOD PLACEMENT:
  
  ┌─────────────┐            ┌─────────────┐
  │             │            │      +      │ ← Head level
  │             │            │             │
  │      +      │ ← Too low │             │
  │             │            │             │
  └─────────────┘            └─────────────┘
  
  Bad: You aim at the ground and have to flick UP to heads
  Good: Crosshair is already at head level, just click
```

### Sample Crosshair Codes

| Style | Code | Best For |
|-------|------|----------|
| Clean Dot | See config file | Precise headshots, snipers |
| Small Cross | See config file | General play, all agents |
| Open Cross | See config file | Tracking spray patterns |
| Circle Dot | See config file | Close-range duelists |

*Full crosshair config files with 15+ presets included.*

## Files Included

| File | Description |
|------|-------------|
| `src/aim_fundamentals.md` | Core aiming concepts and techniques |
| `src/crosshair_guide.md` | How crosshairs work + how to choose yours |
| `src/warmup_routines.md` | 5/10/15-minute pre-game routines |
| `src/agent_aim_tips.md` | Role-specific aim requirements |
| `src/progress_tracker.md` | Weekly tracking template |
| `examples/crosshair_configs.json` | 15+ crosshair codes ready to import |
| `examples/sensitivity_guide.md` | Sensitivity finding methodology |

## How to Use

1. **Import a crosshair** — Pick one from `examples/crosshair_configs.json` and paste the code in-game
2. **Read aim fundamentals** — Understand the theory before drilling
3. **Pick your warmup** — Choose 5/10/15 min based on your time
4. **Do the warmup BEFORE every ranked session** — Consistency is everything
5. **Track your progress weekly** — Use the tracker to see improvement

## License

MIT License — See LICENSE file.
