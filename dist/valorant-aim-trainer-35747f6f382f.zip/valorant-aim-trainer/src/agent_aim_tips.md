# Agent-Specific Aim Tips

---

## Aim Requirements by Role

| Role | Primary Aim Type | Sensitivity | Key Skill |
|------|-----------------|-------------|-----------|
| **Duelist** | Flick + Track | Medium-High | First shot accuracy, fast target switch |
| **Initiator** | Pre-aim + Flick | Medium | Clearing angles, refragging |
| **Controller** | Pre-aim + Spray | Medium-Low | Holding angles, post-plant situations |
| **Sentinel** | Precision + Hold | Low-Medium | Headshot on first peek, patience |

---

## Duelist Aim Guide

**Your job:** Enter sites first, get opening kills, create space.

### Key Aim Skills
1. **Shoulder peek → flash → wide swing → headshot** — The standard duelist entry
2. **180° flick** — Enemies behind you after you entry. Fast turnaround.
3. **Multi-kill spray transfer** — Kill one, immediately transfer to the next

```
  ENTRY SEQUENCE:
  
  1. Shoulder peek     2. Throw flash      3. Wide swing + shoot
  
  ┌────┐              ┌────┐              ┌────┐
  │  @ │→ peek        │  @ │→ flash       │      @ │→ SWING + HEADSHOT
  │    │              │  ✦ │              │    💥  │
  └────┘              └────┘              └────────┘
```

### Drill for Duelists
- **3-target elimination** — 3 bots spread across a site. Kill all 3 in under 3 seconds (headshots).
- **180° flick** — Set a target behind you. Turn and headshot as fast as possible.

---

## Initiator Aim Guide

**Your job:** Gather info, clear angles for duelists, trade kills.

### Key Aim Skills
1. **Trade kills** — Teammate dies → you immediately kill their killer (within 2s)
2. **Post-info shots** — After your utility reveals enemy position, pre-aim and shoot
3. **Angle clearing** — Systematically check each angle with crosshair placement

```
  TRADE KILL SEQUENCE:
  
  1. Teammate dies      2. You see the killer     3. Immediate headshot
  
  ┌────┐               ┌────┐                    ┌────┐
  │  X │ teammate down │  + │→ acquire target    │  +💥│ TRADE
  │    │               │    │                    │     │
  └────┘               └────┘                    └────┘
  
  Time window: < 2 seconds
```

### Drill for Initiators
- **Refrag drill** — Have 2 bots. First bot "kills" (stands still), immediately shoot the second bot.
- **Utility + headshot** — Throw a flash/scan, then headshot the revealed target.

---

## Controller Aim Guide

**Your job:** Control areas with smokes/walls, hold angles, stay alive.

### Key Aim Skills
1. **Holding angles** — Aim at one spot and wait for enemy to walk into your crosshair
2. **Post-plant spray** — Spray through smoke when you hear defuse
3. **Off-angle holds** — Hold from unexpected positions

```
  HOLDING AN ANGLE:
  
  ┌─────────────────────┐
  │                     │
  │  YOUR CROSSHAIR: +  │ ← Pre-aimed at head level
  │                     │    at the most common peek spot
  │          ┌──┐       │
  │          │  │ corner │    Enemy peeks → walks INTO
  │          └──┘       │    your crosshair → click
  └─────────────────────┘
  
  You DON'T move your crosshair.
  They move INTO it.
```

### Drill for Controllers
- **Angle hold** — Set a bot to peek every 3-5 seconds. Pre-aim the angle and headshot when they appear.
- **Smoke spray** — Practice spraying a fixed pattern through obscured vision (2-bullet bursts at head level).

---

## Sentinel Aim Guide

**Your job:** Lock down sites, get info with utility, play slow and precise.

### Key Aim Skills
1. **One-tap headshots** — You often get one chance to shoot before repositioning
2. **Patience** — Don't peek. Let them come to you.
3. **Off-angles** — Play positions enemies don't expect

```
  SENTINEL POSITIONING:
  
  COMMON ANGLE (expected):     OFF-ANGLE (unexpected):
  ┌─────────────────┐          ┌─────────────────┐
  │                 │          │                 │
  │          +      │          │     +           │ ← They pre-aim
  │          ┌──┐   │          │          ┌──┐   │    the common spot
  │          │  │   │          │          │  │   │    but you're NOT there
  └─────────────────┘          └─────────────────┘
  
  Enemy pre-aims common spots.
  If you're NOT there, they have to re-adjust.
  That extra 200ms = your kill.
```

### Drill for Sentinels
- **One-tap only** — Practice range, one bullet per bot. If you miss, move to the next. Zero spraying.
- **Holding 2 angles** — Two bots peek from different angles. Kill one, quickly flick to the other.

---

## Universal Tips (All Roles)

1. **Aim at head level at ALL times** — Even when rotating, running, doing nothing
2. **Pre-aim every corner** — Before you peek, your crosshair should already be at the spot
3. **First bullet accuracy** — In tactical shooters, the first bullet is the most accurate. Make it count.
4. **Don't crouch spray** — Crouching makes you an easy headshot. Only crouch to dodge during a committed fight.
5. **Use utility before peeking** — Flash, scan, smoke, then peek. Raw peeking is gambling.

---

*Your agent choice should influence your aim training. Practice the skills your role demands, not just generic aim drills.*
