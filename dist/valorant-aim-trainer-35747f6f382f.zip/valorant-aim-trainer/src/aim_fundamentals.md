# Aim Fundamentals

> 90% of aim improvement comes from understanding these concepts. The other 10% is raw practice.

---

## The Three Types of Aiming

### 1. Crosshair Placement (Most Important)

Your crosshair should always be at head level, pre-aimed at common angles.

```
  APPROACHING A CORNER:
  
  BAD:                          GOOD:
  ┌────────┬──────┐            ┌────────┬──────┐
  │        │      │            │        │  +   │ ← Pre-aimed at
  │        │      │            │        │      │    head level
  │    +   │      │            │        │      │    where enemy
  │        │      │            │        │      │    will peek
  └────────┴──────┘            └────────┴──────┘
  
  Bad: Looking at the wall, have to react + flick
  Good: Already aimed at where they'll appear
```

**Practice drill:** Walk through maps WITHOUT shooting. Focus ONLY on keeping your crosshair at head level on every corner, doorway, and angle.

### 2. Flick Aiming

Moving your crosshair quickly to a target that appears unexpectedly.

```
  FLICK SEQUENCE:
  
  1. Enemy appears    2. Brain processes    3. Flick to target
  
  +        👤         +    ←→  👤           +👤
  (crosshair) (enemy)  (recognize)          (on target)
  
  Time: 0ms           Time: 100-200ms       Time: 200-350ms
```

**Key insight:** Flick distance matters. The closer your crosshair already is to the target (thanks to crosshair placement), the smaller and faster your flick needs to be.

### 3. Tracking

Keeping your crosshair on a moving target continuously.

```
  TRACKING A STRAFING ENEMY:
  
  Frame 1:    Frame 2:    Frame 3:    Frame 4:
  
  👤+         +👤          👤+         +👤
  ←           →           ←           →
  
  Your crosshair follows their movement smoothly.
  NOT: snap to them, lose them, snap again.
```

---

## Crosshair Placement Rules

### Rule 1: Head Height

Different character models have different head heights, but they're close enough that one height works.

```
  STANDARD HEAD HEIGHT:
  
  ┌─────────────────┐
  │                 │
  │ ─ ─ ─ + ─ ─ ─  │ ← This line. Always.
  │                 │
  │                 │
  │                 │
  └─────────────────┘
  
  About 60-65% up from the bottom of the screen
  when standing at even ground level.
```

### Rule 2: Pre-Aim Common Angles

```
  MAP KNOWLEDGE → CROSSHAIR POSITION
  
  You KNOW enemies peek from certain spots.
  Aim at those spots BEFORE they peek.
  
  ┌─────────────────────────┐
  │     ┌──┐                │
  │     │  │  ← Common peek │
  │     │+ │  ← AIM HERE    │
  │     │  │                │
  │     └──┘                │
  │              YOU →      │
  └─────────────────────────┘
```

### Rule 3: Adjust for Elevation

```
  ENEMY ABOVE YOU:          ENEMY BELOW YOU:
  
       👤                   YOU (looking down)
      / \                     +
     /   \                   / \
    /  +  \                 /   \
   YOU                     👤
  
  Raise crosshair          Lower crosshair
  for uphill fights         for downhill fights
```

---

## Sensitivity Deep Dive

### The cm/360 Standard

cm/360 = centimeters of mouse movement for one full 360° rotation.

| cm/360 | Category | Playstyle |
|--------|----------|-----------|
| 15-25 cm | Very High | Wrist aimer, fast flicks |
| 25-35 cm | High | Balanced wrist/arm |
| 35-50 cm | Medium | Default competitive |
| 50-70 cm | Low | Arm aimer, precision |
| 70+ cm | Very Low | Sniper specialist |

**Recommended for tactical shooters:** 30-50 cm/360

### Finding Your Sensitivity

**The Elimination Method:**
1. Start at 0.35 in-game sensitivity at 800 DPI (eDPI 280)
2. Play 3 deathmatch games
3. **Overshooting?** (crosshair goes past the target) → Lower by 0.03
4. **Undershooting?** (crosshair stops short) → Raise by 0.03
5. Repeat until overshooting and undershooting happen equally
6. **LOCK IT IN.** Do not change for at least 2 weeks.

---

## Peeking Mechanics

### Types of Peeks

| Peek Type | When to Use | Description |
|-----------|-------------|-------------|
| **Jiggle Peek** | Info gathering | Quick ADAD to spot enemies without committing |
| **Wide Peek** | Dueling | Swing wide to create distance from the wall |
| **Shoulder Peek** | Baiting shots | Show your shoulder to bait a sniper shot |
| **Ferrari Peek** | Aggressive | Full sprint peek + shoot (high risk/reward) |

### The Advantage of Moving

```
  HOLDER (standing still):
  - Sees the peeker's model gradually appear
  - Has to react to their position
  - Advantage: already aimed at the angle
  
  PEEKER (moving out):
  - Sees the holder's full model at once
  - Has "peeker's advantage" (~20-60ms network benefit)
  - Disadvantage: moving while shooting = less accurate
  
  In online play, the peeker usually wins close duels
  because of network latency (information travels faster
  to the peeker's screen).
```

### Counter-Strafing

The most important mechanical skill in tactical shooters.

```
  MOVING RIGHT (D key):     COUNTER-STRAFE (tap A):     SHOOT:
  
  ──→ ──→ ──→              ──→ ←── STOP                + FIRE
  (moving, inaccurate)      (velocity = 0, accurate)    (first bullet accurate)
  
  TIMING:
  D D D D D [release D + tap A] [SHOOT] [continue moving]
            ↑                    ↑
            counter-strafe       fire during the
            stops momentum       brief accuracy window
```

**Practice:** In the range, strafe left and right while shooting a target. Your goal: stop perfectly and fire a headshot each time you change direction.

---

## Common Aim Mistakes

| Mistake | What Happens | Fix |
|---------|-------------|-----|
| Aiming at body | Consistent 4-5 shot kills instead of 1-2 | Force yourself to aim at heads. Accept missing more shots at first. |
| Panicking in duels | Spraying wildly when you see an enemy | Breathe. One clean headshot > 10 body spray bullets. |
| Moving while shooting | All bullets miss | Counter-strafe. Stop. Shoot. Move. |
| Holding the same angle | Getting peeked and dying | Change angles after each kill or after being spotted |
| Not warming up | First 3 games are shaky | 5-minute routine before ranked. Non-negotiable. |

---

*Aim is a daily practice, not a one-time lesson. 10 minutes of focused drills every day beats 3 hours of mindless play.*
