# Warmup Routines — Pre-Game Aim Training

> Never jump straight into ranked. These routines prepare your hands, eyes, and brain.

---

## 5-Minute Quick Warmup (Minimum Viable Warmup)

For when you're short on time but still want to be sharp.

| Time | Drill | Focus |
|------|-------|-------|
| 0:00-1:00 | **Crosshair placement walk** — Walk through a map, keep crosshair at head level on every corner | Muscle memory, pre-aim |
| 1:00-2:30 | **Static bots (head only)** — Shoot standing bots, headshots only. Reset if body shot. | Flick accuracy |
| 2:30-4:00 | **Strafing bots** — Shoot moving bots. Counter-strafe before each shot. | Tracking + counter-strafe |
| 4:00-5:00 | **Quick deathmatch** — Jump into DM, focus on headshots only. K/D doesn't matter. | Real-player timing |

### Mindset During Warmup
- **Don't care about kills.** You're training, not competing.
- **Go for headshots only.** Body shots don't count during warmup.
- **Slow is smooth, smooth is fast.** Precision first, speed second.

---

## 10-Minute Standard Warmup (Recommended)

The sweet spot. Covers all aim fundamentals without burning you out.

| Time | Drill | Focus | Details |
|------|-------|-------|---------|
| 0:00-1:30 | **Crosshair walk** | Placement | Walk through 2 maps, clearing every angle at head height |
| 1:30-3:00 | **Static heads (easy)** | Warmup flicks | Large targets, relaxed pace. Just get your hand moving. |
| 3:00-4:30 | **Static heads (hard)** | Precision flicks | Small targets. Take your time. Every shot must be a headshot. |
| 4:30-6:00 | **Tracking drill** | Smooth tracking | Follow a moving target with crosshair. Don't click yet. Just track. |
| 6:00-7:30 | **Tracking + shooting** | Applied tracking | Now track AND shoot. One bullet at a time. |
| 7:30-9:00 | **Speed flicks** | Reaction speed | Multiple targets, switch between them as fast as possible while being accurate |
| 9:00-10:00 | **Deathmatch warm** | Game feel | 1 minute of DM to transition from drill mode to game mode |

### Accuracy Targets by Rank

| Rank Tier | Static Headshot % | Tracking Headshot % | Speed Flick Accuracy |
|-----------|-------------------|--------------------|--------------------|
| Iron-Bronze | 40%+ | 25%+ | 30%+ |
| Silver-Gold | 55%+ | 35%+ | 40%+ |
| Platinum-Diamond | 70%+ | 45%+ | 55%+ |
| Ascendant+ | 80%+ | 55%+ | 65%+ |

---

## 15-Minute Pro Warmup (Full Session)

For serious ranked sessions. This is what high-rank players do.

### Phase 1: Mechanical Warmup (5 min)

| Time | Drill | Notes |
|------|-------|-------|
| 0:00-1:00 | **Hand stretches** | Wrist circles, finger spreads, forearm stretches |
| 1:00-2:00 | **Mouse control** — Move crosshair in a figure-8 pattern smoothly | Smoothness, no jerky movement |
| 2:00-3:30 | **Flick grid** — 6 targets in a grid, flick between them in order | Pattern flicking |
| 3:30-5:00 | **Micro-adjustment drill** — Aim near a target, then micro-adjust to headshot | The last 5% of aim accuracy |

### Phase 2: Applied Drills (5 min)

| Time | Drill | Notes |
|------|-------|-------|
| 5:00-6:00 | **Peek + headshot** — Practice peeking a corner and headshotting a bot | Peek mechanics |
| 6:00-7:30 | **Counter-strafe shots** — Strafe, stop, headshot, strafe, stop, headshot | Movement + aim integration |
| 7:30-8:30 | **Multiple targets** — 3 bots, kill all 3 as fast as possible (headshots) | Target switching |
| 8:30-10:00 | **Reaction shots** — Bots appear randomly, shoot ASAP | Reaction time |

### Phase 3: Game Simulation (5 min)

| Time | Drill | Notes |
|------|-------|-------|
| 10:00-12:30 | **Deathmatch (headshot focus)** | Focus on crosshair placement and pre-aiming |
| 12:30-15:00 | **Deathmatch (play to win)** | Now play normally — apply everything |

---

## Hand Stretches (Do These!)

Gaming injuries are real. Do these before EVERY session:

### Stretch 1: Prayer Stretch
```
  Put palms together in front of chest.
  Slowly lower hands while keeping palms together.
  Hold for 10 seconds. Feel the wrist stretch.
  
  🙏 → 🙏 (lower)
```

### Stretch 2: Wrist Extension
```
  Extend arm straight, palm facing away.
  Use other hand to gently pull fingers back.
  Hold 10 seconds. Switch hands.
  
  ✋ ← (pull fingers back gently)
```

### Stretch 3: Finger Spreads
```
  Spread all fingers as wide as possible.
  Hold 5 seconds.
  Make a tight fist.
  Hold 5 seconds.
  Repeat 5 times.
  
  🖐 → ✊ → 🖐 → ✊ → 🖐
```

### Stretch 4: Wrist Circles
```
  Make slow circles with your wrist.
  10 clockwise, 10 counter-clockwise.
  Each hand.
  
  ↻ ↻ ↻ ... ↺ ↺ ↺ ...
```

---

## Weekly Practice Schedule

| Day | Warmup | Focus Area |
|-----|--------|------------|
| Monday | 10 min | Flick accuracy (static targets) |
| Tuesday | 10 min | Tracking (moving targets) |
| Wednesday | 5 min | Light warmup (rest day for intense aim) |
| Thursday | 15 min | Full routine + deathmatch |
| Friday | 10 min | Speed flicking + reaction time |
| Saturday | 15 min | Full routine (ranked day) |
| Sunday | 5 min or rest | Recovery |

---

## Progress Tracking Template

Copy this for each week:

```
Week of: ___/___/______

            Mon   Tue   Wed   Thu   Fri   Sat   Sun
Warmup:     [ ]   [ ]   [ ]   [ ]   [ ]   [ ]   [ ]
Duration:   ___   ___   ___   ___   ___   ___   ___

Static HS%: ___   ___   ___   ___   ___   ___   ___
Track HS%:  ___   ___   ___   ___   ___   ___   ___
Flick Acc:  ___   ___   ___   ___   ___   ___   ___

Games played: ___
Current rank: ___
Notes: ________________________________________________
```

---

*The most important warmup is the one you actually do. A 5-minute warmup you do every day beats a 30-minute warmup you do once a week.*
