# Weekly Progress Tracker

Print this or copy it into a document. Fill in after each session.

---

## Week of: _____ / _____ / _________

### Daily Log

#### Monday
- Warmup done: [ ] Yes  [ ] No  | Duration: ____ min
- Static headshot %: _____%
- Tracking headshot %: _____%
- Games played: ____  | Wins: ____
- Current rank: _______________
- What went well: _______________________________________________
- What to improve: ______________________________________________

#### Tuesday
- Warmup done: [ ] Yes  [ ] No  | Duration: ____ min
- Static headshot %: _____%
- Tracking headshot %: _____%
- Games played: ____  | Wins: ____
- Current rank: _______________
- What went well: _______________________________________________
- What to improve: ______________________________________________

#### Wednesday
- Warmup done: [ ] Yes  [ ] No  | Duration: ____ min
- Static headshot %: _____%
- Tracking headshot %: _____%
- Games played: ____  | Wins: ____
- Current rank: _______________
- What went well: _______________________________________________
- What to improve: ______________________________________________

#### Thursday
- Warmup done: [ ] Yes  [ ] No  | Duration: ____ min
- Static headshot %: _____%
- Tracking headshot %: _____%
- Games played: ____  | Wins: ____
- Current rank: _______________
- What went well: _______________________________________________
- What to improve: ______________________________________________

#### Friday
- Warmup done: [ ] Yes  [ ] No  | Duration: ____ min
- Static headshot %: _____%
- Tracking headshot %: _____%
- Games played: ____  | Wins: ____
- Current rank: _______________
- What went well: _______________________________________________
- What to improve: ______________________________________________

#### Saturday
- Warmup done: [ ] Yes  [ ] No  | Duration: ____ min
- Static headshot %: _____%
- Tracking headshot %: _____%
- Games played: ____  | Wins: ____
- Current rank: _______________
- What went well: _______________________________________________
- What to improve: ______________________________________________

#### Sunday
- Warmup done: [ ] Yes  [ ] No  | Duration: ____ min
- Rest day: [ ] Yes
- Notes: ______________________________________________________

---

### Weekly Summary

| Metric | This Week | Last Week | Change |
|--------|-----------|-----------|--------|
| Avg Static HS% | _____ | _____ | _____ |
| Avg Tracking HS% | _____ | _____ | _____ |
| Total games | _____ | _____ | _____ |
| Win rate | _____ | _____ | _____ |
| Rank | _____ | _____ | _____ |
| Warmup days | ___/7 | ___/7 | _____ |

### Focus for Next Week
1. _____________________________________________
2. _____________________________________________
3. _____________________________________________

---

*Consistent tracking is the difference between "I feel like I'm improving" and "I KNOW I'm improving." Data doesn't lie.*
