# Crosshair Guide — Choosing Your Reticle

---

## How Crosshairs Work

Your crosshair has several configurable parts:

```
  ANATOMY OF A CROSSHAIR:
  
       │  ← Outer line (top)
       │
  ─ ─  +  ─ ─  ← Inner lines (left/right) with gap
       │          + = Center dot (optional)
       │
       │  ← Outer line (bottom)
```

### Key Settings

| Setting | What It Does | Impact |
|---------|-------------|--------|
| **Center Dot** | Small dot at exact center | Precision aiming, but can obscure target |
| **Inner Lines** | Short lines near center | Main aiming reference |
| **Inner Line Offset** | Gap between lines and center | Bigger gap = see target better |
| **Outer Lines** | Longer lines further out | Help track during spray |
| **Line Thickness** | How thick the lines are | Thicker = more visible, less precise |
| **Movement/Firing Error** | Lines expand when moving/shooting | Shows accuracy in real-time |
| **Outlines** | Dark border around crosshair elements | Visibility on bright backgrounds |

---

## Crosshair Philosophy by Playstyle

### The Minimalist (Dot or Tiny Cross)
```
  Screen:
  ┌──────────────────┐
  │                  │
  │        ·         │ ← Almost invisible
  │                  │
  └──────────────────┘
  
  PRO: Nothing blocks your view of the enemy
  CON: Easy to lose your crosshair in chaotic fights
  BEST FOR: Experienced players with great crosshair placement
```

### The Standard (Small Cross)
```
  Screen:
  ┌──────────────────┐
  │        |         │
  │      ─ + ─       │ ← Classic, balanced
  │        |         │
  └──────────────────┘
  
  PRO: Clear reference point, easy to track
  CON: Can block the target's head at long range
  BEST FOR: Most players. Start here.
```

### The Dynamic (Expanding Cross)
```
  Standing still:    Moving:          Spraying:
  ┌────────────┐    ┌────────────┐   ┌────────────┐
  │    │       │    │    |       │   │     |      │
  │  ─ + ─    │    │  ─   ─     │   │  ─     ─   │
  │    │       │    │    |       │   │     |      │
  └────────────┘    └────────────┘   └────────────┘
   (tight)           (expanded)       (very expanded)
  
  PRO: Visual feedback on accuracy
  CON: Distracting for some players
  BEST FOR: Learning mechanics, understanding accuracy
```

---

## Choosing Your Crosshair: Decision Tree

```
  Are you new to FPS games?
  ├── YES → Start with "High Visibility" preset
  │         (Large, bright, easy to see)
  │         → After 2 weeks, try "Small Cross"
  │
  └── NO → Do you mainly play close-range (duelists)?
           ├── YES → "Circle Dot" or "Gap Cross"
           │         (Good for tracking movement)
           │
           └── NO → Do you mainly snipe/long-range?
                    ├── YES → "Clean Dot" or "Thin Cross"
                    │         (Precision, no obstruction)
                    │
                    └── NO (balanced) → "Small Cross" or "T-Shape"
                                        (Best all-around options)
```

---

## The Golden Rule

**Pick a crosshair and stick with it for at least 2 weeks.**

Constantly changing your crosshair disrupts your subconscious aim. Your brain learns to aim at a specific reference point. If that point keeps changing shape, size, or color, your aim suffers.

```
  WEEK 1: New crosshair feels weird    → NORMAL
  WEEK 2: Getting used to it           → KEEP GOING  
  WEEK 3: Feels natural                → SUCCESS
  
  DO NOT switch during Week 1-2 just because "it doesn't feel right."
  That's your brain adapting. Let it adapt.
```

---

*The best crosshair is the one you forget about. When you stop thinking about your crosshair and just aim naturally, you've found the right one.*
