# Game Progression Tracker — Universal Progress Tracking System

> **Price:** $3 | **Skill Level:** All Levels | **Format:** Python CLI Tool + JSON Templates

## What Is This?

The Game Progression Tracker is a universal system for tracking your progress across any game. Quests, achievements, battle passes, gear, skill trees — all managed through a simple Python CLI tool and customizable JSON templates.

**Stop losing track of where you are.** Whether you're grinding battle pass tiers, hunting achievements across multiple games, or tracking your RPG character builds, this tool keeps everything in one place. No spreadsheets, no apps with ads, no accounts. Just your data, your machine, plain JSON.

## What's Included

| File | Description |
|------|-------------|
| `src/tracker_template.py` | Python CLI tool for creating, managing, and viewing progression trackers |
| `src/templates/rpg_tracker.json` | RPG progression template (level, quests, skills, equipment slots) |
| `src/templates/battle_pass_tracker.json` | Battle pass tracker (tier, XP, rewards, daily/weekly challenges) |
| `src/templates/achievement_tracker.json` | Achievement hunting template (games, achievements, completion %) |
| `examples/sample_progression.json` | Example filled-out tracker showing the system in action |

## Quick Preview

### The CLI Tool

```bash
# Create a new tracker from a template
python3 src/tracker_template.py create --template rpg --name "My Elden Ring Run"

# Add a goal
python3 src/tracker_template.py add-goal --tracker my_elden_ring_run.json \
  --goal "Beat Malenia" --category bosses

# Mark a goal complete
python3 src/tracker_template.py complete --tracker my_elden_ring_run.json \
  --goal "Beat Malenia"

# View progress
python3 src/tracker_template.py view --tracker my_elden_ring_run.json

# Export summary
python3 src/tracker_template.py export --tracker my_elden_ring_run.json
```

### Sample Output

```
  ═══════════════════════════════════════════════════
    PROGRESSION: My Elden Ring Run
  ═══════════════════════════════════════════════════

  Overall Progress: ████████████░░░░░░░░  62% (31/50 goals)

  BOSSES (8/12 complete — 67%)
  ────────────────────────────────
    [x] Margit, the Fell Omen
    [x] Godrick the Grafted
    [x] Red Wolf of Radagon
    [x] Rennala, Queen of the Full Moon
    [x] Starscourge Radahn
    [x] Morgott, the Omen King
    [x] Fire Giant
    [x] Godskin Duo
    [ ] Maliketh, the Black Blade
    [ ] Malenia, Blade of Miquella
    [ ] Hoarah Loux, Warrior
    [ ] Radagon / Elden Beast

  QUESTS (15/22 complete — 68%)
  ────────────────────────────────
    [x] Ranni's Questline
    [x] Blaidd's Questline
    [ ] Millicent's Questline
    ...
```

## Who This Is For

- **Completionists** who need to track every achievement and collectible
- **Multi-game players** who lose track of where they are in each game
- **Battle pass grinders** who want to plan their XP earning efficiently
- **RPG players** managing builds, quests, and gear across long playthroughs

## How to Use This Guide

1. **Run `src/tracker_template.py`** with the `create` command to start a new tracker
2. **Pick a template** — RPG, battle pass, or achievement (or start blank)
3. **Add goals** as you play, mark them complete when done
4. **View progress** anytime to see where you stand
5. **Export** your tracker to share or back up

## FAQ

**Q: Can I customize the templates?**
A: Absolutely. The JSON templates are fully editable. Add categories, change field names, add custom metadata. The tool reads whatever structure you give it.

**Q: Does this need internet?**
A: No. Everything runs locally. Your data stays on your machine as JSON files.

**Q: Can I track multiple games at once?**
A: Yes. Create a separate tracker file for each game, or use the achievement template to track across multiple games in one file.

## License

MIT License — see LICENSE file.
