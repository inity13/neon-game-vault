#!/usr/bin/env python3
"""
Game Progression Tracker — Universal Progress Tracking CLI Tool

Create, manage, and view game progression trackers using JSON-based
templates. Track achievements, quests, battle passes, gear, and more.

Usage:
    python3 tracker_template.py create --template rpg --name "My Playthrough"
    python3 tracker_template.py add-goal --tracker FILE --goal "Beat Boss X" --category bosses
    python3 tracker_template.py complete --tracker FILE --goal "Beat Boss X"
    python3 tracker_template.py view --tracker FILE
    python3 tracker_template.py export --tracker FILE

No external dependencies — stdlib only.

Author: Game Vault
License: MIT
"""

import argparse
import json
import os
import sys
from datetime import datetime
from typing import Optional


# =============================================================================
# CONSTANTS
# =============================================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(SCRIPT_DIR, "templates")

TEMPLATE_FILES = {
    "rpg": "rpg_tracker.json",
    "battle_pass": "battle_pass_tracker.json",
    "achievement": "achievement_tracker.json",
}

BAR_WIDTH = 20  # progress bar character width


# =============================================================================
# TRACKER DATA OPERATIONS
# =============================================================================

def load_tracker(filepath: str) -> dict:
    """Load a tracker JSON file.

    Args:
        filepath: Path to the tracker JSON file.

    Returns:
        Parsed tracker dictionary.

    Raises:
        FileNotFoundError: If the file doesn't exist.
        json.JSONDecodeError: If the file isn't valid JSON.
    """
    with open(filepath, "r") as f:
        return json.load(f)


def save_tracker(filepath: str, data: dict) -> None:
    """Save tracker data to a JSON file.

    Args:
        filepath: Destination path.
        data: Tracker dictionary to save.
    """
    with open(filepath, "w") as f:
        json.dump(data, f, indent=2)


def load_template(template_name: str) -> dict:
    """Load a template from the templates directory.

    Args:
        template_name: Template key (rpg, battle_pass, achievement).

    Returns:
        Parsed template dictionary.

    Raises:
        ValueError: If template name is not recognized.
    """
    if template_name not in TEMPLATE_FILES:
        raise ValueError(
            f"Unknown template: {template_name}. "
            f"Options: {list(TEMPLATE_FILES.keys())}"
        )

    path = os.path.join(TEMPLATE_DIR, TEMPLATE_FILES[template_name])
    if not os.path.exists(path):
        raise FileNotFoundError(f"Template file not found: {path}")

    with open(path, "r") as f:
        return json.load(f)


def make_filename(name: str) -> str:
    """Convert a tracker name to a safe filename.

    Args:
        name: Human-readable tracker name.

    Returns:
        Sanitized filename with .json extension.
    """
    safe = name.lower().replace(" ", "_").replace("-", "_")
    safe = "".join(c for c in safe if c.isalnum() or c == "_")
    return f"{safe}.json"


# =============================================================================
# CORE TRACKER LOGIC
# =============================================================================

def create_tracker(template_name: str, name: str, output_dir: str = ".") -> str:
    """Create a new tracker from a template.

    Args:
        template_name: Template to use (rpg, battle_pass, achievement).
        name: Display name for the tracker.
        output_dir: Directory to save the tracker file.

    Returns:
        Path to the created tracker file.
    """
    template = load_template(template_name)

    tracker = {
        "meta": {
            "name": name,
            "template": template_name,
            "created": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
        },
        "categories": template.get("categories", {}),
    }

    filename = make_filename(name)
    filepath = os.path.join(output_dir, filename)
    save_tracker(filepath, tracker)
    return filepath


def create_blank_tracker(name: str, output_dir: str = ".") -> str:
    """Create a blank tracker with no predefined categories.

    Args:
        name: Display name.
        output_dir: Output directory.

    Returns:
        Path to the created file.
    """
    tracker = {
        "meta": {
            "name": name,
            "template": "blank",
            "created": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
        },
        "categories": {},
    }

    filename = make_filename(name)
    filepath = os.path.join(output_dir, filename)
    save_tracker(filepath, tracker)
    return filepath


def add_goal(filepath: str, goal: str, category: str, notes: str = "") -> None:
    """Add a goal to a tracker.

    Args:
        filepath: Path to tracker file.
        goal: Goal description.
        category: Category to add the goal to (created if missing).
        notes: Optional notes.
    """
    data = load_tracker(filepath)

    if category not in data["categories"]:
        data["categories"][category] = {"goals": []}

    goals = data["categories"][category]["goals"]

    # Check for duplicates
    for g in goals:
        if g["name"].lower() == goal.lower():
            print(f"  Goal already exists: {goal}")
            return

    goals.append({
        "name": goal,
        "completed": False,
        "added": datetime.now().isoformat(),
        "completed_at": None,
        "notes": notes,
    })

    data["meta"]["last_updated"] = datetime.now().isoformat()
    save_tracker(filepath, data)


def complete_goal(filepath: str, goal: str) -> bool:
    """Mark a goal as complete.

    Args:
        filepath: Path to tracker file.
        goal: Goal description to match (case-insensitive).

    Returns:
        True if the goal was found and marked complete.
    """
    data = load_tracker(filepath)

    for cat_name, cat_data in data["categories"].items():
        for g in cat_data["goals"]:
            if g["name"].lower() == goal.lower():
                if g["completed"]:
                    print(f"  Already completed: {goal}")
                    return True
                g["completed"] = True
                g["completed_at"] = datetime.now().isoformat()
                data["meta"]["last_updated"] = datetime.now().isoformat()
                save_tracker(filepath, data)
                return True

    return False


def uncomplete_goal(filepath: str, goal: str) -> bool:
    """Mark a goal as incomplete.

    Args:
        filepath: Path to tracker file.
        goal: Goal description to match.

    Returns:
        True if found and unmarked.
    """
    data = load_tracker(filepath)

    for cat_data in data["categories"].values():
        for g in cat_data["goals"]:
            if g["name"].lower() == goal.lower():
                g["completed"] = False
                g["completed_at"] = None
                data["meta"]["last_updated"] = datetime.now().isoformat()
                save_tracker(filepath, data)
                return True

    return False


def remove_goal(filepath: str, goal: str) -> bool:
    """Remove a goal from the tracker.

    Args:
        filepath: Path to tracker file.
        goal: Goal description to match.

    Returns:
        True if found and removed.
    """
    data = load_tracker(filepath)

    for cat_data in data["categories"].values():
        for i, g in enumerate(cat_data["goals"]):
            if g["name"].lower() == goal.lower():
                cat_data["goals"].pop(i)
                data["meta"]["last_updated"] = datetime.now().isoformat()
                save_tracker(filepath, data)
                return True

    return False


# =============================================================================
# DISPLAY / VIEW
# =============================================================================

def progress_bar(done: int, total: int, width: int = BAR_WIDTH) -> str:
    """Generate a text progress bar.

    Args:
        done: Number of completed items.
        total: Total items.
        width: Bar width in characters.

    Returns:
        Formatted progress bar string.
    """
    if total == 0:
        return "[" + " " * width + "] 0%"

    pct = done / total
    filled = int(width * pct)
    bar = "#" * filled + "." * (width - filled)
    return f"[{bar}] {int(pct * 100)}%"


def view_tracker(filepath: str, show_completed: bool = True) -> None:
    """Display tracker progress in a formatted view.

    Args:
        filepath: Path to tracker file.
        show_completed: Whether to show completed goals.
    """
    data = load_tracker(filepath)
    meta = data["meta"]

    total_goals = 0
    total_done = 0

    # Count totals first
    for cat_data in data["categories"].values():
        goals = cat_data.get("goals", [])
        total_goals += len(goals)
        total_done += sum(1 for g in goals if g.get("completed", False))

    # Header
    print(f"\n{'=' * 55}")
    print(f"  PROGRESSION: {meta['name']}")
    print(f"{'=' * 55}")
    print()
    print(f"  Overall: {progress_bar(total_done, total_goals)} ({total_done}/{total_goals})")
    print(f"  Template: {meta.get('template', 'unknown')}")
    print(f"  Last updated: {meta.get('last_updated', 'unknown')[:10]}")
    print()

    # Categories
    for cat_name, cat_data in data["categories"].items():
        goals = cat_data.get("goals", [])
        cat_done = sum(1 for g in goals if g.get("completed", False))
        cat_total = len(goals)

        display_name = cat_name.upper().replace("_", " ")
        print(f"  {display_name} ({cat_done}/{cat_total})")
        print(f"  {'─' * 40}")

        for g in goals:
            done = g.get("completed", False)
            if not show_completed and done:
                continue
            marker = "[x]" if done else "[ ]"
            line = f"    {marker} {g['name']}"
            if g.get("notes"):
                line += f"  ({g['notes']})"
            print(line)

        print()


def export_tracker(filepath: str) -> str:
    """Export tracker as a human-readable text summary.

    Args:
        filepath: Path to tracker file.

    Returns:
        Path to the exported text file.
    """
    data = load_tracker(filepath)
    meta = data["meta"]

    lines = []
    lines.append(f"PROGRESSION REPORT: {meta['name']}")
    lines.append(f"Generated: {datetime.now().isoformat()[:10]}")
    lines.append(f"Template: {meta.get('template', 'unknown')}")
    lines.append("")

    total_goals = 0
    total_done = 0

    for cat_name, cat_data in data["categories"].items():
        goals = cat_data.get("goals", [])
        cat_done = sum(1 for g in goals if g.get("completed", False))
        total_goals += len(goals)
        total_done += cat_done

        lines.append(f"{cat_name.upper()} ({cat_done}/{len(goals)})")
        for g in goals:
            marker = "[x]" if g.get("completed", False) else "[ ]"
            lines.append(f"  {marker} {g['name']}")
        lines.append("")

    pct = int(total_done / total_goals * 100) if total_goals > 0 else 0
    lines.insert(3, f"Overall: {total_done}/{total_goals} ({pct}%)")
    lines.insert(4, "")

    out_path = filepath.replace(".json", "_export.txt")
    with open(out_path, "w") as f:
        f.write("\n".join(lines))

    return out_path


# =============================================================================
# INTERACTIVE MODE
# =============================================================================

def print_header(text: str) -> None:
    """Print a formatted header."""
    print(f"\n{'=' * 55}")
    print(f"  {text}")
    print(f"{'=' * 55}\n")


def interactive_mode() -> None:
    """Run the tracker in interactive mode."""
    print_header("GAME PROGRESSION TRACKER")
    print("  Track achievements, quests, battle passes, and more.\n")

    while True:
        print("  What do you want to do?")
        options = [
            "Create a new tracker",
            "Open an existing tracker",
            "Quit",
        ]
        for i, opt in enumerate(options, 1):
            print(f"    {i}. {opt}")

        try:
            choice = int(input("\n  Choice: "))
        except (ValueError, EOFError):
            continue

        if choice == 1:
            interactive_create()
        elif choice == 2:
            interactive_open()
        elif choice == 3:
            print("\n  GG. Keep grinding.\n")
            break


def interactive_create() -> None:
    """Interactively create a new tracker."""
    print("\n  Available templates:")
    templates = list(TEMPLATE_FILES.keys()) + ["blank"]
    for i, t in enumerate(templates, 1):
        print(f"    {i}. {t}")

    try:
        idx = int(input("\n  Template choice: "))
        if idx < 1 or idx > len(templates):
            print("  Invalid choice.")
            return
    except (ValueError, EOFError):
        return

    template = templates[idx - 1]
    name = input("  Tracker name: ").strip()
    if not name:
        print("  Name cannot be empty.")
        return

    if template == "blank":
        path = create_blank_tracker(name)
    else:
        path = create_tracker(template, name)

    print(f"\n  Created: {path}")
    print(f"  Template: {template}")
    print(f"  Start adding goals and tracking your progress!")


def interactive_open() -> None:
    """Open and manage an existing tracker."""
    path = input("\n  Tracker file path: ").strip()
    if not os.path.exists(path):
        print(f"  File not found: {path}")
        return

    while True:
        view_tracker(path)
        print("  Actions:")
        actions = [
            "Add a goal",
            "Complete a goal",
            "Uncomplete a goal",
            "Remove a goal",
            "Export to text",
            "Back to main menu",
        ]
        for i, a in enumerate(actions, 1):
            print(f"    {i}. {a}")

        try:
            choice = int(input("\n  Action: "))
        except (ValueError, EOFError):
            continue

        if choice == 1:
            category = input("  Category: ").strip().lower().replace(" ", "_")
            goal = input("  Goal: ").strip()
            notes = input("  Notes (optional): ").strip()
            add_goal(path, goal, category, notes)
            print(f"  Added: {goal} -> {category}")

        elif choice == 2:
            goal = input("  Goal to complete: ").strip()
            if complete_goal(path, goal):
                print(f"  Completed: {goal}")
            else:
                print(f"  Goal not found: {goal}")

        elif choice == 3:
            goal = input("  Goal to uncomplete: ").strip()
            if uncomplete_goal(path, goal):
                print(f"  Unmarked: {goal}")
            else:
                print(f"  Goal not found: {goal}")

        elif choice == 4:
            goal = input("  Goal to remove: ").strip()
            if remove_goal(path, goal):
                print(f"  Removed: {goal}")
            else:
                print(f"  Goal not found: {goal}")

        elif choice == 5:
            out = export_tracker(path)
            print(f"  Exported to: {out}")

        elif choice == 6:
            break


# =============================================================================
# CLI ARGUMENT PARSING
# =============================================================================

def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""
    parser = argparse.ArgumentParser(
        description="Game Progression Tracker — track achievements, quests, and more.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    sub = parser.add_subparsers(dest="command", help="Command to run")

    # create
    create_p = sub.add_parser("create", help="Create a new tracker from a template")
    create_p.add_argument("--template", "-t", required=True,
                          choices=list(TEMPLATE_FILES.keys()) + ["blank"],
                          help="Template to use")
    create_p.add_argument("--name", "-n", required=True, help="Tracker name")
    create_p.add_argument("--output", "-o", default=".", help="Output directory")

    # add-goal
    add_p = sub.add_parser("add-goal", help="Add a goal to a tracker")
    add_p.add_argument("--tracker", "-f", required=True, help="Tracker file path")
    add_p.add_argument("--goal", "-g", required=True, help="Goal description")
    add_p.add_argument("--category", "-c", required=True, help="Category name")
    add_p.add_argument("--notes", default="", help="Optional notes")

    # complete
    comp_p = sub.add_parser("complete", help="Mark a goal as complete")
    comp_p.add_argument("--tracker", "-f", required=True, help="Tracker file path")
    comp_p.add_argument("--goal", "-g", required=True, help="Goal to complete")

    # uncomplete
    uncomp_p = sub.add_parser("uncomplete", help="Mark a goal as incomplete")
    uncomp_p.add_argument("--tracker", "-f", required=True, help="Tracker file path")
    uncomp_p.add_argument("--goal", "-g", required=True, help="Goal to uncomplete")

    # remove
    rm_p = sub.add_parser("remove", help="Remove a goal")
    rm_p.add_argument("--tracker", "-f", required=True, help="Tracker file path")
    rm_p.add_argument("--goal", "-g", required=True, help="Goal to remove")

    # view
    view_p = sub.add_parser("view", help="View tracker progress")
    view_p.add_argument("--tracker", "-f", required=True, help="Tracker file path")
    view_p.add_argument("--hide-completed", action="store_true",
                        help="Hide completed goals")

    # export
    export_p = sub.add_parser("export", help="Export tracker to text")
    export_p.add_argument("--tracker", "-f", required=True, help="Tracker file path")

    return parser


def main() -> None:
    """Main entry point."""
    parser = build_parser()
    args = parser.parse_args()

    if args.command is None:
        # No subcommand — run interactive mode
        interactive_mode()
        return

    if args.command == "create":
        if args.template == "blank":
            path = create_blank_tracker(args.name, args.output)
        else:
            path = create_tracker(args.template, args.name, args.output)
        print(f"  Created tracker: {path}")

    elif args.command == "add-goal":
        add_goal(args.tracker, args.goal, args.category, args.notes)
        print(f"  Added goal: {args.goal} -> {args.category}")

    elif args.command == "complete":
        if complete_goal(args.tracker, args.goal):
            print(f"  Completed: {args.goal}")
        else:
            print(f"  Goal not found: {args.goal}")
            sys.exit(1)

    elif args.command == "uncomplete":
        if uncomplete_goal(args.tracker, args.goal):
            print(f"  Uncompleted: {args.goal}")
        else:
            print(f"  Goal not found: {args.goal}")
            sys.exit(1)

    elif args.command == "remove":
        if remove_goal(args.tracker, args.goal):
            print(f"  Removed: {args.goal}")
        else:
            print(f"  Goal not found: {args.goal}")
            sys.exit(1)

    elif args.command == "view":
        view_tracker(args.tracker, show_completed=not args.hide_completed)

    elif args.command == "export":
        out = export_tracker(args.tracker)
        print(f"  Exported to: {out}")


if __name__ == "__main__":
    main()
