# Roblox Scripting Patterns — From Basics to Production Code

> The patterns and anti-patterns that separate hobby projects from successful games.

---

## Table of Contents

1. [Lua Refresher for Roblox](#lua-refresher)
2. [Roblox Services — Your Toolbox](#roblox-services)
3. [Client-Server Architecture](#client-server-architecture)
4. [RemoteEvents and RemoteFunctions](#remoteevents-and-remotefunctions)
5. [Data Persistence with DataStoreService](#data-persistence)
6. [Essential Scripting Patterns](#essential-patterns)
7. [Module Scripts and Code Organization](#module-scripts)
8. [Anti-Patterns to Avoid](#anti-patterns)

---

## Lua Refresher

If you know ANY programming language, Lua will feel familiar. Here's the Roblox-flavored basics:

### Variables and Types

```lua
-- Roblox uses Luau (Lua + type annotations + performance improvements)
-- Variables are local by default in good code — ALWAYS use 'local'

local playerName: string = "ExampleUser"   -- String
local playerHealth: number = 100           -- Number (no int/float distinction)
local isAlive: boolean = true              -- Boolean
local inventory: {string} = {"Sword", "Shield", "Potion"}  -- Table (array)
local stats: {[string]: number} = {        -- Table (dictionary)
    Level = 1,
    XP = 0,
    Coins = 100,
}

-- WHY local? Two reasons:
-- 1. Performance: Local variables are stored in registers, globals require table lookups
-- 2. Safety: Global variables leak between scripts, causing impossible-to-debug conflicts
```

### Functions

```lua
-- Named function with type annotations (Luau feature)
local function calculateDamage(baseDamage: number, multiplier: number): number
    -- WHY separate the calculation? So you can change the formula in ONE place
    -- instead of hunting through 50 scripts when you rebalance
    return math.floor(baseDamage * multiplier)
end

-- Functions as values (useful for callbacks and event handlers)
local onPlayerJoined = function(player: Player)
    print(player.Name .. " joined the game!")
end
```

### Control Flow

```lua
-- If/elseif/else — note: NO curly braces, NO parentheses required
local health = 50

if health <= 0 then
    -- Player is dead
    respawnPlayer()
elseif health < 25 then
    -- Low health warning
    showWarningUI()
else
    -- Player is fine
end

-- For loops — numeric
for i = 1, 10 do          -- 1 to 10, inclusive
    print(i)
end

for i = 10, 1, -1 do      -- 10 to 1, counting down
    print(i)
end

-- For loops — generic (iterating tables)
for index, item in ipairs(inventory) do     -- Array-style (ordered)
    print(index, item)
end

for key, value in pairs(stats) do           -- Dictionary-style (unordered)
    print(key, value)
end

-- While loops
while isAlive do
    task.wait(1)  -- Wait 1 second (NOT wait() — that's deprecated!)
    updateHealthRegen()
end
```

---

## Roblox Services — Your Toolbox

Roblox gives you pre-built "services" for everything. Think of them as departments in a company — each one handles a specific job.

```
┌─────────────────────────────────────────────────────────┐
│                    ROBLOX SERVICES                       │
├─────────────────────┬───────────────────────────────────┤
│  Players            │  Player join/leave, characters    │
│  Workspace          │  The 3D world, parts, models      │
│  ReplicatedStorage  │  Shared data (client + server)    │
│  ServerStorage      │  Server-only data (secure)        │
│  ServerScriptService│  Server scripts run here          │
│  StarterGui         │  UI templates for players         │
│  StarterPack        │  Tools given to players           │
│  DataStoreService   │  Persistent data (saves between   │
│                     │  sessions)                        │
│  TweenService       │  Smooth animations                │
│  RunService         │  Frame-by-frame updates           │
│  UserInputService   │  Keyboard/mouse/touch input       │
│  MarketplaceService │  Purchases (Game Passes, etc.)    │
└─────────────────────┴───────────────────────────────────┘
```

### How to Access Services

```lua
-- ALWAYS use GetService() — never index game directly
-- WHY? GetService() is guaranteed to work even if the service hasn't loaded yet

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local DataStoreService = game:GetService("DataStoreService")
local TweenService = game:GetService("TweenService")
local RunService = game:GetService("RunService")

-- Get services at the TOP of your script, not inside functions
-- WHY? It's a one-time operation. Calling it inside a loop wastes cycles.
```

### Where Things Live

```
game
├── Workspace/              ← The 3D world. Parts, models, terrain
│   ├── Map/
│   ├── SpawnLocation
│   └── [Player Characters appear here]
│
├── Players/                ← Connected players
│   └── ExampleUser/
│       ├── Backpack/       ← Player's current tools
│       └── leaderstats/    ← Leaderboard values
│
├── ReplicatedStorage/      ← BOTH client and server can see this
│   ├── RemoteEvents/       ← Client-server communication
│   ├── Modules/            ← Shared module scripts
│   └── Assets/             ← Models, sounds, effects
│
├── ServerStorage/          ← ONLY the server can see this
│   ├── PlayerData/         ← Templates for player data
│   └── SecretStuff/        ← Things clients shouldn't access
│
├── ServerScriptService/    ← Server scripts run from here
│   ├── GameManager.lua
│   └── DataManager.lua
│
└── StarterGui/             ← UI templates (copied to each player)
    ├── ShopGui/
    └── HudGui/
```

**Key insight:** The `Server` in ServerStorage and ServerScriptService means the CLIENT CANNOT SEE IT. This is your secure zone. Put anything sensitive (data templates, admin scripts, game logic) here.

---

## Client-Server Architecture

This is THE most important concept in Roblox development. Get this wrong and hackers will destroy your game.

```
┌──────────────────────┐          ┌──────────────────────┐
│      CLIENT          │          │       SERVER          │
│  (Player's computer) │          │  (Roblox's computer)  │
│                      │          │                       │
│  • Renders graphics  │          │  • Runs game logic    │
│  • Handles input     │◄────────►│  • Validates actions  │
│  • Shows UI          │ Network  │  • Stores data        │
│  • Plays sounds      │          │  • Controls NPCs      │
│  • Local effects     │          │  • Manages rounds     │
│                      │          │                       │
│  LocalScripts only   │          │  Scripts only         │
│  (StarterGui,        │          │  (ServerScriptService,│
│   StarterPlayerScr.) │          │   ServerStorage)      │
└──────────────────────┘          └──────────────────────┘

   RULE: The client SUGGESTS.     RULE: The server DECIDES.
   Never trust the client.        Always validate inputs.
```

### What Runs Where?

| Script Type | Runs On | Can Access | Use For |
|-------------|---------|------------|---------|
| **Script** | Server | ServerStorage, DataStoreService, all players | Game logic, data, validation |
| **LocalScript** | Client | UserInputService, local camera, local UI | Input, UI, effects, sounds |
| **ModuleScript** | Both | Depends on who requires it | Shared code, configurations |

### The Golden Rule

```
╔══════════════════════════════════════════════════════════╗
║  NEVER let the client decide game outcomes.              ║
║  The client sends INPUTS. The server makes DECISIONS.    ║
║                                                          ║
║  Client: "I clicked at position (10, 5, 20)"            ║
║  Server: "Is there a valid target? Is weapon ready?      ║
║           Is player alive? OK, apply 25 damage."         ║
╚══════════════════════════════════════════════════════════╝
```

---

## RemoteEvents and RemoteFunctions

These are how the client and server talk to each other. Think of them as walkie-talkies.

### RemoteEvent (One-Way Messages)

```lua
-- Setup: Create a RemoteEvent in ReplicatedStorage/RemoteEvents/

-- ═══════════════════════════════════════════
-- SERVER SCRIPT (ServerScriptService)
-- ═══════════════════════════════════════════
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local attackEvent = ReplicatedStorage.RemoteEvents.AttackEvent

-- Listen for client attacks
attackEvent.OnServerEvent:Connect(function(player, targetName, aimPosition)
    -- WHY validate everything? Because a hacker can send ANY data through
    -- RemoteEvents. They could send fake targetNames, impossible positions,
    -- or non-existent items.
    
    -- Validation Step 1: Does the player have a weapon?
    local weapon = player.Character and player.Character:FindFirstChild("Weapon")
    if not weapon then
        warn(player.Name .. " tried to attack without a weapon!")
        return  -- Silently reject — don't tell hackers WHY it failed
    end
    
    -- Validation Step 2: Is the target real and alive?
    local targetPlayer = game.Players:FindFirstChild(targetName)
    if not targetPlayer or not targetPlayer.Character then return end
    
    local targetHumanoid = targetPlayer.Character:FindFirstChildOfClass("Humanoid")
    if not targetHumanoid or targetHumanoid.Health <= 0 then return end
    
    -- Validation Step 3: Is the target within range?
    local distance = (player.Character.HumanoidRootPart.Position - 
                      targetPlayer.Character.HumanoidRootPart.Position).Magnitude
    if distance > weapon:GetAttribute("Range") then return end
    
    -- Validation Step 4: Is the weapon off cooldown?
    local lastAttack = weapon:GetAttribute("LastAttack") or 0
    if tick() - lastAttack < weapon:GetAttribute("Cooldown") then return end
    
    -- ALL checks passed — NOW apply damage
    weapon:SetAttribute("LastAttack", tick())
    targetHumanoid:TakeDamage(weapon:GetAttribute("Damage"))
    
    -- Tell ALL clients about the hit (for visual effects)
    attackEvent:FireAllClients(player.Name, targetName, aimPosition)
end)

-- ═══════════════════════════════════════════
-- LOCAL SCRIPT (StarterGui or StarterPlayerScripts)
-- ═══════════════════════════════════════════
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local attackEvent = ReplicatedStorage.RemoteEvents.AttackEvent

-- Send attack input to server
local function onAttackInput(targetName, aimPosition)
    -- Client just sends the input — server decides what happens
    attackEvent:FireServer(targetName, aimPosition)
end

-- Listen for attack results (visual effects for ALL players)
attackEvent.OnClientEvent:Connect(function(attackerName, targetName, hitPosition)
    -- Play hit effect, sound, screen shake — purely visual
    playHitEffect(hitPosition)
end)
```

### RemoteFunction (Request-Response)

```lua
-- RemoteFunctions return a value — like asking a question and getting an answer
-- USE SPARINGLY: They yield (pause) the script until the response comes back

-- SERVER
local getPlayerStats = ReplicatedStorage.RemoteEvents.GetPlayerStats

getPlayerStats.OnServerInvoke = function(player)
    -- WHY not just let the client read the data directly?
    -- Because the server is the source of truth. The client might have
    -- outdated or tampered data.
    local data = DataManager:GetData(player)
    return {
        Level = data.Level,
        XP = data.XP,
        Coins = data.Coins,
        -- DON'T send sensitive data like admin flags or internal IDs
    }
end

-- CLIENT
local stats = getPlayerStats:InvokeServer()
print("My level:", stats.Level)

-- ⚠️ WARNING: NEVER use OnClientInvoke
-- WHY? The server would YIELD waiting for the client to respond.
-- A hacker can simply never respond, freezing your server script forever.
-- Use FireAllClients instead for server-to-client communication.
```

### When to Use Which?

```
RemoteEvent (Fire and forget):
  ✅ Player attacks → Server validates → Applies damage
  ✅ Server announces "Round starting in 10 seconds"
  ✅ Client sends chat message → Server broadcasts

RemoteFunction (Request/Response):
  ✅ Client asks "What's in the shop?" → Server sends shop data
  ✅ Client asks "Can I afford this?" → Server checks and responds
  ❌ NEVER: Server invokes client (use RemoteEvent instead)
```

---

## Data Persistence

DataStoreService saves player data between game sessions. Get this right or players lose their progress (and your game loses players).

### Basic DataStore Pattern

```lua
-- SERVER SCRIPT ONLY — DataStoreService doesn't work on the client

local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")

-- WHY version the data store name? So you can migrate data if your
-- schema changes. "PlayerData_v3" means you're on version 3.
local playerDataStore = DataStoreService:GetDataStore("PlayerData_v3")

-- Default data template — new players get this
-- WHY define it separately? So you have ONE place to add new fields
-- when you update your game. Also makes it easy to reset during testing.
local DEFAULT_DATA = {
    Level = 1,
    XP = 0,
    Coins = 100,
    Inventory = {"StarterSword"},
    Settings = {
        MusicVolume = 0.5,
        SFXVolume = 0.8,
    },
    -- Track data version for future migrations
    DataVersion = 3,
}

-- In-memory cache — we load from DataStore once, then work from memory
-- WHY? DataStore has rate limits (60 requests/min per key). Reading from
-- memory is instant and has no limits.
local playerCache = {}

-- ═══════════════════════════════════════════
-- LOAD DATA
-- ═══════════════════════════════════════════
local function loadPlayerData(player: Player)
    local key = "Player_" .. player.UserId
    -- WHY use UserId instead of Name? Names can change. UserId is permanent.
    
    local success, data = pcall(function()
        return playerDataStore:GetAsync(key)
    end)
    
    if success then
        if data then
            -- Player has existing data
            -- WHY merge with defaults? If you added new fields in an update,
            -- existing players won't have them. Merging fills in the gaps.
            for field, defaultValue in pairs(DEFAULT_DATA) do
                if data[field] == nil then
                    data[field] = defaultValue
                end
            end
            playerCache[player.UserId] = data
        else
            -- New player — give them default data
            playerCache[player.UserId] = table.clone(DEFAULT_DATA)
        end
    else
        -- DataStore failed — DON'T kick the player!
        -- Give them default data and flag it so we don't overwrite their save
        warn("Failed to load data for " .. player.Name .. ": " .. tostring(data))
        playerCache[player.UserId] = table.clone(DEFAULT_DATA)
        playerCache[player.UserId]._loadFailed = true
    end
end

-- ═══════════════════════════════════════════
-- SAVE DATA
-- ═══════════════════════════════════════════
local function savePlayerData(player: Player)
    local data = playerCache[player.UserId]
    if not data then return end
    
    -- WHY check _loadFailed? If we couldn't load their real data, saving now
    -- would overwrite their actual save with default data. That's DATA LOSS.
    if data._loadFailed then
        warn("Skipping save for " .. player.Name .. " — load failed earlier")
        return
    end
    
    local key = "Player_" .. player.UserId
    
    local success, err = pcall(function()
        playerDataStore:SetAsync(key, data)
    end)
    
    if not success then
        warn("Failed to save data for " .. player.Name .. ": " .. err)
        -- In production, you'd want a retry queue here
    end
end

-- ═══════════════════════════════════════════
-- CONNECT EVENTS
-- ═══════════════════════════════════════════

Players.PlayerAdded:Connect(function(player)
    loadPlayerData(player)
    -- Set up leaderstats, UI, etc. after data loads
    setupLeaderstats(player)
end)

Players.PlayerRemoving:Connect(function(player)
    savePlayerData(player)
    playerCache[player.UserId] = nil  -- Clean up memory
end)

-- WHY save on game shutdown? If the server crashes or Roblox shuts it down,
-- PlayerRemoving might not fire. BindToClose gives you ~30 seconds to save.
game:BindToClose(function()
    for _, player in ipairs(Players:GetPlayers()) do
        savePlayerData(player)
    end
end)

-- Auto-save every 5 minutes as a safety net
-- WHY? If the server crashes between manual saves, players lose less progress
task.spawn(function()
    while true do
        task.wait(300)  -- 5 minutes
        for _, player in ipairs(Players:GetPlayers()) do
            savePlayerData(player)
            task.wait(1)  -- Stagger saves to avoid hitting rate limits
        end
    end
end)
```

### DataStore Rate Limits (Know These!)

```
┌────────────────────────────────────────────────────────┐
│              DATASTORE RATE LIMITS                      │
├────────────────────────────────────────────────────────┤
│  GetAsync:    60 + (numPlayers × 10) requests/min      │
│  SetAsync:    60 + (numPlayers × 10) requests/min      │
│  UpdateAsync: 60 + (numPlayers × 10) requests/min      │
│                                                         │
│  Key size:    50 characters max                         │
│  Value size:  4 MB max (but keep it under 100KB)        │
│                                                         │
│  Best practice: Load once on join, save on leave,       │
│  auto-save every 5 min, work from memory cache.         │
└────────────────────────────────────────────────────────┘
```

---

## Essential Patterns

These are the battle-tested patterns you'll use in almost every Roblox game.

### Pattern 1: Debounce (Prevent Spam)

```lua
-- Problem: Player clicks a button 20 times in 1 second
-- Without debounce: 20 purchases, 20 remote events, chaos

local debounceMap = {}

local function debounce(key: string, cooldown: number, callback: () -> ())
    if debounceMap[key] then return end
    debounceMap[key] = true
    
    callback()
    
    task.delay(cooldown, function()
        debounceMap[key] = nil
    end)
end

-- Usage:
buyButton.Activated:Connect(function()
    debounce("buy_" .. itemId, 1, function()
        buyEvent:FireServer(itemId)
    end)
end)
```

### Pattern 2: Cooldown System

```lua
-- More advanced than debounce — tracks individual ability cooldowns

local Cooldowns = {}
Cooldowns.__index = Cooldowns

function Cooldowns.new()
    return setmetatable({
        _cooldowns = {},
    }, Cooldowns)
end

function Cooldowns:start(abilityName: string, duration: number)
    self._cooldowns[abilityName] = tick() + duration
end

function Cooldowns:isReady(abilityName: string): boolean
    local expiry = self._cooldowns[abilityName]
    if not expiry then return true end
    return tick() >= expiry
end

function Cooldowns:getRemaining(abilityName: string): number
    local expiry = self._cooldowns[abilityName]
    if not expiry then return 0 end
    return math.max(0, expiry - tick())
end

-- Usage:
local playerCooldowns = Cooldowns.new()

if playerCooldowns:isReady("Fireball") then
    castFireball()
    playerCooldowns:start("Fireball", 5)  -- 5 second cooldown
else
    local remaining = playerCooldowns:getRemaining("Fireball")
    showCooldownUI(remaining)
end
```

### Pattern 3: Simple State Machine

```lua
-- WHY use a state machine? Because complex game logic with dozens of
-- if/elseif chains becomes impossible to debug. State machines make
-- the flow explicit and predictable.

local GameState = {
    LOBBY = "Lobby",
    STARTING = "Starting",
    PLAYING = "Playing",
    ROUND_END = "RoundEnd",
    GAME_OVER = "GameOver",
}

local currentState = GameState.LOBBY

-- Define what happens when entering each state
local stateHandlers = {
    [GameState.LOBBY] = function()
        print("Waiting for players...")
        showLobbyUI()
        -- Transition when enough players join
    end,
    
    [GameState.STARTING] = function()
        print("Round starting in 10 seconds!")
        showCountdownUI(10)
        task.wait(10)
        transitionTo(GameState.PLAYING)
    end,
    
    [GameState.PLAYING] = function()
        print("Round in progress!")
        startRoundTimer(120)  -- 2 minute round
        teleportPlayersToArena()
    end,
    
    [GameState.ROUND_END] = function()
        print("Round over!")
        announceWinner()
        task.wait(5)
        transitionTo(GameState.LOBBY)
    end,
}

-- Clean transition function
function transitionTo(newState: string)
    print("State:", currentState, "→", newState)
    currentState = newState
    
    local handler = stateHandlers[newState]
    if handler then
        handler()
    else
        warn("No handler for state: " .. newState)
    end
end
```

### Pattern 4: Object Pooling

```lua
-- WHY pool objects? Creating and destroying parts is EXPENSIVE.
-- If you spawn 100 bullets per second, that's 100 Instance.new() calls
-- plus 100 :Destroy() calls. Pooling reuses existing objects.

local BulletPool = {}
BulletPool.__index = BulletPool

function BulletPool.new(size: number): any
    local pool = setmetatable({
        _available = {},
        _template = nil,
    }, BulletPool)
    
    -- Pre-create bullet parts
    -- WHY pre-create? So there's no lag spike during gameplay
    local template = Instance.new("Part")
    template.Size = Vector3.new(0.2, 0.2, 1)
    template.Anchored = true
    template.CanCollide = false
    template.Name = "PooledBullet"
    pool._template = template
    
    for i = 1, size do
        local bullet = template:Clone()
        bullet.Parent = ServerStorage.BulletPool
        table.insert(pool._available, bullet)
    end
    
    return pool
end

function BulletPool:get()
    local bullet = table.remove(self._available)
    if not bullet then
        -- Pool exhausted — create a new one (but warn about it)
        warn("Bullet pool exhausted! Consider increasing pool size.")
        bullet = self._template:Clone()
    end
    bullet.Parent = Workspace
    return bullet
end

function BulletPool:release(bullet)
    bullet.Parent = ServerStorage.BulletPool
    table.insert(self._available, bullet)
end
```

### Pattern 5: Signal/Event Pattern

```lua
-- A custom event system for when Roblox's built-in events aren't enough
-- WHY? Sometimes you need events between module scripts without using
-- BindableEvents (which require Instance creation)

local Signal = {}
Signal.__index = Signal

function Signal.new()
    return setmetatable({
        _listeners = {},
    }, Signal)
end

function Signal:connect(callback: (...any) -> ())
    table.insert(self._listeners, callback)
    
    -- Return a connection object for disconnecting
    return {
        disconnect = function()
            local index = table.find(self._listeners, callback)
            if index then
                table.remove(self._listeners, index)
            end
        end,
    }
end

function Signal:fire(...)
    for _, callback in ipairs(self._listeners) do
        task.spawn(callback, ...)  -- task.spawn so one error doesn't block others
    end
end

-- Usage:
local onCoinCollected = Signal.new()

-- In your UI module:
local connection = onCoinCollected:connect(function(player, amount)
    updateCoinDisplay(player, amount)
end)

-- In your game module:
onCoinCollected:fire(player, 50)  -- Player collected 50 coins
```

---

## Module Scripts

Module scripts are reusable code that any script can `require()`. They're the key to organized, maintainable code.

### Folder Structure

```
ReplicatedStorage/
└── Modules/
    ├── Shared/           ← Used by both client AND server
    │   ├── Config.lua    ← Game constants and settings
    │   ├── Utils.lua     ← Helper functions
    │   └── Types.lua     ← Type definitions
    │
    └── Client/           ← Used by client only
        ├── UIManager.lua
        └── Effects.lua

ServerScriptService/
└── Modules/              ← Used by server only
    ├── DataManager.lua
    ├── GameManager.lua
    └── CombatManager.lua
```

### Writing a Module Script

```lua
-- ModuleScript: ReplicatedStorage/Modules/Shared/Config.lua

local Config = {}

-- Game balance constants — change these to rebalance your entire game
-- WHY put them here? So you change ONE number instead of searching 50 scripts
Config.MAX_PLAYERS = 12
Config.ROUND_DURATION = 120     -- seconds
Config.LOBBY_MIN_PLAYERS = 2
Config.RESPAWN_TIME = 5         -- seconds

-- Weapon stats — easy to balance from one location
Config.WEAPONS = {
    StarterSword = {
        Damage = 25,
        Range = 8,
        Cooldown = 0.8,
        Tier = "Common",
    },
    FireBlade = {
        Damage = 40,
        Range = 10,
        Cooldown = 1.0,
        Tier = "Rare",
    },
    ThunderHammer = {
        Damage = 60,
        Range = 6,
        Cooldown = 1.5,
        Tier = "Legendary",
    },
}

-- XP curve — how much XP needed for each level
Config.XP_CURVE = {}
for level = 1, 100 do
    -- Formula: Each level needs 20% more XP than the last
    -- Level 1: 100 XP, Level 2: 120 XP, Level 3: 144 XP, ...
    Config.XP_CURVE[level] = math.floor(100 * (1.2 ^ (level - 1)))
end

return Config

-- ═══════════════════════════════════════════
-- Using the module in another script:
-- ═══════════════════════════════════════════
-- local Config = require(ReplicatedStorage.Modules.Shared.Config)
-- local swordDamage = Config.WEAPONS.StarterSword.Damage
-- local xpNeeded = Config.XP_CURVE[playerLevel]
```

### Module Communication Pattern

```lua
-- WHY is this important? Modules should NOT require each other in circles.
-- If ModuleA requires ModuleB, and ModuleB requires ModuleA, you get
-- an infinite loop (or nil values, which is even worse to debug).

-- GOOD: Tree structure (one-directional)
--   GameManager → CombatManager → Config
--   GameManager → DataManager → Config

-- BAD: Circular dependency
--   GameManager → CombatManager → GameManager  ← INFINITE LOOP!

-- Solution for modules that need to communicate:
-- Use a shared Signal/Event module (Pattern 5 from above)
```

---

## Anti-Patterns

Things that WILL cause problems. Learn from others' mistakes.

### Anti-Pattern 1: Using wait() Instead of task.wait()

```lua
-- ❌ BAD: wait() is deprecated and has a minimum of ~0.03 seconds
wait(0.01)  -- Actually waits 0.03+ seconds!

-- ✅ GOOD: task.wait() is precise and modern
task.wait(0.01)  -- Actually waits ~0.01 seconds

-- Also use:
-- task.spawn() instead of spawn()
-- task.delay() instead of delay()
-- task.defer() instead of nothing (runs after current resumption cycle)
```

### Anti-Pattern 2: Trusting Client Data

```lua
-- ❌ BAD: Client says "give me 1000 coins" — server just does it
remoteEvent.OnServerEvent:Connect(function(player, amount)
    playerData[player.UserId].Coins += amount  -- HACKER PARADISE
end)

-- ✅ GOOD: Server decides how many coins based on game logic
remoteEvent.OnServerEvent:Connect(function(player, questId)
    local quest = Quests[questId]
    if not quest then return end
    if not hasCompletedQuest(player, questId) then return end
    
    local reward = quest.CoinReward  -- Server controls the amount
    playerData[player.UserId].Coins += reward
end)
```

### Anti-Pattern 3: Not Using pcall() for DataStore

```lua
-- ❌ BAD: If DataStore fails, your entire script crashes
local data = DataStoreService:GetDataStore("PlayerData"):GetAsync(key)

-- ✅ GOOD: Handle failures gracefully
local success, data = pcall(function()
    return DataStoreService:GetDataStore("PlayerData"):GetAsync(key)
end)

if success then
    -- Use data
else
    -- Handle error (data contains the error message)
    warn("DataStore error:", data)
end
```

### Anti-Pattern 4: Memory Leaks with Connections

```lua
-- ❌ BAD: Creating connections in PlayerAdded without cleaning up
Players.PlayerAdded:Connect(function(player)
    -- This connection lives FOREVER, even after the player leaves
    RunService.Heartbeat:Connect(function()
        updatePlayerUI(player)  -- Player might not exist anymore!
    end)
end)

-- ✅ GOOD: Store connections and clean up on PlayerRemoving
local playerConnections = {}

Players.PlayerAdded:Connect(function(player)
    playerConnections[player.UserId] = {}
    
    local connection = RunService.Heartbeat:Connect(function()
        updatePlayerUI(player)
    end)
    
    table.insert(playerConnections[player.UserId], connection)
end)

Players.PlayerRemoving:Connect(function(player)
    -- Disconnect ALL connections for this player
    local connections = playerConnections[player.UserId]
    if connections then
        for _, conn in ipairs(connections) do
            conn:Disconnect()
        end
    end
    playerConnections[player.UserId] = nil
end)
```

### Anti-Pattern 5: Giant Monolithic Scripts

```lua
-- ❌ BAD: One 2000-line script that handles everything
-- "GameScript.lua" — handles rounds, combat, data, UI, shop, quests...
-- Good luck finding anything or fixing bugs.

-- ✅ GOOD: Separate concerns into module scripts
-- GameManager.lua    — 200 lines, handles round flow
-- CombatManager.lua  — 150 lines, handles combat logic
-- DataManager.lua    — 180 lines, handles data persistence
-- ShopManager.lua    — 120 lines, handles purchases
-- QuestManager.lua   — 160 lines, handles quest tracking

-- Rule of thumb: If a script is over 300 lines, it's probably doing too much.
-- Split it into modules.
```

---

## What's Next?

Now that you understand scripting patterns:

1. **Read `monetization_guide.md`** to learn how to earn Robux from your game
2. **Read `ui_design.md`** to make your game look professional
3. **Use `examples/game_template.lua`** as your starting point
4. **Follow `publishing_checklist.md`** when you're ready to launch

Remember: **The best code is code you can understand 6 months from now.** Comment your logic, organize into modules, and name things clearly.
