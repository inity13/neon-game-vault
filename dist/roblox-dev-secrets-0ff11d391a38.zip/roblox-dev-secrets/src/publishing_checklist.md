# Roblox Publishing Checklist — From "Done" to "Live"

> A step-by-step checklist for launching your Roblox game. Print this out or check off as you go.

---

## Phase 1: Pre-Launch Testing

### Gameplay Testing

```
□ Play through the ENTIRE game as a new player
   → Is the first 5 minutes engaging?
   → Is anything confusing without explanation?

□ Test with 1 player (solo experience)
   → Does everything work alone?
   → Are there multiplayer-only deadlocks?

□ Test with maximum players
   → Does performance hold up?
   → Do game mechanics scale?

□ Test on all target platforms
   □ Desktop (Windows/Mac)
   □ Mobile (phone — small screen!)
   □ Tablet (medium screen)
   □ Xbox (if applicable — controller support)

□ Test ALL monetization flows
   □ Game Pass purchase → perk activation
   □ Developer Product purchase → item delivery
   □ What happens if purchase fails mid-transaction?

□ Test edge cases
   □ Player joins mid-round — what happens?
   □ Player leaves mid-round — does it break?
   □ Player joins, immediately leaves — any errors?
   □ All players leave — does the server handle it?
   □ Internet disconnects — what does the player see?
```

### Data Persistence Testing

```
□ Save data, leave game, rejoin → is data intact?
□ Earn items/currency, leave, rejoin → still there?
□ New player joins for the first time → default data loads correctly?
□ Stress test: rapid joins/leaves → no data corruption?
□ DataStore failure simulation (pcall catches errors gracefully?)
□ BindToClose saves all player data on server shutdown?
```

### Performance Testing

```
□ Check server memory (Developer Console → Memory)
   → Should be under 500MB for a healthy game
   → Watch for memory growing over time (leak!)

□ Check script performance (MicroProfiler — Ctrl+F5)
   → No single script taking > 1ms per frame
   → No "Stepped" or "Heartbeat" scripts doing heavy work

□ Part count check
   → Under 10,000 parts for mobile-friendly games
   → Use MeshParts and unions to reduce count

□ Network traffic (Developer Console → Network)
   → RemoteEvents aren't firing every frame
   → Large tables aren't being sent constantly
```

---

## Phase 2: Game Page Setup

### Thumbnails and Icons

```
□ Game icon (512×512 pixels)
   → Clear, eye-catching, readable at small sizes
   → Shows what the game is about
   → No text that's too small to read
   → Bright colors that stand out in search results

□ Game thumbnails (at least 3, 1920×1080 each)
   → Screenshot 1: Best gameplay moment (action shot)
   → Screenshot 2: Unique feature showcase
   → Screenshot 3: UI/shop preview (shows polish)
   → Consider a "before/after" or progression shot

□ Video thumbnail (optional but powerful)
   → 30-60 second gameplay trailer
   → Show the BEST parts first (people click away fast)
   → No long intros — jump into action
```

### Game Description

```
□ Write a compelling description (1000+ characters)

Template:
───────────────────────────────────────────
🎮 [GAME NAME] — [One-line hook]

[2-3 sentences explaining what the game is and why it's fun]

⚡ FEATURES:
• [Feature 1 — the coolest thing]
• [Feature 2 — what makes you different]
• [Feature 3 — social/multiplayer aspect]
• [Feature 4 — progression/collection]
• [Feature 5 — regular updates]

🎁 GAME PASSES:
• [VIP Pass] — [what it gives]
• [Boost Pass] — [what it gives]

🔄 UPDATE LOG:
• v1.0 — Launch!

💬 Join our community: [your social links]

Tags: [genre], [type], [feature], [keyword]
───────────────────────────────────────────

□ Use relevant tags (up to 5)
   → Genre tags: "Tycoon", "Obby", "Simulator", "RPG"
   → Feature tags: "Multiplayer", "PvP", "Building"
   → Avoid misleading tags (Roblox penalizes this)
```

### Game Settings

```
□ Max players per server
   → Standard: 12-30 depending on game type
   → Smaller = more intimate, less lag
   → Larger = more social, more server costs

□ Genre selection (pick the MOST accurate one)
   → Affects where your game appears in search

□ Playable devices
   □ Computer ← almost always yes
   □ Phone ← yes if you tested mobile UI
   □ Tablet ← yes if you tested tablet UI
   □ Console ← only if you tested controller input

□ Allow copying: OFF (protect your work!)
□ Allow third-party sales: depends on your needs
□ Allow third-party teleports: usually OFF

□ Game access
   → Public (anyone can play)
   → Private (only you and friends — for testing)
   → Start PRIVATE, switch to PUBLIC on launch day
```

---

## Phase 3: Marketing

### Before Launch (1-2 weeks ahead)

```
□ Create a Discord server for your game community
   → Channels: #announcements, #general, #suggestions, #bug-reports
   → Set up basic moderation rules
   → Invite friends to seed initial community

□ Create social media accounts
   □ TikTok — short gameplay clips (most effective for Roblox!)
   □ YouTube — longer gameplay videos, tutorials, updates
   □ X/Twitter — updates, teasers, community interaction

□ Make a launch teaser
   → 15-30 second clip showing the best gameplay moments
   → Post across all platforms
   → "Coming [date]! 🎮"

□ Reach out to Roblox content creators (small ones!)
   → Don't spam big creators — they get 1000 DMs/day
   → Find creators with 1K-50K subscribers who play your genre
   → Offer early access or exclusive in-game item
   → Be genuine, not spammy
```

### Launch Day

```
□ Set game to PUBLIC
□ Post announcement across all platforms
   → "🎮 [GAME NAME] IS LIVE! Link in bio"
   → Include your best 15-second gameplay clip
   → Pin the post

□ Be online in your game for the first few hours
   → First impressions matter
   → Fix critical bugs immediately
   → Talk to players, get feedback

□ Monitor server performance
   → Watch for crashes, lag spikes, data issues
   → Have a "kill switch" ready (private server) if something breaks badly

□ Respond to early feedback
   → Players who feel heard become loyal fans
   → "Thanks for the suggestion! We'll look into it."
```

### Post-Launch (ongoing)

```
□ Weekly content updates (keep players coming back)
   → New items, areas, features, events
   → Even small additions keep the game feeling alive
   → Post update notes on Discord and socials

□ Community management
   → Read and respond to bug reports
   → Acknowledge popular feature requests
   → Be transparent about what's coming next

□ Analytics review (weekly)
   → Track: DAU, session length, retention, revenue
   → If DAU drops, investigate why
   → If retention is low, improve the first 5 minutes
```

---

## Phase 4: Analytics & Growth

### Key Metrics to Track

```
┌─────────────────────────┬──────────────────────────────────┐
│ Metric                  │ What It Tells You                │
├─────────────────────────┼──────────────────────────────────┤
│ DAU (Daily Active Users)│ How many people play each day    │
│ Session Length           │ How long each visit lasts        │
│ D1 Retention            │ % who come back next day         │
│ D7 Retention            │ % who come back after a week     │
│ D30 Retention           │ % who come back after a month    │
│ Conversion Rate         │ % who make a purchase            │
│ ARPDAU                  │ Revenue ÷ DAU (revenue per user) │
│ Concurrent Players      │ How many online right now        │
└─────────────────────────┴──────────────────────────────────┘

Healthy benchmarks:
  Session Length: 15+ minutes (great: 30+)
  D1 Retention:  20-30% (great: 40+)
  D7 Retention:  10-15% (great: 20+)
  Conversion:    2-5% (great: 5+)
```

### Where to Find Analytics

```
Roblox Creator Dashboard (create.roblox.com):
  → Your game → Analytics tab
  → Shows: visits, playtime, retention, revenue, audience

In-Game Developer Console (F9 while playing):
  → Memory, network, script performance
  → Real-time server health

Custom analytics (advanced):
  → Use DataStoreService to log custom events
  → Track: which items sell most, where players quit, 
    which areas are popular
```

### Growth Strategies

```
ORGANIC GROWTH (free):
  □ SEO: Good title, description, and tags
  □ Regular updates (Roblox algorithm favors active games)
  □ Community: Discord, social media engagement
  □ Cross-promotion: Teleport from other games you've made
  □ Sponsored events: In-game events that create buzz

PAID GROWTH (costs Robux):
  □ Roblox Sponsored Experiences
     → Set a daily budget (start small: 100-500 Robux/day)
     → Target your audience by age, gender, device
     → Monitor cost-per-visit and adjust
  □ Collaborate with content creators (paid sponsorship)

THE MOST IMPORTANT GROWTH STRATEGY:
  Make a game so fun that players tell their friends.
  Word-of-mouth is free, powerful, and compounds.
  No amount of advertising fixes a bad game.
```

---

## Quick Reference: Launch Timeline

```
4 weeks before:  Game feature-complete, start testing
3 weeks before:  Fix bugs, optimize performance
2 weeks before:  Set up Discord, socials, game page
1 week before:   Teaser posts, creator outreach, final testing
Launch day:      Go public! Monitor, engage, fix
Week 1:          Gather feedback, hotfix bugs
Week 2:          First content update based on feedback
Monthly:         Regular updates, community events
```

---

## Emergency Checklist (When Things Go Wrong)

```
CRITICAL BUG (game-breaking):
  1. Set game to Private immediately
  2. Post on Discord: "Maintenance — fixing a critical issue"
  3. Fix the bug
  4. Test thoroughly
  5. Set game back to Public
  6. Post: "Fixed! Sorry for the downtime, here's [free item] as apology"

DATA LOSS:
  1. DON'T PANIC — check if your auto-save caught it
  2. Check DataStore version history (if you versioned your saves)
  3. If data is truly lost, be honest with players
  4. Offer compensation (in-game currency, items)
  5. Add better data protection (more frequent saves, backups)

EXPLOITER/HACKER:
  1. Document what they're doing (screenshots/video)
  2. Check your server validation (see scripting_patterns.md)
  3. Fix the exploit on the SERVER side
  4. Report the player to Roblox if needed
  5. NEVER argue with exploiters in public chat
```
