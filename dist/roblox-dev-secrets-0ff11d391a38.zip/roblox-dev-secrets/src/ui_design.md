# Roblox UI Design Guide — Make Your Game Look Pro

> Professional UI/UX patterns that make players stick around.

---

## Table of Contents

1. [UI Fundamentals](#ui-fundamentals)
2. [Core UI Elements](#core-elements)
3. [Responsive Layouts](#responsive-layouts)
4. [UI Animation with TweenService](#animation)
5. [Common UI Patterns](#common-patterns)
6. [Color Theory for Games](#color-theory)
7. [Mobile-Friendly Design](#mobile-design)
8. [Accessibility](#accessibility)

---

## UI Fundamentals

### The UI Hierarchy

```
PlayerGui                      ← Each player gets their own
└── ScreenGui                  ← A "layer" of UI (can have multiple)
    ├── Frame                  ← Container/box (like a div in HTML)
    │   ├── TextLabel          ← Display text
    │   ├── TextButton         ← Clickable text
    │   ├── ImageLabel         ← Display image
    │   ├── ImageButton        ← Clickable image
    │   └── TextBox            ← Text input field
    └── Frame
        └── ...

Key concepts:
  • Everything is nested inside ScreenGui
  • Frames are your layout containers
  • Position/Size use UDim2 (scale + offset)
  • ZIndex controls which elements appear on top
```

### UDim2 — The Positioning System

```lua
-- UDim2.new(scaleX, offsetX, scaleY, offsetY)
-- Scale: 0-1 (percentage of parent)    Offset: pixels

-- Center of screen:
frame.Position = UDim2.new(0.5, 0, 0.5, 0)
frame.AnchorPoint = Vector2.new(0.5, 0.5)  -- Center the anchor too!
-- WHY AnchorPoint? Without it, Position refers to the top-left corner.
-- With AnchorPoint(0.5, 0.5), Position refers to the center.

-- Top-right corner with 10px padding:
frame.Position = UDim2.new(1, -10, 0, 10)
frame.AnchorPoint = Vector2.new(1, 0)

-- Full width, fixed height:
frame.Size = UDim2.new(1, 0, 0, 50)  -- 100% wide, 50px tall

-- Common shortcut:
UDim2.fromScale(0.5, 0.5)   -- Same as UDim2.new(0.5, 0, 0.5, 0)
UDim2.fromOffset(100, 50)   -- Same as UDim2.new(0, 100, 0, 50)
```

### The Parent-Child Relationship

```
A child's Scale is relative to its PARENT, not the screen.

ScreenGui (1920×1080)
└── MainFrame (Size: 0.5, 0, 0.5, 0)  → 960×540 pixels
    └── InnerFrame (Size: 0.5, 0, 0.5, 0)  → 480×270 pixels
         (50% of MainFrame, NOT 50% of screen)

WHY this matters: Nesting frames lets you create responsive
layouts without calculating pixel positions manually.
```

---

## Core Elements

### TextLabel — Displaying Text

```lua
local label = Instance.new("TextLabel")
label.Name = "HealthDisplay"
label.Size = UDim2.fromScale(0.2, 0.05)
label.Position = UDim2.fromScale(0.5, 0.02)
label.AnchorPoint = Vector2.new(0.5, 0)

-- Text properties
label.Text = "HP: 100/100"
label.TextColor3 = Color3.fromRGB(255, 255, 255)   -- White text
label.TextScaled = true     -- Auto-size text to fit the label
-- WHY TextScaled? It makes text readable on ALL screen sizes.
-- Without it, text might be tiny on mobile or huge on 4K monitors.

label.Font = Enum.Font.GothamBold
-- WHY GothamBold? It's Roblox's cleanest, most readable font.
-- Avoid fancy fonts for gameplay UI — readability > aesthetics.

-- Background
label.BackgroundColor3 = Color3.fromRGB(30, 30, 30)    -- Dark background
label.BackgroundTransparency = 0.3                       -- Slightly transparent

-- Corners (modern look)
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 8)
corner.Parent = label

label.Parent = screenGui
```

### TextButton — Clickable Buttons

```lua
local button = Instance.new("TextButton")
button.Name = "ShopButton"
button.Size = UDim2.fromOffset(200, 50)
button.Position = UDim2.fromScale(0.5, 0.9)
button.AnchorPoint = Vector2.new(0.5, 1)

button.Text = "Open Shop"
button.TextColor3 = Color3.fromRGB(255, 255, 255)
button.TextScaled = true
button.Font = Enum.Font.GothamBold

button.BackgroundColor3 = Color3.fromRGB(0, 120, 255)  -- Blue

-- Rounded corners
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 12)
corner.Parent = button

-- Padding for text
local padding = Instance.new("UIPadding")
padding.PaddingLeft = UDim.new(0, 16)
padding.PaddingRight = UDim.new(0, 16)
padding.Parent = button

-- Click handler
button.Activated:Connect(function()
    -- WHY Activated instead of MouseButton1Click?
    -- Activated works on BOTH mouse and touch (mobile/tablet)
    -- MouseButton1Click only works with a mouse
    toggleShop()
end)

-- Hover effect (desktop)
button.MouseEnter:Connect(function()
    -- Lighten the button on hover
    TweenService:Create(button, TweenInfo.new(0.15), {
        BackgroundColor3 = Color3.fromRGB(50, 150, 255),
    }):Play()
end)

button.MouseLeave:Connect(function()
    TweenService:Create(button, TweenInfo.new(0.15), {
        BackgroundColor3 = Color3.fromRGB(0, 120, 255),
    }):Play()
end)
```

---

## Responsive Layouts

Layout objects automatically arrange children — no manual positioning needed.

### UIListLayout — Vertical/Horizontal Lists

```lua
-- Creates a vertical list of items (like a menu or inventory column)
local listLayout = Instance.new("UIListLayout")
listLayout.FillDirection = Enum.FillDirection.Vertical
listLayout.SortOrder = Enum.SortOrder.LayoutOrder
listLayout.Padding = UDim.new(0, 8)  -- 8px between items
-- WHY Padding? Without spacing, buttons touch each other,
-- making them hard to tap on mobile (fat finger problem)
listLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
listLayout.Parent = menuFrame

-- Each child just needs a LayoutOrder
local button1 = createButton("Play")
button1.LayoutOrder = 1
button1.Parent = menuFrame

local button2 = createButton("Shop")
button2.LayoutOrder = 2
button2.Parent = menuFrame

-- They'll stack vertically, centered, with 8px gaps
```

### UIGridLayout — Grid of Items (Inventory, Shop)

```lua
-- Perfect for inventory screens, shop grids, achievement displays
local gridLayout = Instance.new("UIGridLayout")
gridLayout.CellSize = UDim2.fromOffset(80, 80)   -- Each cell is 80x80
gridLayout.CellPadding = UDim2.fromOffset(8, 8)  -- 8px gap
gridLayout.SortOrder = Enum.SortOrder.LayoutOrder
gridLayout.FillDirection = Enum.FillDirection.Horizontal
-- FillDirection.Horizontal = left to right, then wraps down
gridLayout.Parent = inventoryFrame

-- Add items — they auto-arrange into a grid!
for i, item in ipairs(playerInventory) do
    local slot = createInventorySlot(item)
    slot.LayoutOrder = i
    slot.Parent = inventoryFrame
end
```

### UIAspectRatioConstraint — Keep It Square

```lua
-- WHY? Without this, a "square" frame becomes rectangular
-- on different screen sizes. This forces a consistent ratio.

local constraint = Instance.new("UIAspectRatioConstraint")
constraint.AspectRatio = 1        -- 1:1 (square)
-- constraint.AspectRatio = 16/9  -- For widescreen panels
constraint.Parent = iconFrame
```

### Auto-Sizing Frames (ScrollingFrame)

```lua
-- For content that might be longer than the screen (chat, inventory, etc.)
local scroll = Instance.new("ScrollingFrame")
scroll.Size = UDim2.fromScale(0.3, 0.6)
scroll.Position = UDim2.fromScale(0.5, 0.5)
scroll.AnchorPoint = Vector2.new(0.5, 0.5)

scroll.CanvasSize = UDim2.new(0, 0, 0, 0)  -- Will be auto-set
scroll.AutomaticCanvasSize = Enum.AutomaticSize.Y  -- Auto-grow vertically
scroll.ScrollBarThickness = 6
scroll.ScrollBarImageColor3 = Color3.fromRGB(150, 150, 150)

-- WHY AutomaticCanvasSize? So you don't have to manually calculate
-- how tall the content is. The frame figures it out automatically.

local listLayout = Instance.new("UIListLayout")
listLayout.Padding = UDim.new(0, 4)
listLayout.Parent = scroll

-- Add children — scroll area grows automatically
```

---

## UI Animation with TweenService

Smooth animations make your UI feel polished and professional. TweenService is your best friend.

### Basic Tween

```lua
local TweenService = game:GetService("TweenService")

-- Fade in a frame
local function fadeIn(frame: Frame, duration: number?)
    duration = duration or 0.3
    
    frame.Visible = true
    frame.BackgroundTransparency = 1  -- Start invisible
    
    local tween = TweenService:Create(
        frame,
        TweenInfo.new(
            duration,                          -- Duration
            Enum.EasingStyle.Quint,            -- Easing style
            Enum.EasingDirection.Out            -- Easing direction
        ),
        {BackgroundTransparency = 0}           -- Target properties
    )
    
    tween:Play()
end

-- Slide in from the right
local function slideInFromRight(frame: Frame)
    frame.Position = UDim2.fromScale(1.5, 0.5)  -- Start off-screen
    frame.Visible = true
    
    TweenService:Create(frame, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
        Position = UDim2.fromScale(0.5, 0.5),  -- Slide to center
    }):Play()
    -- WHY EasingStyle.Back? It slightly overshoots then settles,
    -- creating a bouncy, satisfying feel.
end

-- Scale pop (for notifications, achievements)
local function popIn(frame: Frame)
    frame.Size = UDim2.fromScale(0, 0)  -- Start at zero size
    frame.Visible = true
    
    TweenService:Create(frame, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
        Size = UDim2.fromScale(0.4, 0.3),  -- Target size
    }):Play()
end
```

### Common Easing Styles Cheatsheet

```
┌──────────────────┬──────────────────────────────────────┐
│ Easing Style     │ When to Use                          │
├──────────────────┼──────────────────────────────────────┤
│ Linear           │ Progress bars, continuous movement    │
│ Quad             │ Subtle, natural movement              │
│ Quint            │ Smooth fade-ins and slides            │
│ Back             │ Bouncy pop-ins (menus, notifications)│
│ Bounce           │ Playful, cartoonish UI               │
│ Elastic          │ Exaggerated spring effect             │
│ Sine             │ Gentle, breathing animations          │
│ Exponential      │ Snappy, responsive interactions       │
├──────────────────┼──────────────────────────────────────┤
│ Direction:       │                                      │
│  Out  → Fast at  │ Best for enter/open animations       │
│        start     │                                      │
│  In   → Slow at  │ Best for exit/close animations       │
│        start     │                                      │
│  InOut → Both    │ Best for moving between positions    │
└──────────────────┴──────────────────────────────────────┘
```

### Button Press Animation

```lua
-- Make buttons feel responsive by scaling them on press
local function setupButtonFeedback(button: TextButton)
    local originalSize = button.Size
    
    button.MouseButton1Down:Connect(function()
        -- Shrink slightly on press
        TweenService:Create(button, TweenInfo.new(0.05), {
            Size = UDim2.new(
                originalSize.X.Scale * 0.95, originalSize.X.Offset,
                originalSize.Y.Scale * 0.95, originalSize.Y.Offset
            ),
        }):Play()
    end)
    
    button.MouseButton1Up:Connect(function()
        -- Spring back
        TweenService:Create(button, TweenInfo.new(0.15, Enum.EasingStyle.Back), {
            Size = originalSize,
        }):Play()
    end)
end
```

---

## Common UI Patterns

### Pattern 1: Health Bar

```
┌─────────────────────────────────────────────────┐
│ ████████████████████░░░░░░░░░░░░  HP: 67/100   │
└─────────────────────────────────────────────────┘
```

```lua
-- Structure:
-- BackgroundFrame (dark)
--   └── FillFrame (colored, changes width based on HP)
--   └── TextLabel (HP text)

local function createHealthBar(parent: Frame)
    local background = Instance.new("Frame")
    background.Name = "HealthBar"
    background.Size = UDim2.new(0.3, 0, 0, 30)
    background.Position = UDim2.fromScale(0.02, 0.02)
    background.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
    
    local fill = Instance.new("Frame")
    fill.Name = "Fill"
    fill.Size = UDim2.fromScale(1, 1)  -- 100% = full health
    fill.BackgroundColor3 = Color3.fromRGB(0, 200, 50)  -- Green
    fill.Parent = background
    
    local text = Instance.new("TextLabel")
    text.Name = "HealthText"
    text.Size = UDim2.fromScale(1, 1)
    text.BackgroundTransparency = 1
    text.Text = "100/100"
    text.TextColor3 = Color3.fromRGB(255, 255, 255)
    text.TextScaled = true
    text.Font = Enum.Font.GothamBold
    text.ZIndex = 2  -- On top of the fill bar
    text.Parent = background
    
    -- Corner rounding for both
    Instance.new("UICorner", background).CornerRadius = UDim.new(0, 6)
    Instance.new("UICorner", fill).CornerRadius = UDim.new(0, 6)
    
    background.Parent = parent
    return background
end

-- Update function:
local function updateHealthBar(healthBar, current: number, max: number)
    local fill = healthBar.Fill
    local text = healthBar.HealthText
    local ratio = math.clamp(current / max, 0, 1)
    
    -- Animate the fill bar
    TweenService:Create(fill, TweenInfo.new(0.3, Enum.EasingStyle.Quint), {
        Size = UDim2.fromScale(ratio, 1),
    }):Play()
    
    -- Change color based on health level
    -- WHY color change? Visual urgency — red means "you're about to die"
    local color
    if ratio > 0.6 then
        color = Color3.fromRGB(0, 200, 50)    -- Green (healthy)
    elseif ratio > 0.3 then
        color = Color3.fromRGB(255, 200, 0)   -- Yellow (caution)
    else
        color = Color3.fromRGB(255, 50, 50)   -- Red (danger!)
    end
    
    TweenService:Create(fill, TweenInfo.new(0.3), {
        BackgroundColor3 = color,
    }):Play()
    
    text.Text = current .. "/" .. max
end
```

### Pattern 2: Shop Grid

```
┌─────────────────────────────────────────────┐
│  ⚔ SHOP                              [X]   │
├─────────┬─────────┬─────────┬─────────┤     │
│ [Sword] │ [Shield]│ [Potion]│ [Armor] │     │
│  250 🪙  │  180 🪙 │  50 🪙  │  400 🪙 │     │
│  [BUY]  │  [BUY]  │  [BUY]  │  [BUY]  │     │
├─────────┼─────────┼─────────┼─────────┤     │
│ [Boots] │ [Ring]  │ [Helm]  │ [Staff] │     │
│  120 🪙  │  300 🪙 │  200 🪙 │  350 🪙 │     │
│  [BUY]  │  [BUY]  │  [BUY]  │  [BUY]  │     │
└─────────┴─────────┴─────────┴─────────┘     │
│  Your Coins: 500 🪙                          │
└─────────────────────────────────────────────┘
```

```lua
-- The shop uses UIGridLayout for auto-arrangement
local function createShopUI()
    -- Main container
    local shop = Instance.new("Frame")
    shop.Name = "ShopUI"
    shop.Size = UDim2.fromScale(0.6, 0.7)
    shop.Position = UDim2.fromScale(0.5, 0.5)
    shop.AnchorPoint = Vector2.new(0.5, 0.5)
    shop.BackgroundColor3 = Color3.fromRGB(25, 25, 35)
    Instance.new("UICorner", shop).CornerRadius = UDim.new(0, 16)
    
    -- Title bar
    local titleBar = Instance.new("Frame")
    titleBar.Size = UDim2.new(1, 0, 0, 50)
    titleBar.BackgroundColor3 = Color3.fromRGB(35, 35, 50)
    titleBar.Parent = shop
    
    -- Scrollable item grid
    local scroll = Instance.new("ScrollingFrame")
    scroll.Size = UDim2.new(1, -20, 1, -110)  -- Minus title and footer
    scroll.Position = UDim2.fromOffset(10, 60)
    scroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
    scroll.BackgroundTransparency = 1
    scroll.Parent = shop
    
    local grid = Instance.new("UIGridLayout")
    grid.CellSize = UDim2.fromOffset(120, 150)
    grid.CellPadding = UDim2.fromOffset(10, 10)
    grid.SortOrder = Enum.SortOrder.LayoutOrder
    grid.Parent = scroll
    
    -- Populate with items
    local shopItems = getShopItems()  -- Your item data
    for i, item in ipairs(shopItems) do
        local card = createShopCard(item)
        card.LayoutOrder = i
        card.Parent = scroll
    end
    
    return shop
end
```

### Pattern 3: Notification Toast

```
  ┌──────────────────────────────┐
  │  ✓ Achievement Unlocked!     │   ← Slides in from top
  │    First Victory             │   ← Stays for 3 seconds
  └──────────────────────────────┘   ← Slides out
```

```lua
local function showNotification(message: string, subtext: string?, duration: number?)
    duration = duration or 3
    
    local notification = Instance.new("Frame")
    notification.Size = UDim2.new(0.3, 0, 0, 60)
    notification.Position = UDim2.new(0.5, 0, -0.1, 0)  -- Start above screen
    notification.AnchorPoint = Vector2.new(0.5, 0)
    notification.BackgroundColor3 = Color3.fromRGB(40, 180, 80)
    Instance.new("UICorner", notification).CornerRadius = UDim.new(0, 12)
    notification.Parent = screenGui
    
    -- Title
    local title = Instance.new("TextLabel")
    title.Size = UDim2.new(1, -20, 0, 30)
    title.Position = UDim2.fromOffset(10, 5)
    title.BackgroundTransparency = 1
    title.Text = message
    title.TextColor3 = Color3.fromRGB(255, 255, 255)
    title.TextScaled = true
    title.Font = Enum.Font.GothamBold
    title.TextXAlignment = Enum.TextXAlignment.Left
    title.Parent = notification
    
    -- Slide in
    TweenService:Create(notification, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
        Position = UDim2.new(0.5, 0, 0, 10),
    }):Play()
    
    -- Wait, then slide out
    task.delay(duration, function()
        local out = TweenService:Create(notification, TweenInfo.new(0.3, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
            Position = UDim2.new(0.5, 0, -0.1, 0),
        })
        out:Play()
        out.Completed:Wait()
        notification:Destroy()
    end)
end
```

---

## Color Theory for Games

### Color Palettes That Work

```
DARK THEME (most popular for games):
  Background:  #1a1a2e (very dark blue)    Color3.fromRGB(26, 26, 46)
  Panel:       #16213e (dark navy)          Color3.fromRGB(22, 33, 62)
  Accent:      #0f3460 (deep blue)          Color3.fromRGB(15, 52, 96)
  Highlight:   #e94560 (vibrant pink/red)   Color3.fromRGB(233, 69, 96)

GAMING NEON:
  Background:  #0d0d0d (near black)         Color3.fromRGB(13, 13, 13)
  Panel:       #1a1a2e (dark purple)        Color3.fromRGB(26, 26, 46)
  Primary:     #00ff88 (neon green)         Color3.fromRGB(0, 255, 136)
  Secondary:   #ff006e (neon pink)          Color3.fromRGB(255, 0, 110)

CLEAN MINIMAL:
  Background:  #f0f0f0 (light gray)         Color3.fromRGB(240, 240, 240)
  Panel:       #ffffff (white)              Color3.fromRGB(255, 255, 255)
  Primary:     #2196f3 (blue)               Color3.fromRGB(33, 150, 243)
  Text:        #333333 (dark gray)          Color3.fromRGB(51, 51, 51)
```

### Color for UI States

```lua
-- Use consistent colors for states across your entire UI
local UI_COLORS = {
    -- Actions
    Primary    = Color3.fromRGB(0, 120, 255),   -- Main action (Buy, Play)
    Secondary  = Color3.fromRGB(100, 100, 120),  -- Secondary action (Cancel)
    Danger     = Color3.fromRGB(220, 50, 50),    -- Destructive (Delete, Sell)
    Success    = Color3.fromRGB(40, 180, 80),     -- Confirmation (Purchased!)
    
    -- Rarity (universal gaming convention)
    Common     = Color3.fromRGB(180, 180, 180),  -- Gray
    Uncommon   = Color3.fromRGB(30, 200, 30),    -- Green
    Rare       = Color3.fromRGB(30, 120, 255),   -- Blue
    Epic       = Color3.fromRGB(180, 50, 255),   -- Purple
    Legendary  = Color3.fromRGB(255, 180, 0),    -- Gold/Orange
    
    -- Backgrounds
    Dark       = Color3.fromRGB(25, 25, 35),
    Medium     = Color3.fromRGB(40, 40, 55),
    Light      = Color3.fromRGB(60, 60, 75),
}
```

---

## Mobile-Friendly Design

**Over 70% of Roblox players are on mobile.** If your UI doesn't work on phones, you're losing most of your audience.

### Mobile Design Rules

```
1. TOUCH TARGETS: Minimum 44×44 pixels
   WHY? Fingers are bigger than mouse cursors. Small buttons
   are impossible to tap accurately on a phone.

2. BOTTOM OF SCREEN: Most important buttons go here
   WHY? That's where thumbs naturally rest. Putting buttons
   at the top means players have to stretch.

3. NO HOVER STATES: Mobile has no "hover"
   WHY? There's no mouse cursor on a phone. Hover-revealed
   info needs a different trigger (tap, long press).

4. LESS TEXT: Mobile screens are small
   Instead of "Click here to open the shop"
   Just show a shop icon with a coin count.

5. CLOSE BUTTONS: Make them BIG and obvious
   Nothing is more frustrating than a tiny [X] on mobile.

6. TEST AT 50% SCALE: In Studio, resize the viewport
   to phone proportions. Does everything still work?
```

### Detecting Platform

```lua
local UserInputService = game:GetService("UserInputService")

local function isMobile(): boolean
    return UserInputService.TouchEnabled 
       and not UserInputService.KeyboardEnabled
end

local function isTablet(): boolean
    return UserInputService.TouchEnabled 
       and UserInputService.KeyboardEnabled
end

-- Adjust UI based on platform
if isMobile() then
    -- Larger buttons, simplified layout
    shopButton.Size = UDim2.fromOffset(120, 60)
    inventoryGrid.CellSize = UDim2.fromOffset(100, 100)
else
    -- Standard sizes for desktop
    shopButton.Size = UDim2.fromOffset(80, 40)
    inventoryGrid.CellSize = UDim2.fromOffset(80, 80)
end
```

---

## Accessibility

Making your UI accessible isn't just nice — it expands your audience.

### Text Readability

```
MINIMUM CONTRAST RATIOS:
  Regular text:  4.5:1 (light text on dark background)
  Large text:    3:1
  UI components: 3:1

GOOD:  White (#FFFFFF) on dark blue (#1a1a2e) = 15.7:1  ✅
BAD:   Gray (#888888) on dark blue (#1a1a2e) = 4.2:1    ⚠️ (barely ok)
AWFUL: Dark gray (#555555) on dark blue (#1a1a2e) = 2.3:1  ❌

Tool: Search "WebAIM contrast checker" for a free online tool.
```

### Don't Rely Solely on Color

```
❌ BAD: Health bar is green/red with no text
   Color-blind players can't tell them apart!

✅ GOOD: Health bar has color AND text "HP: 67/100"
   Works for everyone regardless of color vision.

❌ BAD: "Click the blue button" in a tutorial
   Which blue? The one that looks gray to a color-blind player?

✅ GOOD: "Click the [EQUIP] button" with clear labels
   The label works regardless of color perception.
```

### Font Size Options

```lua
-- Let players adjust text size — it's simple to implement
local TEXT_SCALE = {
    Small = 0.8,
    Normal = 1.0,
    Large = 1.3,
    ExtraLarge = 1.6,
}

local function setTextScale(scaleName: string)
    local scale = TEXT_SCALE[scaleName] or 1.0
    
    -- Apply to all TextLabels/TextButtons in the UI
    for _, element in ipairs(screenGui:GetDescendants()) do
        if element:IsA("TextLabel") or element:IsA("TextButton") then
            local baseSize = element:GetAttribute("BaseTextSize") or 14
            element.TextSize = math.floor(baseSize * scale)
        end
    end
end
```

---

## UI Design Checklist

```
Before shipping your UI:

  Layout:
  □ Works on desktop (1920×1080)
  □ Works on mobile (phone AND tablet)
  □ No overlapping elements at any screen size
  □ ScrollingFrame for content that might overflow
  □ Close buttons are easy to find and tap

  Visual:
  □ Consistent color palette (max 3-4 colors)
  □ Text is readable on all backgrounds
  □ Rarity/state colors follow gaming conventions
  □ Rounded corners (UICorner) on all frames
  □ Consistent padding and spacing

  Animation:
  □ Menus open/close with smooth transitions
  □ Buttons have press/hover feedback
  □ Notifications slide in/out
  □ No animation longer than 0.5 seconds (feels sluggish)

  Accessibility:
  □ Text labels on all interactive elements
  □ Color is not the ONLY indicator of state
  □ Minimum 44×44 touch targets on mobile
  □ High contrast between text and background

  Performance:
  □ No UI updates every frame (use events instead)
  □ Invisible frames have Visible = false (not just transparency)
  □ Destroyed UI elements when no longer needed
```
