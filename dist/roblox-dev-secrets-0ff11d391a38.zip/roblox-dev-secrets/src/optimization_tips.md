# Roblox Optimization Tips — Make Your Game Run Smooth

> Performance optimization techniques that keep your game playable on phones AND PCs.

---

## Table of Contents

1. [Why Performance Matters](#why-performance-matters)
2. [Part Count Management](#part-count)
3. [Script Optimization](#script-optimization)
4. [Memory Management](#memory-management)
5. [Network Optimization](#network-optimization)
6. [Rendering and Lighting](#rendering)
7. [Mobile-Specific Optimization](#mobile)
8. [Profiling Tools](#profiling)
9. [Common Performance Killers](#performance-killers)

---

## Why Performance Matters

```
PERFORMANCE = PLAYERS

  Smooth (60 FPS):  Players stay, play longer, spend more
  Choppy (30 FPS):  Players tolerate it but complain
  Laggy (15 FPS):   Players leave and never come back
  Unplayable (<10): You get thumbs-down and bad reviews

Remember: 70%+ of Roblox players are on MOBILE.
A phone from 2020 has less power than a gaming PC from 2015.
If it doesn't run on a mid-range phone, you're losing most players.
```

---

## Part Count Management

Parts (blocks, meshes, unions) are the #1 performance factor. Every part needs to be:
- Rendered (drawn on screen)
- Physics-simulated (if not anchored)
- Networked (synced between client and server)

### Reducing Part Count

```
TECHNIQUE 1: Use MeshParts Instead of Many Parts
  ❌ A tree made of 50 small green parts = 50 parts
  ✅ A tree as a single MeshPart = 1 part
  
  WHY? Each part is a separate render call. Fewer parts = fewer calls.

TECHNIQUE 2: Use Unions Sparingly
  Unions merge parts into one... but they're NOT free.
  → Small unions (2-5 parts) are fine
  → Huge unions (50+ parts) can actually be SLOWER than the parts
  → Unions can't be modified at runtime
  → Use MeshParts instead for complex shapes

TECHNIQUE 3: Anchor Everything That Doesn't Move
  ❌ A building made of 200 unanchored parts = 200 physics calculations/frame
  ✅ Anchor static objects = 0 physics calculations
  
  Workspace → Select all static parts → Properties → Anchored = true

TECHNIQUE 4: StreamingEnabled
  Roblox's built-in LOD (Level of Detail) system.
  Only loads parts that are NEAR the player.
  
  Workspace → Properties → StreamingEnabled = true
  StreamingMinRadius = 64    -- Always loaded within 64 studs
  StreamingTargetRadius = 256 -- Tries to load within 256 studs
  
  WHY? A huge map with 50,000 parts but StreamingEnabled only
  loads ~5,000 at a time. Massive performance boost.
```

### Part Count Budgets

```
┌──────────────────┬─────────────────────────────────────┐
│ Platform         │ Recommended Part Budget              │
├──────────────────┼─────────────────────────────────────┤
│ Desktop (good PC)│ 50,000 - 100,000 parts              │
│ Desktop (avg PC) │ 20,000 - 50,000 parts               │
│ Tablet           │ 10,000 - 20,000 parts               │
│ Phone (modern)   │ 5,000 - 15,000 parts                │
│ Phone (older)    │ Under 5,000 parts                   │
├──────────────────┼─────────────────────────────────────┤
│ With Streaming   │ Multiply budget by 3-5x             │
│ (total map size) │ (only nearby parts count)            │
└──────────────────┴─────────────────────────────────────┘
```

---

## Script Optimization

### Use task Library (Modern Roblox)

```lua
-- The task library is FASTER and MORE PRECISE than the old functions

-- ❌ OLD (deprecated, imprecise):
wait(1)              -- Minimum ~0.03s, often longer
spawn(function() end) -- Deferred, unpredictable timing  
delay(1, function() end)

-- ✅ NEW (precise, reliable):
task.wait(1)         -- Actually waits ~1 second
task.spawn(function() end)  -- Runs immediately in new thread
task.delay(1, function() end)  -- Runs after 1 second
task.defer(function() end)  -- Runs at end of current cycle
```

### Avoid Per-Frame Expensive Operations

```lua
-- ❌ BAD: Finding parts by name EVERY FRAME
RunService.Heartbeat:Connect(function()
    local part = Workspace:FindFirstChild("TargetPart")  -- Searching every frame!
    if part then
        -- do stuff
    end
end)

-- ✅ GOOD: Cache the reference ONCE
local targetPart = Workspace:WaitForChild("TargetPart")  -- Find once
RunService.Heartbeat:Connect(function()
    -- Use cached reference — no search needed
    if targetPart then
        -- do stuff
    end
end)
```

### Limit Loop Frequency

```lua
-- ❌ BAD: Updating ALL enemies every frame (60 times/second)
RunService.Heartbeat:Connect(function()
    for _, enemy in ipairs(enemies) do
        updateEnemyAI(enemy)  -- If you have 100 enemies, that's 6,000 AI updates/second!
    end
end)

-- ✅ GOOD: Update enemies on a timer (2-5 times/second is fine for AI)
local AI_UPDATE_INTERVAL = 0.2  -- 5 times per second

task.spawn(function()
    while true do
        for _, enemy in ipairs(enemies) do
            updateEnemyAI(enemy)
        end
        task.wait(AI_UPDATE_INTERVAL)
    end
end)

-- ✅ EVEN BETTER: Stagger updates (not all at once)
task.spawn(function()
    local index = 1
    while true do
        if #enemies > 0 then
            local enemy = enemies[index]
            updateEnemyAI(enemy)
            
            index = index + 1
            if index > #enemies then index = 1 end
        end
        task.wait(AI_UPDATE_INTERVAL / #enemies)
        -- Each enemy updates every AI_UPDATE_INTERVAL seconds
        -- but they're spread out across frames
    end
end)
```

### String Operations

```lua
-- ❌ BAD: Concatenating strings in a loop (creates new string each time)
local result = ""
for i = 1, 1000 do
    result = result .. "item" .. i .. ", "
    -- Each concatenation creates a BRAND NEW string object
    -- 1000 iterations = 1000 string allocations = garbage collector nightmare
end

-- ✅ GOOD: Use table.concat
local parts = {}
for i = 1, 1000 do
    table.insert(parts, "item" .. i)
end
local result = table.concat(parts, ", ")
-- Only ONE final string is created
```

---

## Memory Management

### Common Memory Leaks

```lua
-- LEAK 1: Connections that never disconnect
-- Every :Connect() creates a persistent reference.
-- If the object is destroyed but the connection lives on, that's a leak.

-- ❌ BAD:
part.Touched:Connect(function(hit)
    -- This connection lives even if 'part' is destroyed!
end)

-- ✅ GOOD: Disconnect when done
local connection = part.Touched:Connect(function(hit)
    handleTouch(hit)
end)

-- Later, when the part is no longer needed:
connection:Disconnect()
part:Destroy()


-- LEAK 2: Tables that grow but never shrink
-- ❌ BAD:
local playerHistory = {}
game.Players.PlayerAdded:Connect(function(player)
    playerHistory[player.UserId] = {}
end)
-- Players leave but their data stays in the table FOREVER

-- ✅ GOOD: Clean up on leave
game.Players.PlayerRemoving:Connect(function(player)
    playerHistory[player.UserId] = nil  -- Allow garbage collection
end)


-- LEAK 3: Cloned instances that are never parented or destroyed
-- ❌ BAD:
local clone = template:Clone()
-- clone is in memory but has no parent — invisible, uncollectable
-- You can't even find it to destroy it!

-- ✅ GOOD: Always parent or destroy clones
local clone = template:Clone()
clone.Parent = Workspace  -- Visible and trackable
-- OR
clone:Destroy()  -- If you decided you don't need it
```

### Memory Monitoring

```lua
-- Check memory usage in-game
local stats = game:GetService("Stats")

task.spawn(function()
    while true do
        -- Get memory in MB
        local memory = stats:GetTotalMemoryUsageMb()
        
        if memory > 500 then
            warn("HIGH MEMORY: " .. math.floor(memory) .. "MB")
            -- Consider cleaning up cached data, destroying unused instances
        end
        
        task.wait(30)  -- Check every 30 seconds
    end
end)
```

---

## Network Optimization

Every RemoteEvent, replicated property change, and part movement is sent over the network. On mobile with slow internet, this matters A LOT.

### Reduce RemoteEvent Traffic

```lua
-- ❌ BAD: Sending position every frame
RunService.Heartbeat:Connect(function()
    updateEvent:FireServer(character.HumanoidRootPart.Position)
    -- That's 60 network messages PER SECOND per player
    -- 20 players × 60/sec = 1,200 messages/second!
end)

-- ✅ GOOD: Send only when significantly changed
local lastSentPosition = Vector3.zero
local MIN_DISTANCE = 2  -- Only send if moved 2+ studs

RunService.Heartbeat:Connect(function()
    local pos = character.HumanoidRootPart.Position
    if (pos - lastSentPosition).Magnitude > MIN_DISTANCE then
        updateEvent:FireServer(pos)
        lastSentPosition = pos
    end
end)

-- ✅ EVEN BETTER: Use Roblox's built-in replication
-- Character positions are already replicated automatically!
-- You DON'T need to send them manually unless doing custom movement.
```

### Minimize Data Size in Remote Calls

```lua
-- ❌ BAD: Sending huge tables
remoteEvent:FireServer({
    PlayerName = player.Name,
    Position = character.HumanoidRootPart.Position,
    Rotation = character.HumanoidRootPart.Orientation,
    Health = humanoid.Health,
    MaxHealth = humanoid.MaxHealth,
    Inventory = getFullInventory(),  -- Could be massive!
    Settings = getAllSettings(),
    Timestamp = os.time(),
})

-- ✅ GOOD: Send only what the server NEEDS for this specific action
remoteEvent:FireServer(actionType, targetPosition)
-- The server already knows the player's health, inventory, etc.
-- It can look them up itself — no need to trust client data anyway!
```

### Rate Limiting on the Server

```lua
-- Prevent clients from flooding the server with RemoteEvents
local lastFireTime = {}
local RATE_LIMIT = 0.1  -- Max 10 fires per second

remoteEvent.OnServerEvent:Connect(function(player, ...)
    local now = tick()
    local last = lastFireTime[player.UserId] or 0
    
    if now - last < RATE_LIMIT then
        -- Too fast — ignore (probably an exploiter)
        return
    end
    
    lastFireTime[player.UserId] = now
    
    -- Process the event normally
    handleEvent(player, ...)
end)
```

---

## Rendering and Lighting

### Lighting Settings for Performance

```
Technology matters:

  ShadowMap (default):
    → Good quality, moderate performance
    → Fine for most games
  
  Future:
    → Best quality, heaviest performance
    → Looks amazing but kills mobile performance
    → Only use if your game is desktop-only
  
  Voxel:
    → Fastest lighting mode
    → Lower quality but runs great on mobile
    → Good for stylized/cartoon games
  
  Compatibility:
    → Lowest quality, best performance
    → Use as a fallback for very low-end devices

RECOMMENDATION:
  Start with ShadowMap. If mobile performance is bad,
  switch to Voxel. Use Future only for desktop-only games.
```

### Particle and Effect Optimization

```lua
-- Particles are EXPENSIVE on mobile. Use them sparingly.

-- ❌ BAD: 1000-particle explosion
local emitter = Instance.new("ParticleEmitter")
emitter.Rate = 1000
emitter.Lifetime = NumberRange.new(3, 5)
-- 1000 particles × 5 second lifetime = up to 5000 particles on screen!

-- ✅ GOOD: Impactful with fewer particles
local emitter = Instance.new("ParticleEmitter")
emitter.Rate = 50   -- Way fewer, but make each one bigger/brighter
emitter.Lifetime = NumberRange.new(0.5, 1.5)  -- Shorter lifetime
emitter.Size = NumberSequence.new({
    NumberSequenceKeypoint.new(0, 2),    -- Start big
    NumberSequenceKeypoint.new(1, 0),    -- Shrink to nothing
})

-- ✅ BEST: Use emit() instead of Rate for one-time effects
emitter.Rate = 0  -- Don't continuously emit
emitter:Emit(20)  -- Burst 20 particles, then done
```

---

## Mobile-Specific Optimization

### Auto Quality Settings

```lua
-- Detect device capability and adjust graphics
local function getDeviceTier(): string
    local platform = UserInputService:GetPlatform()
    
    if platform == Enum.Platform.Windows or platform == Enum.Platform.OSX then
        return "High"
    elseif platform == Enum.Platform.IOS or platform == Enum.Platform.Android then
        -- Check if it's a tablet (larger screen = usually more powerful)
        local screenSize = Workspace.CurrentCamera.ViewportSize
        if screenSize.X > 1200 then
            return "Medium"  -- Tablet
        else
            return "Low"     -- Phone
        end
    else
        return "Medium"  -- Unknown, play it safe
    end
end

-- Apply quality settings
local function applyQuality(tier: string)
    local lighting = game:GetService("Lighting")
    
    if tier == "Low" then
        lighting.GlobalShadows = false
        lighting.Technology = Enum.Technology.Voxel
        game.Workspace.StreamingMinRadius = 32
        -- Disable expensive effects on mobile
    elseif tier == "Medium" then
        lighting.GlobalShadows = true
        lighting.Technology = Enum.Technology.ShadowMap
        game.Workspace.StreamingMinRadius = 64
    else -- "High"
        lighting.GlobalShadows = true
        lighting.Technology = Enum.Technology.ShadowMap
        game.Workspace.StreamingMinRadius = 128
    end
end
```

---

## Profiling Tools

### Developer Console (F9)

```
Open with F9 in-game. Key tabs:

  Log:     Error messages and warnings
  Memory:  Memory usage by category
  Network: Incoming/outgoing data
  
  What to look for:
  → Memory growing over time = memory leak
  → Network spikes = too many remote events
  → Repeated errors = unhandled edge cases
```

### MicroProfiler (Ctrl+F5)

```
The most powerful profiling tool. Shows EXACTLY what's slow.

Open with Ctrl+F5. You'll see colored bars:
  → Each bar = one frame
  → Tall bars = slow frames (lag!)
  → Click a tall bar to see what's causing it

Color coding:
  Green  = Rendering (graphics)
  Blue   = Physics
  Orange = Scripts (your code!)
  Red    = Network

If orange bars are tall:
  → Your scripts are too heavy
  → Find the function name in the bar and optimize it

If green bars are tall:
  → Too many parts or particles
  → Reduce part count or particle effects

If blue bars are tall:
  → Too many unanchored parts
  → Anchor static objects
```

### Script Performance Logging

```lua
-- Simple performance timer for debugging
local function measureTime(label: string, callback: () -> ())
    local start = os.clock()
    callback()
    local elapsed = os.clock() - start
    
    if elapsed > 0.001 then  -- More than 1ms
        warn(string.format("[PERF] %s took %.3fms", label, elapsed * 1000))
    end
end

-- Usage:
measureTime("Enemy AI Update", function()
    for _, enemy in ipairs(enemies) do
        updateEnemyAI(enemy)
    end
end)

-- If you see "[PERF] Enemy AI Update took 5.234ms" — that's a problem!
-- A full frame at 60 FPS is only 16.6ms. One function taking 5ms leaves
-- only 11.6ms for EVERYTHING else.
```

---

## Common Performance Killers

### The Top 10 Performance Mistakes

```
1. ❌ Unanchored parts that don't need physics
   FIX: Anchor all static objects

2. ❌ FindFirstChild/WaitForChild in loops
   FIX: Cache references outside the loop

3. ❌ Firing RemoteEvents every frame
   FIX: Only fire when data actually changes

4. ❌ Using wait() instead of task.wait()
   FIX: Replace all wait() calls

5. ❌ Not using StreamingEnabled on large maps
   FIX: Enable it in Workspace properties

6. ❌ Thousands of particles on mobile
   FIX: Reduce particle count, use :Emit() bursts

7. ❌ Memory leaks (connections never disconnected)
   FIX: Disconnect on PlayerRemoving, use Maid/Janitor patterns

8. ❌ String concatenation in hot loops
   FIX: Use table.concat

9. ❌ Heavy AI/logic running on Heartbeat (every frame)
   FIX: Run AI on a timer (0.2-0.5 second intervals)

10.❌ Future lighting on mobile
   FIX: Use ShadowMap or Voxel for mobile-friendly games
```

### Performance Budget Guide

```
Your game gets 16.6ms per frame (at 60 FPS).

Budget allocation:
  Rendering:     6-8ms  (graphics, particles, UI)
  Physics:       2-3ms  (moving parts, collisions)
  Your Scripts:  3-5ms  (game logic, AI, data)
  Network:       1-2ms  (remote events, replication)
  Overhead:      1-2ms  (Roblox engine internals)

If any category exceeds its budget, you get frame drops.
Use MicroProfiler to identify which category is the culprit.
```

---

## Optimization Checklist

```
Before launch, verify:

Parts & World:
  □ All static objects are Anchored
  □ StreamingEnabled is ON for large maps
  □ Part count is within budget for target platform
  □ No invisible/unused parts left in workspace

Scripts:
  □ All wait() replaced with task.wait()
  □ No FindFirstChild inside Heartbeat/RenderStepped
  □ AI updates are on timers, not per-frame
  □ All connections are disconnected on cleanup

Memory:
  □ Player data cleaned up on PlayerRemoving
  □ No growing tables without cleanup
  □ Cloned instances are always parented or destroyed
  □ Memory usage stable over 30+ minutes of play

Network:
  □ RemoteEvents fire only when needed
  □ Minimal data sent per remote call
  □ Server-side rate limiting on all RemoteEvents
  □ No client-to-server data the server already knows

Rendering:
  □ Lighting technology appropriate for target platform
  □ Particle effects use burst :Emit(), not high Rate
  □ UI elements with Visible = false when hidden
  □ No unnecessary per-frame UI updates
```
