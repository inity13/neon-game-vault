# Roblox Monetization Guide — Earn Robux Without Being Scummy

> How to build a sustainable revenue stream while keeping your players happy.

---

## Table of Contents

1. [The Robux Economy](#the-robux-economy)
2. [Game Passes — Your Bread and Butter](#game-passes)
3. [Developer Products — Consumables That Sell](#developer-products)
4. [In-Game Currency Systems](#in-game-currency)
5. [Premium Payouts](#premium-payouts)
6. [Ethical Monetization Principles](#ethical-principles)
7. [Pricing Psychology](#pricing-psychology)
8. [Revenue Estimation](#revenue-estimation)
9. [A/B Testing Your Monetization](#ab-testing)

---

## The Robux Economy

### How Money Flows

```
Player buys Robux → Spends in your game → You earn Robux → DevEx to real money
     ($)              (Game Pass/Product)    (70% of sale)    (Robux → USD)

Exchange Rate (DevEx):
  100,000 Robux = $350 USD (as of 2024)
  That's $0.0035 per Robux

So a 100 Robux Game Pass earns you:
  100 × 0.70 (Roblox takes 30%) = 70 Robux
  70 × $0.0035 = $0.245 per sale

Sounds small? At 1,000 sales/month = $245/month
At 10,000 sales/month = $2,450/month
```

### DevEx Requirements

To cash out your Robux, you need:
- **Minimum 30,000 Robux** in your account
- **13+ years old** (with ID verification)
- Active Roblox Premium subscription
- Account in good standing (no bans/warnings)
- Consistent earnings (not just one-time spikes)

**Reality check:** Most games won't qualify for DevEx immediately. Focus on making a great game first, monetization second. Players can smell cash grabs.

---

## Game Passes

Game Passes are **permanent, one-time purchases**. Once a player buys it, they own it forever. Think of them as DLC.

### What Sells Well

| Game Pass Type | Example | Typical Price | Why It Works |
|---------------|---------|---------------|--------------|
| **Cosmetic** | Custom trail, special hat | 50-200 R$ | Doesn't affect gameplay, pure flex |
| **Convenience** | 2x speed, extra storage | 100-500 R$ | Saves time without being unfair |
| **VIP Access** | VIP server room, exclusive area | 200-1000 R$ | Exclusivity feels special |
| **Progression Boost** | 2x XP (not 2x damage!) | 100-400 R$ | Speeds up earning, not power |
| **Creative Tools** | Extra build slots, custom colors | 50-300 R$ | For creative/sandbox games |

### What to AVOID

```
╔══════════════════════════════════════════════════════════╗
║  ❌ PAY-TO-WIN GAME PASSES (will kill your game)         ║
║                                                          ║
║  • "God Mode" — No one wants to play against invincible  ║
║    players. Free players quit, and buyers have no one    ║
║    to play with.                                         ║
║                                                          ║
║  • "Instant Max Level" — Removes the entire point of     ║
║    playing your game. Buyers get bored in 5 minutes.     ║
║                                                          ║
║  • "Super Weapon" — Free players feel cheated and leave.  ║
║    Your game gets review-bombed.                         ║
║                                                          ║
║  Rule: If a free player can't compete, your              ║
║  monetization is broken.                                 ║
╚══════════════════════════════════════════════════════════╝
```

### Implementing Game Passes

```lua
-- SERVER SCRIPT
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")

-- Store Game Pass IDs in one place for easy management
local GAME_PASSES = {
    VIP = 12345678,           -- Replace with your actual Game Pass ID
    DoubleXP = 12345679,
    RadioAccess = 12345680,
}

-- Check if a player owns a Game Pass
local function ownsGamePass(player: Player, passName: string): boolean
    local passId = GAME_PASSES[passName]
    if not passId then return false end
    
    -- WHY pcall? MarketplaceService calls can fail due to network issues
    local success, ownsPass = pcall(function()
        return MarketplaceService:UserOwnsGamePassAsync(player.UserId, passId)
    end)
    
    return success and ownsPass
end

-- Apply Game Pass perks on join
Players.PlayerAdded:Connect(function(player)
    if ownsGamePass(player, "VIP") then
        player:SetAttribute("IsVIP", true)
        -- Give VIP chat tag, nameplate, etc.
    end
    
    if ownsGamePass(player, "DoubleXP") then
        player:SetAttribute("XPMultiplier", 2)
    else
        player:SetAttribute("XPMultiplier", 1)
    end
end)

-- Handle mid-game purchases
MarketplaceService.PromptGamePassPurchaseFinished:Connect(function(player, passId, purchased)
    if not purchased then return end
    
    if passId == GAME_PASSES.VIP then
        player:SetAttribute("IsVIP", true)
    elseif passId == GAME_PASSES.DoubleXP then
        player:SetAttribute("XPMultiplier", 2)
    end
end)
```

---

## Developer Products

Developer Products are **consumable purchases** — the player can buy them multiple times. Think in-game currency packs, extra lives, or instant items.

### Best-Selling Developer Product Ideas

| Product | Price Range | Notes |
|---------|-------------|-------|
| Coin packs (100, 500, 1000) | 25-500 R$ | The classic. Works in any game. |
| Extra life/respawn | 10-25 R$ | For difficult games only |
| Loot crate/mystery box | 25-100 R$ | Show odds! Be transparent. |
| Skip timer/instant complete | 10-50 R$ | For tycoon/idle games |
| Cosmetic randomizer | 50-200 R$ | Must show odds to be ethical |

### Implementing Developer Products

```lua
-- SERVER SCRIPT
local MarketplaceService = game:GetService("MarketplaceService")

local PRODUCTS = {
    SmallCoinPack  = { Id = 11111111, Coins = 100 },
    MediumCoinPack = { Id = 11111112, Coins = 500 },
    LargeCoinPack  = { Id = 11111113, Coins = 1200 },  -- 20% bonus!
}

-- WHY ProcessReceipt? This is the ONLY reliable way to grant Developer Products.
-- Roblox calls this function and expects you to return 
-- Enum.ProductPurchaseDecision.PurchaseGranted when the item is successfully given.
-- If you return anything else (or error), Roblox will retry later.
MarketplaceService.ProcessReceipt = function(receiptInfo)
    local player = Players:GetPlayerByUserId(receiptInfo.PlayerId)
    if not player then
        -- Player left before we could grant the item
        -- Return NotProcessedYet so Roblox retries when they rejoin
        return Enum.ProductPurchaseDecision.NotProcessedYet
    end
    
    local productId = receiptInfo.ProductId
    
    -- Find which product was purchased
    for name, product in pairs(PRODUCTS) do
        if product.Id == productId then
            -- Grant the coins
            local data = playerCache[player.UserId]
            if data then
                data.Coins = data.Coins + product.Coins
                -- Save immediately after purchase — don't risk losing it
                savePlayerData(player)
                
                -- Notify the player
                notifyPlayer(player, "+" .. product.Coins .. " coins!")
                
                return Enum.ProductPurchaseDecision.PurchaseGranted
            end
        end
    end
    
    -- Unknown product — don't grant
    warn("Unknown product purchased:", productId)
    return Enum.ProductPurchaseDecision.NotProcessedYet
end
```

---

## In-Game Currency Systems

Many successful games have their own currency. Here's how to design one that works.

### Single vs. Dual Currency

```
SINGLE CURRENCY (Simpler, more fair):
  • Coins — earned by playing AND purchasable
  • Everything costs Coins
  • Pro: Simple for players to understand
  • Con: Hard to monetize if earning rate is too generous

DUAL CURRENCY (More common, more revenue):
  • Coins — earned by playing (free currency)
  • Gems — purchased with Robux (premium currency)
  • Some items cost Coins, premium items cost Gems
  • Pro: Separates free and paid content clearly
  • Con: Can feel unfair if not balanced well

RECOMMENDATION FOR NEW DEVS:
  Start with SINGLE currency. It's simpler to balance
  and players trust you more. Add a premium currency
  later if your game grows.
```

### Balancing Your Economy

```
The key formula:

  EARN RATE × PLAY TIME = TOTAL EARNINGS
  TOTAL EARNINGS should buy something satisfying every 30-60 minutes

Example:
  Player earns 10 coins/minute
  In 30 minutes they earn 300 coins
  → Make sure there's something cool for 200-400 coins

  If the ONLY way to afford things is buying Robux,
  free players will quit and your game dies.

Economy health check:
  ✅ Free players can earn everything (just takes longer)
  ✅ Paid currency is for convenience/cosmetics, not power
  ✅ Something to buy at every price point (cheap AND expensive)
  ✅ A "sink" to remove currency (upgrades, customization, consumables)
  ✅ Players always have something to save up for (long-term goals)
```

---

## Premium Payouts

Roblox Premium members earn you Robux just by playing your game — no purchase required!

### How It Works

```
1. Roblox takes a percentage of each Premium subscriber's fee
2. That pool gets distributed to developers based on "engagement time"
3. The more time Premium players spend in YOUR game, the more you earn

Engagement Time Score = Time Premium players spend in your game
                       ÷ Total time across ALL Roblox games

You don't need to do anything special — just make a game people
want to play for a long time. That said, you CAN incentivize
Premium players:
```

### Premium-Specific Perks (Optional)

```lua
-- Detect Premium players and give them bonuses
-- WHY do this? It encourages free players to buy Premium,
-- and Premium players feel valued in your game.

Players.PlayerAdded:Connect(function(player)
    if player.MembershipType == Enum.MembershipType.Premium then
        player:SetAttribute("CoinMultiplier", 1.5)  -- 50% more coins
        -- Give a special badge/nameplate
        grantPremiumBadge(player)
    end
end)

-- Also detect if someone upgrades mid-game
Players.PlayerMembershipChanged:Connect(function(player)
    if player.MembershipType == Enum.MembershipType.Premium then
        player:SetAttribute("CoinMultiplier", 1.5)
        notifyPlayer(player, "Premium activated! You now earn 50% more coins!")
    end
end)
```

---

## Ethical Monetization Principles

These aren't just nice-to-have. Games that violate these principles lose players fast.

### The 5 Rules

```
1. FREE PLAYERS MUST BE ABLE TO COMPETE
   If a free player can never beat a paying player,
   your game is pay-to-win and will die.

2. PAYING SHOULD SAVE TIME, NOT BUY POWER
   ✅ "2x XP boost" (gets there faster)
   ❌ "2x damage" (unfair advantage)

3. ALWAYS SHOW ODDS FOR RANDOM ITEMS
   If you sell mystery boxes or random drops,
   SHOW THE EXACT PERCENTAGES.
   ✅ "70% Common, 25% Rare, 5% Legendary"
   ❌ "Open for a surprise!"

4. NO PRESSURE TACTICS
   ❌ "Buy NOW or miss out forever!"
   ❌ Popup ads every 30 seconds
   ❌ Making the game unplayable without purchases
   ✅ Shop is always available, no artificial urgency

5. DELIVER REAL VALUE
   Every purchase should make the player think
   "That was worth it." Not "I feel tricked."
```

### The Newspaper Test

> Before adding ANY monetization feature, ask: "If a journalist wrote an article about how my game makes money, would I be embarrassed?"
> 
> If yes, redesign it.

---

## Pricing Psychology

How to set prices that feel fair and maximize revenue.

### The Pricing Ladder

```
Don't just sell one thing. Create a ladder of options at different price points:

  FREE          → Core gameplay (must be fun on its own!)
  25-50 R$      → Small cosmetics, basic conveniences
  100-200 R$    → Significant upgrades, popular Game Passes
  500-1000 R$   → Premium content, VIP access
  
WHY a ladder? Different players have different budgets.
Some will spend 25 R$, some will spend 1000 R$.
If you only have expensive options, you lose the 25 R$ buyers.
If you only have cheap options, whales (big spenders) have nothing to buy.
```

### The Anchor Effect

```
If you want to sell a 200 R$ Game Pass, show a 500 R$ option next to it.

  VIP Bronze  — 100 R$  (basic perks)
  VIP Silver  — 200 R$  (good perks)   ← Most people buy this
  VIP Gold    — 500 R$  (all perks)

The Gold option makes Silver look like a great deal.
This is called "anchoring" — the expensive option sets the reference point.
```

### Bundle Discounts

```
Individual:
  Custom Trail   — 50 R$
  Extra Slot     — 75 R$
  Radio Access   — 100 R$
  Total: 225 R$

Bundle (Starter Pack) — 150 R$  (33% off!)

WHY bundles work:
  1. Players feel like they're getting a deal
  2. You sell items that players might not buy individually
  3. Higher total revenue per player
```

---

## Revenue Estimation

Use this formula to estimate your game's potential revenue:

```
Monthly Revenue Formula:

  Daily Active Users (DAU) × Conversion Rate × Average Purchase × 30 days

  Conservative estimates:
    Conversion Rate: 2-5% of players make any purchase
    Average Purchase: 100-300 Robux

  Example: "Acme Tycoon" with 500 DAU
    500 × 0.03 × 150 × 30 = 67,500 Robux/month
    After Roblox's 30% cut: 47,250 Robux
    DevEx value: ~$165/month

  Example: "Example Obby" with 5,000 DAU
    5,000 × 0.04 × 200 × 30 = 1,200,000 Robux/month
    After Roblox's 30% cut: 840,000 Robux
    DevEx value: ~$2,940/month
```

### Revenue Tracking Spreadsheet

Track these numbers weekly:

```
┌──────────┬──────┬──────────────┬─────────────┬──────────────┐
│ Week     │ DAU  │ Total Sales  │ Revenue (R$) │ Conv. Rate   │
├──────────┼──────┼──────────────┼─────────────┼──────────────┤
│ Week 1   │      │              │             │              │
│ Week 2   │      │              │             │              │
│ Week 3   │      │              │             │              │
│ Week 4   │      │              │             │              │
├──────────┼──────┼──────────────┼─────────────┼──────────────┤
│ Monthly  │ Avg: │   Total:     │   Total:    │   Average:   │
└──────────┴──────┴──────────────┴─────────────┴──────────────┘
```

---

## A/B Testing Your Monetization

Don't guess — test. Here's a simple A/B testing approach:

### Method: Attribute-Based Groups

```lua
-- Assign players to test groups on first join
-- WHY random? So the groups are statistically similar
local function assignTestGroup(player: Player): string
    -- Use UserId for consistent assignment (same player always gets same group)
    -- WHY UserId? So a player doesn't switch groups when they rejoin
    if player.UserId % 2 == 0 then
        return "GroupA"
    else
        return "GroupB"
    end
end

-- Then show different prices to different groups:
Players.PlayerAdded:Connect(function(player)
    local group = assignTestGroup(player)
    player:SetAttribute("TestGroup", group)
    
    if group == "GroupA" then
        -- Show coin pack at 100 Robux
        showShopPrice(player, "CoinPack", 100)
    else
        -- Show coin pack at 75 Robux
        showShopPrice(player, "CoinPack", 75)
    end
end)

-- After a week, compare:
-- Group A: 100 sales × 100 R$ = 10,000 R$ revenue
-- Group B: 150 sales × 75 R$  = 11,250 R$ revenue
-- Group B wins! Lower price generated more total revenue.
```

### What to Test

- **Price points:** Is 100 or 75 Robux better for coin packs?
- **Shop placement:** Button on HUD vs. separate shop building?
- **Bundle composition:** Which items sell better together?
- **Timing:** Show shop after 5 minutes of play vs. 15 minutes?

### What NOT to Test

- **Core gameplay:** Don't make the game worse for one group
- **Fairness:** Both groups should have the same gameplay experience
- **Too many things at once:** Test ONE variable at a time

---

## Quick Reference: Monetization Checklist

```
Before Launch:
  □ At least 3 Game Passes at different price points
  □ At least 1 Developer Product (consumable)
  □ Free players can enjoy the full core experience
  □ All random items have visible odds
  □ No pay-to-win mechanics
  □ Shop UI is clean and non-intrusive
  □ ProcessReceipt handles all products correctly
  □ Data saves immediately after purchase

After Launch:
  □ Track daily revenue and conversion rate
  □ Read player feedback about fairness
  □ A/B test one pricing change per month
  □ Add new items regularly to keep the shop fresh
  □ Never retroactively nerf paid items (players will revolt)
```
