-- ═══════════════════════════════════════════════════════════════
-- ROBLOX MODULE SCRIPT EXAMPLES
-- ═══════════════════════════════════════════════════════════════
--
-- This file contains example module scripts showing how to:
--   • Organize code into reusable modules
--   • Create a combat system module
--   • Create an inventory management module
--   • Create a settings/configuration module
--   • Handle module communication without circular dependencies
--
-- HOW TO USE:
--   Each module below should be its own ModuleScript in your game.
--   Copy the section you need into a new ModuleScript in the
--   appropriate location (ServerScriptService/Modules/ for server,
--   ReplicatedStorage/Modules/ for shared).
--
-- MODULE LOCATION GUIDE:
--   ServerScriptService/Modules/   → Server-only modules
--   ReplicatedStorage/Modules/     → Shared modules (client + server)
--   StarterPlayerScripts/Modules/  → Client-only modules
-- ═══════════════════════════════════════════════════════════════


-- ╔═══════════════════════════════════════════════════════════╗
-- ║  MODULE 1: CombatManager                                  ║
-- ║  Location: ServerScriptService/Modules/CombatManager       ║
-- ║  Purpose: Handles all combat logic on the server           ║
-- ╚═══════════════════════════════════════════════════════════╝

--[[
    WHY a CombatManager module?
    
    Without it, combat logic ends up scattered across 10 different scripts:
    - The sword script handles melee
    - The gun script handles ranged
    - The grenade script handles explosions
    - The trap script handles environmental damage
    
    With CombatManager, ALL damage goes through ONE place.
    This means:
    1. Easy to add shields, buffs, damage reduction
    2. Easy to track kill/assist stats
    3. Easy to prevent exploits (one validation point)
    4. Easy to log combat events for analytics
]]

local CombatManager = {}

-- Services
local Players = game:GetService("Players")

-- Dependencies (require other modules here)
-- local Config = require(script.Parent.Parent.ReplicatedStorage.Modules.Shared.Config)

-- Internal state
local damageLog = {}  -- Track recent damage for assists
local ASSIST_WINDOW = 10  -- Seconds to count as an assist

-- Record damage dealt (for kill/assist tracking)
local function logDamage(attackerId, targetId, amount)
    if not damageLog[targetId] then
        damageLog[targetId] = {}
    end
    
    table.insert(damageLog[targetId], {
        attackerId = attackerId,
        amount = amount,
        timestamp = tick(),
    })
    
    -- Clean old entries
    local cutoff = tick() - ASSIST_WINDOW
    local log = damageLog[targetId]
    local i = 1
    while i <= #log do
        if log[i].timestamp < cutoff then
            table.remove(log, i)
        else
            i = i + 1
        end
    end
end

-- Get assists for a kill (players who damaged the target recently)
local function getAssists(targetId, killerId)
    local assists = {}
    local log = damageLog[targetId]
    if not log then return assists end
    
    local seen = {}
    for _, entry in ipairs(log) do
        -- Don't count the killer as an assist
        if entry.attackerId ~= killerId and not seen[entry.attackerId] then
            seen[entry.attackerId] = true
            table.insert(assists, entry.attackerId)
        end
    end
    
    return assists
end

-- ═════════════════════════════════════
-- PUBLIC API
-- ═════════════════════════════════════

-- Apply damage from one player to another
-- Returns: killed (boolean), overkill amount
function CombatManager:dealDamage(attacker, target, baseDamage, damageType)
    -- Validate inputs (NEVER trust what's passed in)
    if not attacker or not target then return false, 0 end
    if not attacker.Character or not target.Character then return false, 0 end
    
    local targetHumanoid = target.Character:FindFirstChildOfClass("Humanoid")
    if not targetHumanoid or targetHumanoid.Health <= 0 then return false, 0 end
    
    -- Calculate final damage (apply modifiers here!)
    local finalDamage = baseDamage
    
    -- Example: Check for shield buff
    local shield = target:GetAttribute("Shield") or 0
    if shield > 0 then
        -- Shield absorbs damage first
        local absorbed = math.min(shield, finalDamage)
        target:SetAttribute("Shield", shield - absorbed)
        finalDamage = finalDamage - absorbed
    end
    
    -- Example: Check for damage boost on attacker
    local damageMultiplier = attacker:GetAttribute("DamageMultiplier") or 1
    finalDamage = finalDamage * damageMultiplier
    
    -- Log the damage (for assist tracking)
    logDamage(attacker.UserId, target.UserId, finalDamage)
    
    -- Apply damage
    local healthBefore = targetHumanoid.Health
    targetHumanoid:TakeDamage(finalDamage)
    
    -- Check if this killed the target
    local killed = targetHumanoid.Health <= 0
    local overkill = killed and (finalDamage - healthBefore) or 0
    
    if killed then
        -- Handle kill
        self:_onKill(attacker, target)
    end
    
    return killed, overkill
end

-- Internal: Handle kill event
function CombatManager:_onKill(killer, victim)
    print(killer.Name .. " eliminated " .. victim.Name)
    
    -- Get assists
    local assistIds = getAssists(victim.UserId, killer.UserId)
    
    -- Award kill points to killer
    -- (In a real game, you'd fire events or call other modules here)
    
    -- Award assist points
    for _, assistId in ipairs(assistIds) do
        local assister = Players:GetPlayerByUserId(assistId)
        if assister then
            print(assister.Name .. " got an assist!")
        end
    end
    
    -- Clean up damage log for this target
    damageLog[victim.UserId] = nil
end

-- Check if an attack would be valid (use before dealing damage)
function CombatManager:canAttack(attacker, target, weaponRange)
    -- Is the attacker alive?
    local attackerHumanoid = attacker.Character 
        and attacker.Character:FindFirstChildOfClass("Humanoid")
    if not attackerHumanoid or attackerHumanoid.Health <= 0 then
        return false, "Attacker is dead"
    end
    
    -- Is the target alive?
    local targetHumanoid = target.Character 
        and target.Character:FindFirstChildOfClass("Humanoid")
    if not targetHumanoid or targetHumanoid.Health <= 0 then
        return false, "Target is dead"
    end
    
    -- Is the target in range?
    local distance = (
        attacker.Character.HumanoidRootPart.Position - 
        target.Character.HumanoidRootPart.Position
    ).Magnitude
    
    if distance > weaponRange then
        return false, "Out of range"
    end
    
    -- No friendly fire (if teams exist)
    if attacker.Team and target.Team and attacker.Team == target.Team then
        return false, "Friendly fire"
    end
    
    return true, "Valid"
end

-- Clean up when a player leaves
function CombatManager:playerLeft(player)
    damageLog[player.UserId] = nil
end

return CombatManager


-- ╔═══════════════════════════════════════════════════════════╗
-- ║  MODULE 2: InventoryManager                               ║
-- ║  Location: ServerScriptService/Modules/InventoryManager    ║
-- ║  Purpose: Manages player inventories                       ║
-- ╚═══════════════════════════════════════════════════════════╝

--[[
    WHY an InventoryManager module?
    
    Player inventories touch EVERYTHING:
    - Data saving/loading
    - Shop purchases
    - Equipment/loadout
    - Trading (if you have it)
    - Drop/pickup systems
    
    One module handles all inventory operations, ensuring:
    1. Consistent validation (can't have negative items)
    2. Easy integration with DataStore
    3. Simple API for other modules to use
]]

local InventoryManager = {}

-- Item database — define all items in your game here
-- In a real game, this might be a separate Config module
local ITEMS = {
    StarterSword = {
        Name = "Starter Sword",
        Type = "Weapon",
        Rarity = "Common",
        MaxStack = 1,
        Tradeable = false,
        Description = "A basic sword. Everyone starts with one.",
    },
    HealthPotion = {
        Name = "Health Potion",
        Type = "Consumable",
        Rarity = "Common",
        MaxStack = 99,
        Tradeable = true,
        Description = "Restores 50 HP when used.",
    },
    FireBlade = {
        Name = "Fire Blade",
        Type = "Weapon",
        Rarity = "Rare",
        MaxStack = 1,
        Tradeable = true,
        Description = "A flaming sword that deals bonus fire damage.",
    },
    GoldenCrown = {
        Name = "Golden Crown",
        Type = "Cosmetic",
        Rarity = "Legendary",
        MaxStack = 1,
        Tradeable = false,
        Description = "A crown that shows everyone you're royalty.",
    },
}

-- ═════════════════════════════════════
-- PUBLIC API
-- ═════════════════════════════════════

-- Get item info from the database
function InventoryManager:getItemInfo(itemId)
    return ITEMS[itemId]
end

-- Check if a player has an item (and optionally a minimum count)
function InventoryManager:hasItem(playerData, itemId, minCount)
    minCount = minCount or 1
    local inventory = playerData.Inventory
    
    for _, slot in ipairs(inventory) do
        if slot.id == itemId and slot.count >= minCount then
            return true
        end
    end
    
    return false
end

-- Get the count of an item in a player's inventory
function InventoryManager:getItemCount(playerData, itemId)
    for _, slot in ipairs(playerData.Inventory) do
        if slot.id == itemId then
            return slot.count
        end
    end
    return 0
end

-- Add an item to a player's inventory
-- Returns: success (boolean), message (string)
function InventoryManager:addItem(playerData, itemId, count)
    count = count or 1
    
    -- Validate item exists
    local itemInfo = ITEMS[itemId]
    if not itemInfo then
        return false, "Unknown item: " .. itemId
    end
    
    -- Check for existing stack
    for _, slot in ipairs(playerData.Inventory) do
        if slot.id == itemId then
            local newCount = slot.count + count
            if newCount > itemInfo.MaxStack then
                return false, "Inventory full (max " .. itemInfo.MaxStack .. ")"
            end
            slot.count = newCount
            return true, "Added " .. count .. "x " .. itemInfo.Name
        end
    end
    
    -- New item — add a new slot
    if count > itemInfo.MaxStack then
        return false, "Exceeds max stack size"
    end
    
    table.insert(playerData.Inventory, {
        id = itemId,
        count = count,
    })
    
    return true, "Added " .. count .. "x " .. itemInfo.Name
end

-- Remove an item from a player's inventory
-- Returns: success (boolean), message (string)
function InventoryManager:removeItem(playerData, itemId, count)
    count = count or 1
    
    for i, slot in ipairs(playerData.Inventory) do
        if slot.id == itemId then
            if slot.count < count then
                return false, "Not enough items (have " .. slot.count .. ", need " .. count .. ")"
            end
            
            slot.count = slot.count - count
            
            -- Remove empty slots
            if slot.count <= 0 then
                table.remove(playerData.Inventory, i)
            end
            
            return true, "Removed " .. count .. "x " .. ITEMS[itemId].Name
        end
    end
    
    return false, "Item not found in inventory"
end

-- Get full inventory as a formatted list (for UI display)
function InventoryManager:getInventoryList(playerData)
    local list = {}
    
    for _, slot in ipairs(playerData.Inventory) do
        local info = ITEMS[slot.id]
        if info then
            table.insert(list, {
                id = slot.id,
                name = info.Name,
                type = info.Type,
                rarity = info.Rarity,
                count = slot.count,
                maxStack = info.MaxStack,
                tradeable = info.Tradeable,
            })
        end
    end
    
    return list
end

return InventoryManager


-- ╔═══════════════════════════════════════════════════════════╗
-- ║  MODULE 3: SettingsManager                                ║
-- ║  Location: ReplicatedStorage/Modules/Shared/Settings       ║
-- ║  Purpose: Player settings that sync between client/server  ║
-- ╚═══════════════════════════════════════════════════════════╝

--[[
    WHY a SettingsManager module?
    
    Player settings need to:
    1. Persist between sessions (saved to DataStore)
    2. Be accessible on both client AND server
    3. Have validation (volume can't be negative or > 1)
    4. Have defaults for new players
    
    This module lives in ReplicatedStorage so BOTH client and server
    can require() it. The server handles saving, the client handles
    displaying the settings UI.
]]

local SettingsManager = {}

-- Define all settings with their defaults and validation rules
local SETTINGS_SCHEMA = {
    MusicVolume = {
        default = 0.5,
        type = "number",
        min = 0,
        max = 1,
        description = "Background music volume",
    },
    SFXVolume = {
        default = 0.8,
        type = "number",
        min = 0,
        max = 1,
        description = "Sound effects volume",
    },
    Sensitivity = {
        default = 0.5,
        type = "number",
        min = 0.1,
        max = 2.0,
        description = "Camera sensitivity",
    },
    ShowDamageNumbers = {
        default = true,
        type = "boolean",
        description = "Show floating damage numbers",
    },
    ShowPlayerNames = {
        default = true,
        type = "boolean",
        description = "Show other players' names above their heads",
    },
    ReducedEffects = {
        default = false,
        type = "boolean",
        description = "Reduce particle effects for better performance",
    },
    ChatFilter = {
        default = "Normal",
        type = "string",
        options = {"Strict", "Normal", "Minimal"},
        description = "Chat filtering level",
    },
}

-- ═════════════════════════════════════
-- PUBLIC API
-- ═════════════════════════════════════

-- Get default settings (for new players)
function SettingsManager:getDefaults()
    local defaults = {}
    for key, schema in pairs(SETTINGS_SCHEMA) do
        defaults[key] = schema.default
    end
    return defaults
end

-- Validate a single setting value
-- Returns: isValid (boolean), cleanValue (any), error (string?)
function SettingsManager:validate(settingName, value)
    local schema = SETTINGS_SCHEMA[settingName]
    if not schema then
        return false, nil, "Unknown setting: " .. settingName
    end
    
    -- Type check
    if type(value) ~= schema.type then
        return false, schema.default, "Expected " .. schema.type .. ", got " .. type(value)
    end
    
    -- Number range check
    if schema.type == "number" then
        if schema.min and value < schema.min then
            value = schema.min
        end
        if schema.max and value > schema.max then
            value = schema.max
        end
    end
    
    -- String options check
    if schema.type == "string" and schema.options then
        local valid = false
        for _, option in ipairs(schema.options) do
            if value == option then
                valid = true
                break
            end
        end
        if not valid then
            return false, schema.default, "Invalid option: " .. value
        end
    end
    
    return true, value, nil
end

-- Update a setting in player data (with validation)
-- Returns: success (boolean), message (string)
function SettingsManager:setSetting(playerData, settingName, value)
    local isValid, cleanValue, err = self:validate(settingName, value)
    
    if not isValid then
        return false, err
    end
    
    if not playerData.Settings then
        playerData.Settings = self:getDefaults()
    end
    
    playerData.Settings[settingName] = cleanValue
    return true, settingName .. " set to " .. tostring(cleanValue)
end

-- Get a setting value (with fallback to default)
function SettingsManager:getSetting(playerData, settingName)
    if playerData.Settings and playerData.Settings[settingName] ~= nil then
        return playerData.Settings[settingName]
    end
    
    local schema = SETTINGS_SCHEMA[settingName]
    return schema and schema.default
end

-- Get all settings info (for building the settings UI)
function SettingsManager:getSettingsInfo()
    local info = {}
    for key, schema in pairs(SETTINGS_SCHEMA) do
        table.insert(info, {
            key = key,
            type = schema.type,
            default = schema.default,
            min = schema.min,
            max = schema.max,
            options = schema.options,
            description = schema.description,
        })
    end
    
    -- Sort alphabetically for consistent UI ordering
    table.sort(info, function(a, b) return a.key < b.key end)
    
    return info
end

return SettingsManager


-- ╔═══════════════════════════════════════════════════════════╗
-- ║  HOW MODULES COMMUNICATE                                  ║
-- ║  (Avoiding circular dependencies)                         ║
-- ╚═══════════════════════════════════════════════════════════╝

--[[
    PROBLEM: CombatManager needs InventoryManager (to check equipped weapon).
    InventoryManager needs CombatManager (to calculate item stats).
    If they require() each other, you get an infinite loop!
    
    SOLUTION 1: One-way dependencies (preferred)
    
        Config ← InventoryManager ← CombatManager
                                   ← ShopManager
        
        CombatManager requires InventoryManager, not the other way around.
        If InventoryManager needs combat data, put it in Config.
    
    SOLUTION 2: Dependency injection
    
        -- In your main game script:
        local Combat = require(CombatManager)
        local Inventory = require(InventoryManager)
        
        -- Pass references to each other AFTER requiring
        Combat:init(Inventory)
        Inventory:init(Combat)
        
        -- Now they can use each other without circular requires
    
    SOLUTION 3: Event-based communication
    
        -- Create a shared event bus module
        local EventBus = {}
        local listeners = {}
        
        function EventBus:on(eventName, callback)
            if not listeners[eventName] then
                listeners[eventName] = {}
            end
            table.insert(listeners[eventName], callback)
        end
        
        function EventBus:emit(eventName, ...)
            if listeners[eventName] then
                for _, callback in ipairs(listeners[eventName]) do
                    task.spawn(callback, ...)
                end
            end
        end
        
        -- CombatManager:
        EventBus:emit("PlayerKilled", killer, victim)
        
        -- InventoryManager (no require of CombatManager needed):
        EventBus:on("PlayerKilled", function(killer, victim)
            dropItems(victim)
        end)
    
    RECOMMENDATION:
    Start with Solution 1 (one-way dependencies).
    Use Solution 3 (events) when modules truly need bidirectional communication.
    Solution 2 is a last resort — it's harder to reason about.
]]
