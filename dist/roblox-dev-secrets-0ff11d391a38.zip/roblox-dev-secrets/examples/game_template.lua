-- ═══════════════════════════════════════════════════════════════
-- ROBLOX GAME TEMPLATE — Complete Round-Based Game Structure
-- ═══════════════════════════════════════════════════════════════
--
-- This template gives you a complete game loop with:
--   • Player management (join/leave handling)
--   • Round system (lobby → countdown → playing → results)
--   • Leaderboard scoring
--   • Data persistence (saves between sessions)
--   • Clean state machine architecture
--
-- HOW TO USE:
--   1. Create a Script in ServerScriptService
--   2. Paste this code
--   3. Modify the CONFIG section for your game
--   4. Implement the TODO sections with your game logic
--   5. Create the required RemoteEvents in ReplicatedStorage
--
-- IMPORTANT: This is a SERVER script. It runs on Roblox's servers,
-- not on the player's computer. All game logic should be here.
-- ═══════════════════════════════════════════════════════════════

-- ┌─────────────────────────────────────┐
-- │           SERVICES                   │
-- └─────────────────────────────────────┘
-- Get services at the top — they're used throughout the script.
-- Always use GetService() instead of game.ServiceName for reliability.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local DataStoreService = game:GetService("DataStoreService")
local TweenService = game:GetService("TweenService")

-- ┌─────────────────────────────────────┐
-- │         CONFIGURATION                │
-- └─────────────────────────────────────┘
-- Change these values to customize your game.
-- All balance numbers in ONE place — easy to tune!

local CONFIG = {
    -- Game settings
    GAME_NAME = "My Awesome Game",     -- Your game's name
    MIN_PLAYERS = 2,                    -- Minimum players to start a round
    MAX_ROUNDS = 10,                    -- Rounds per match (0 = infinite)
    ROUND_DURATION = 120,               -- Seconds per round
    INTERMISSION_DURATION = 15,         -- Seconds between rounds
    COUNTDOWN_DURATION = 5,             -- Countdown before round starts
    
    -- Scoring
    KILL_POINTS = 100,                  -- Points per elimination
    ASSIST_POINTS = 50,                 -- Points per assist
    WIN_BONUS = 500,                    -- Bonus points for winning
    SURVIVAL_POINTS_PER_SEC = 1,        -- Points per second survived
    
    -- Data persistence
    DATA_STORE_NAME = "GameData_v1",    -- Version your data store!
    AUTO_SAVE_INTERVAL = 300,           -- Auto-save every 5 minutes
    
    -- Spawn locations
    LOBBY_SPAWN = Vector3.new(0, 10, 0),     -- Where players wait
    ARENA_SPAWNS = {                          -- Where players fight
        Vector3.new(50, 10, 0),
        Vector3.new(-50, 10, 0),
        Vector3.new(0, 10, 50),
        Vector3.new(0, 10, -50),
    },
}

-- ┌─────────────────────────────────────┐
-- │         GAME STATE                   │
-- └─────────────────────────────────────┘
-- The state machine that controls the entire game flow.
-- WHY a state machine? Because if/elseif chains for game flow
-- become impossible to debug. States make the flow EXPLICIT.

local GameState = {
    WAITING = "Waiting",       -- Not enough players
    INTERMISSION = "Intermission", -- Between rounds
    COUNTDOWN = "Countdown",   -- About to start
    PLAYING = "Playing",       -- Round in progress
    ROUND_END = "RoundEnd",    -- Showing results
}

local currentState = GameState.WAITING
local currentRound = 0
local roundTimer = 0
local activePlayers = {}  -- Players currently in the round

-- ┌─────────────────────────────────────┐
-- │       DATA PERSISTENCE               │
-- └─────────────────────────────────────┘
-- Saves player progress between game sessions.
-- Uses an in-memory cache to avoid hitting DataStore rate limits.

local dataStore = DataStoreService:GetDataStore(CONFIG.DATA_STORE_NAME)

-- Default data for new players — modify this for YOUR game
local DEFAULT_DATA = {
    Wins = 0,
    Kills = 0,
    Deaths = 0,
    TotalScore = 0,
    GamesPlayed = 0,
    Level = 1,
    XP = 0,
    Coins = 100,              -- Starting currency
    Inventory = {},            -- Owned items
    DataVersion = 1,           -- For future data migrations
}

-- In-memory cache (fast reads, no rate limit concerns)
local playerDataCache = {}

-- Load player data from DataStore
local function loadData(player)
    local key = "Player_" .. player.UserId
    
    local success, data = pcall(function()
        return dataStore:GetAsync(key)
    end)
    
    if success and data then
        -- Merge with defaults to handle new fields added in updates
        for field, default in pairs(DEFAULT_DATA) do
            if data[field] == nil then
                data[field] = default
            end
        end
        playerDataCache[player.UserId] = data
        print("[DATA] Loaded data for " .. player.Name)
    elseif success then
        -- New player
        playerDataCache[player.UserId] = table.clone(DEFAULT_DATA)
        print("[DATA] New player: " .. player.Name)
    else
        -- DataStore failed — use defaults but flag it
        warn("[DATA] Failed to load for " .. player.Name .. ": " .. tostring(data))
        local fallback = table.clone(DEFAULT_DATA)
        fallback._loadFailed = true
        playerDataCache[player.UserId] = fallback
    end
end

-- Save player data to DataStore
local function saveData(player)
    local data = playerDataCache[player.UserId]
    if not data then return end
    
    -- CRITICAL: Don't overwrite real data with defaults if load failed
    if data._loadFailed then
        warn("[DATA] Skipping save for " .. player.Name .. " (load failed)")
        return
    end
    
    local key = "Player_" .. player.UserId
    
    local success, err = pcall(function()
        dataStore:SetAsync(key, data)
    end)
    
    if success then
        print("[DATA] Saved data for " .. player.Name)
    else
        warn("[DATA] Save failed for " .. player.Name .. ": " .. err)
    end
end

-- Get a player's cached data (fast, no DataStore call)
local function getData(player)
    return playerDataCache[player.UserId]
end

-- ┌─────────────────────────────────────┐
-- │        LEADERBOARD                   │
-- └─────────────────────────────────────┘
-- Creates the in-game leaderboard (top-right of screen)

local function setupLeaderstats(player)
    local data = getData(player)
    if not data then return end
    
    -- "leaderstats" is a magic name — Roblox shows it as the leaderboard
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player
    
    -- Add columns (customize these for your game!)
    local wins = Instance.new("IntValue")
    wins.Name = "Wins"
    wins.Value = data.Wins
    wins.Parent = leaderstats
    
    local kills = Instance.new("IntValue")
    kills.Name = "Kills"
    kills.Value = data.Kills
    kills.Parent = leaderstats
    
    local score = Instance.new("IntValue")
    score.Name = "Score"
    score.Value = 0  -- Reset each game
    score.Parent = leaderstats
end

-- Update a leaderstat value
local function updateStat(player, statName, value)
    local leaderstats = player:FindFirstChild("leaderstats")
    if leaderstats then
        local stat = leaderstats:FindFirstChild(statName)
        if stat then
            stat.Value = value
        end
    end
end

-- Add to a leaderstat value
local function addToStat(player, statName, amount)
    local leaderstats = player:FindFirstChild("leaderstats")
    if leaderstats then
        local stat = leaderstats:FindFirstChild(statName)
        if stat then
            stat.Value = stat.Value + amount
        end
    end
end

-- ┌─────────────────────────────────────┐
-- │       PLAYER MANAGEMENT              │
-- └─────────────────────────────────────┘

-- Teleport a player to a position
local function teleportPlayer(player, position)
    local character = player.Character
    if character then
        local root = character:FindFirstChild("HumanoidRootPart")
        if root then
            root.CFrame = CFrame.new(position)
        end
    end
end

-- Give a player their tools/weapons for the round
local function equipPlayer(player)
    -- TODO: Customize this for your game!
    -- Example: Give a starter sword from ServerStorage
    --[[
    local sword = ServerStorage.Tools.StarterSword:Clone()
    sword.Parent = player.Backpack
    ]]
end

-- Reset a player for a new round
local function resetPlayer(player)
    local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
    if humanoid then
        humanoid.Health = humanoid.MaxHealth
    end
end

-- ┌─────────────────────────────────────┐
-- │         ROUND SYSTEM                 │
-- └─────────────────────────────────────┘
-- The core game loop. Each function handles one state transition.

-- Broadcast a message to all players
-- TODO: Replace this with your UI system (RemoteEvent to clients)
local function announce(message)
    print("[GAME] " .. message)
    -- In a real game, fire a RemoteEvent to update client UI:
    -- ReplicatedStorage.RemoteEvents.Announcement:FireAllClients(message)
end

-- Get all players who are alive and in the round
local function getAlivePlayers()
    local alive = {}
    for _, player in ipairs(activePlayers) do
        if player.Parent == Players then  -- Still in the game
            local humanoid = player.Character 
                and player.Character:FindFirstChildOfClass("Humanoid")
            if humanoid and humanoid.Health > 0 then
                table.insert(alive, player)
            end
        end
    end
    return alive
end

-- STATE: Waiting for enough players
local function waitingState()
    currentState = GameState.WAITING
    announce("Waiting for " .. CONFIG.MIN_PLAYERS .. " players...")
    
    -- Wait until we have enough players
    while #Players:GetPlayers() < CONFIG.MIN_PLAYERS do
        announce(#Players:GetPlayers() .. "/" .. CONFIG.MIN_PLAYERS .. " players")
        task.wait(5)
    end
    
    -- Enough players — start intermission
    intermissionState()
end

-- STATE: Intermission between rounds
function intermissionState()
    currentState = GameState.INTERMISSION
    
    -- Teleport everyone to lobby
    for _, player in ipairs(Players:GetPlayers()) do
        teleportPlayer(player, CONFIG.LOBBY_SPAWN)
    end
    
    -- Countdown intermission
    for i = CONFIG.INTERMISSION_DURATION, 1, -1 do
        announce("Next round in " .. i .. " seconds")
        task.wait(1)
        
        -- Check if players left during intermission
        if #Players:GetPlayers() < CONFIG.MIN_PLAYERS then
            announce("Not enough players!")
            waitingState()
            return
        end
    end
    
    countdownState()
end

-- STATE: Countdown before round starts
function countdownState()
    currentState = GameState.COUNTDOWN
    currentRound = currentRound + 1
    
    announce("Round " .. currentRound .. " starting!")
    
    for i = CONFIG.COUNTDOWN_DURATION, 1, -1 do
        announce(i .. "...")
        task.wait(1)
    end
    
    playingState()
end

-- STATE: Round in progress
function playingState()
    currentState = GameState.PLAYING
    announce("GO! Round " .. currentRound .. " has begun!")
    
    -- Set up active players (everyone currently in the game)
    activePlayers = {}
    for i, player in ipairs(Players:GetPlayers()) do
        table.insert(activePlayers, player)
        
        -- Teleport to arena spawn (cycle through spawn points)
        local spawnIndex = ((i - 1) % #CONFIG.ARENA_SPAWNS) + 1
        teleportPlayer(player, CONFIG.ARENA_SPAWNS[spawnIndex])
        
        -- Give them their equipment
        resetPlayer(player)
        equipPlayer(player)
        
        -- Reset round score
        updateStat(player, "Score", 0)
    end
    
    -- Round timer
    roundTimer = CONFIG.ROUND_DURATION
    
    while roundTimer > 0 and currentState == GameState.PLAYING do
        task.wait(1)
        roundTimer = roundTimer - 1
        
        -- Award survival points
        for _, player in ipairs(getAlivePlayers()) do
            addToStat(player, "Score", CONFIG.SURVIVAL_POINTS_PER_SEC)
        end
        
        -- Check win condition
        local alive = getAlivePlayers()
        if #alive <= 1 then
            -- Round over — someone won (or everyone died)
            break
        end
        
        -- Announce time remaining at intervals
        if roundTimer == 60 then
            announce("60 seconds remaining!")
        elseif roundTimer == 30 then
            announce("30 seconds!")
        elseif roundTimer == 10 then
            announce("10 seconds!")
        end
    end
    
    roundEndState()
end

-- STATE: Round ended, show results
function roundEndState()
    currentState = GameState.ROUND_END
    
    -- Determine winner (highest score)
    local winner = nil
    local highestScore = 0
    
    for _, player in ipairs(activePlayers) do
        if player.Parent == Players then
            local stats = player:FindFirstChild("leaderstats")
            if stats then
                local score = stats:FindFirstChild("Score")
                if score and score.Value > highestScore then
                    highestScore = score.Value
                    winner = player
                end
            end
        end
    end
    
    if winner then
        announce(winner.Name .. " wins Round " .. currentRound .. " with " .. highestScore .. " points!")
        
        -- Award win bonus
        addToStat(winner, "Score", CONFIG.WIN_BONUS)
        
        -- Update persistent data
        local data = getData(winner)
        if data then
            data.Wins = data.Wins + 1
            updateStat(winner, "Wins", data.Wins)
        end
    else
        announce("Round " .. currentRound .. " ended — no winner!")
    end
    
    -- Update games played for all participants
    for _, player in ipairs(activePlayers) do
        if player.Parent == Players then
            local data = getData(player)
            if data then
                data.GamesPlayed = data.GamesPlayed + 1
            end
        end
    end
    
    -- Show results for a few seconds
    task.wait(5)
    
    -- Check if we've reached max rounds
    if CONFIG.MAX_ROUNDS > 0 and currentRound >= CONFIG.MAX_ROUNDS then
        announce("Match complete! Starting new match...")
        currentRound = 0
    end
    
    -- Check player count
    if #Players:GetPlayers() >= CONFIG.MIN_PLAYERS then
        intermissionState()
    else
        waitingState()
    end
end

-- ┌─────────────────────────────────────┐
-- │     PLAYER EVENTS (Join/Leave)       │
-- └─────────────────────────────────────┘

Players.PlayerAdded:Connect(function(player)
    print("[GAME] " .. player.Name .. " joined")
    
    -- Load their saved data
    loadData(player)
    
    -- Set up leaderboard
    setupLeaderstats(player)
    
    -- Handle character spawning
    player.CharacterAdded:Connect(function(character)
        -- Wait for humanoid to load
        local humanoid = character:WaitForChild("Humanoid")
        
        -- Handle death
        humanoid.Died:Connect(function()
            local data = getData(player)
            if data then
                data.Deaths = data.Deaths + 1
            end
            
            -- TODO: Find the killer and award kill points
            -- This depends on your combat system
            
            -- Auto-respawn after delay (if in a round)
            if currentState == GameState.PLAYING then
                task.wait(CONFIG.RESPAWN_TIME or 5)
                -- player:LoadCharacter()  -- Uncomment for respawn
            end
        end)
        
        -- Teleport to lobby if not in a round
        if currentState ~= GameState.PLAYING then
            teleportPlayer(player, CONFIG.LOBBY_SPAWN)
        end
    end)
end)

Players.PlayerRemoving:Connect(function(player)
    print("[GAME] " .. player.Name .. " left")
    
    -- Save their data
    saveData(player)
    
    -- Clean up cache
    playerDataCache[player.UserId] = nil
    
    -- Remove from active players
    local index = table.find(activePlayers, player)
    if index then
        table.remove(activePlayers, index)
    end
end)

-- ┌─────────────────────────────────────┐
-- │        SERVER SHUTDOWN                │
-- └─────────────────────────────────────┘
-- Save ALL player data when the server shuts down.
-- BindToClose gives us ~30 seconds to save everything.

game:BindToClose(function()
    print("[GAME] Server shutting down — saving all data...")
    
    for _, player in ipairs(Players:GetPlayers()) do
        saveData(player)
    end
    
    print("[GAME] All data saved!")
end)

-- ┌─────────────────────────────────────┐
-- │         AUTO-SAVE LOOP               │
-- └─────────────────────────────────────┘
-- Safety net: saves all player data periodically

task.spawn(function()
    while true do
        task.wait(CONFIG.AUTO_SAVE_INTERVAL)
        
        for _, player in ipairs(Players:GetPlayers()) do
            saveData(player)
            task.wait(1)  -- Stagger saves to avoid rate limits
        end
    end
end)

-- ┌─────────────────────────────────────┐
-- │       START THE GAME LOOP            │
-- └─────────────────────────────────────┘

print("[GAME] " .. CONFIG.GAME_NAME .. " server started!")
waitingState()  -- Begin the game loop!
