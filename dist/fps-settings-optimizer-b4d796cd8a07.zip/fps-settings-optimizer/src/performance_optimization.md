# Performance Optimization — Squeeze Every Frame Out of Your System

> OS tweaks, GPU driver settings, and network optimization for competitive FPS. No snake oil, just stuff that actually works.

## Table of Contents
1. [Windows Optimization](#windows-optimization)
2. [NVIDIA GPU Settings](#nvidia-gpu-settings)
3. [AMD GPU Settings](#amd-gpu-settings)
4. [Network Optimization](#network-optimization)
5. [Hardware Priorities](#hardware-priorities)
6. [Monitoring Your Performance](#monitoring-your-performance)

---

## Windows Optimization

### Essential Windows Settings

| Setting | Location | Value | FPS Impact |
|---------|----------|-------|------------|
| Game Mode | Settings → Gaming → Game Mode | ON | +2-5% |
| Hardware-accelerated GPU Scheduling | Settings → Display → Graphics | ON | +1-3% |
| Mouse Acceleration | Control Panel → Mouse → Pointer Options | OFF (uncheck "Enhance pointer precision") | Aim consistency |
| Power Plan | Control Panel → Power Options | High Performance / Ultimate Performance | +5-15% |
| Visual Effects | System → Advanced → Performance | "Adjust for best performance" | +1-3% |
| Background Apps | Settings → Apps → Startup | Disable non-essentials | +5-10% |
| Fullscreen Optimizations | Game .exe → Properties → Compatibility | Disable | Reduces input lag |

### Power Plan Setup

```
HOW TO ENABLE ULTIMATE PERFORMANCE (Windows 10/11):

  1. Open Command Prompt as Admin
  2. Run: powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61
  3. Go to Control Panel → Power Options
  4. Select "Ultimate Performance"
  
  WHAT IT DOES:
  - Prevents CPU from downclocking during gameplay
  - Keeps GPU at higher performance states
  - Disables USB selective suspend (no mouse disconnects)
  
  DOWNSIDE: Higher power usage and heat. Fine for desktops.
  For laptops: use "High Performance" while plugged in only.
```

### Disable Unnecessary Services

```
SERVICES TO DISABLE (services.msc):

  SysMain (Superfetch):     Preloads apps into RAM — useless for gaming
  Windows Search Indexer:   Background disk activity during games
  Diagnostic Tracking:      Telemetry — uses CPU/disk in background
  Connected User Experiences: More telemetry
  
  HOW:
  1. Win+R → services.msc
  2. Find the service → Right-click → Properties
  3. Set Startup Type to "Disabled"
  4. Click "Stop" if currently running
  
  CAUTION: Only disable these if you're on a dedicated gaming PC.
  On your work/school PC, leave them alone.
```

### Close Background Apps Before Gaming

```
THE USUAL SUSPECTS (check Task Manager):

  Discord:        Can use 5-15% CPU with screen share
                  FIX: Disable hardware acceleration in Discord settings
                  
  Browser (Chrome): Each tab = a separate process eating RAM
                    FIX: Close ALL browser tabs. Seriously.
                    
  Antivirus:      Real-time scanning during game file access
                  FIX: Add game folder to exclusion list
                  
  Windows Update: Downloads in background, causes latency spikes
                  FIX: Pause updates during gaming sessions
                  
  RGB Software:   iCUE, Synapse, etc. — constant CPU polling
                  FIX: Set up your RGB, then close the app
                  
  OBS/Recording:  Uses GPU encoder, steals frames
                  FIX: Use NVENC (GPU encoding) not x264 (CPU)
```

---

## NVIDIA GPU Settings

### NVIDIA Control Panel (Right-click Desktop → NVIDIA Control Panel)

**Manage 3D Settings → Global or Per-Program:**

| Setting | Value | Why |
|---------|-------|-----|
| Power Management Mode | Prefer Maximum Performance | Prevents GPU downclocking mid-game |
| Low Latency Mode | Ultra | Reduces render queue to 1 frame |
| Texture Filtering Quality | High Performance | Slight quality loss, FPS gain |
| Texture Filtering - Anisotropic | Application-controlled | Let the game decide |
| Vertical Sync | Off | Always off for competitive |
| Max Pre-Rendered Frames | 1 | Reduces input lag |
| Threaded Optimization | On | Uses multiple CPU cores for driver |
| Shader Cache | On | Reduces shader compilation stutters |
| Triple Buffering | Off | Only useful with V-Sync (which is off) |
| Image Sharpening | Optional (50-70%) | Can improve clarity at low settings |

### NVIDIA Reflex

```
WHAT IT IS:
  NVIDIA Reflex reduces the render queue between CPU and GPU.
  This directly reduces input lag — the time between your mouse
  click and the action appearing on screen.
  
SUPPORTED GAMES:
  ✓ Valorant       ✓ Fortnite
  ✓ Apex Legends   ✓ Overwatch 2
  ✓ CS2            ✓ Call of Duty
  
SETTINGS:
  Off:              No Reflex (baseline)
  On:               Reduces latency by aligning CPU/GPU work
  On + Boost:       Also prevents GPU from downclocking
  
ALWAYS USE: On + Boost (if available in your game)
  
REAL-WORLD IMPACT:
  Without Reflex:  ~30-50ms total system latency
  With Reflex:     ~15-25ms total system latency
  That's 15-25ms faster. Enough to win close fights.
```

### NVIDIA GeForce Experience

```
RECOMMENDED:
  - Disable "In-Game Overlay" (uses GPU resources)
  - Disable "Instant Replay" unless you need it (constant recording)
  - Disable "Auto-Optimize" (its settings are trash)
  
KEEP:
  - Driver update notifications
  - ShadowPlay for manual clip capture (low overhead when not recording)
```

---

## AMD GPU Settings

### AMD Radeon Software (Right-click Desktop → AMD Software)

**Gaming → Graphics:**

| Setting | Value | Why |
|---------|-------|-----|
| Radeon Anti-Lag | Enabled | AMD's equivalent to NVIDIA Reflex |
| Radeon Boost | Enabled | Drops resolution during fast movement |
| Radeon Image Sharpening | Enabled (70-80%) | Compensates for low settings |
| Wait for Vertical Refresh | Always Off | V-Sync off globally |
| Frame Rate Target Control | Monitor refresh + 3 | Prevents unnecessary GPU heat |
| Anti-Aliasing | Use application settings | Let the game decide |
| Texture Filtering Quality | Performance | Minor visual loss |
| Surface Format Optimization | Enabled | Free optimization |
| Tessellation Mode | Override - Off | Slight FPS boost |

### AMD Anti-Lag vs NVIDIA Reflex

```
FEATURE COMPARISON:

  Feature          NVIDIA Reflex    AMD Anti-Lag
  ──────────────────────────────────────────────
  Input lag        ~15-25ms         ~20-30ms
  Game support     Wide             Growing
  Implementation   Per-game SDK     Driver-level
  Boost mode       Yes              No
  
  Both help. Use whichever your GPU supports.
```

---

## Network Optimization

### For Online FPS, Latency Is King

```
NETWORK PRIORITIES FOR COMPETITIVE FPS:

  1. PING (latency)       — Lower is better. Target: <30ms
  2. JITTER (consistency) — Lower is better. Target: <5ms variance
  3. PACKET LOSS          — 0% is the goal. Any loss = rubber-banding
  4. BANDWIDTH            — Barely matters. FPS games use <1 Mbps
  
  TRANSLATION:
  - A 500 Mbps connection with 80ms ping is WORSE than
    a 50 Mbps connection with 15ms ping for gaming.
  - Bandwidth ≠ speed for gaming. Latency is speed.
```

### Wired vs Wireless

```
ALWAYS USE WIRED ETHERNET FOR COMPETITIVE PLAY.

  Connection      Avg Ping Addition   Jitter
  ────────────────────────────────────────────
  Wired (Cat6)    +0ms               <1ms
  WiFi 6E         +1-5ms             2-10ms
  WiFi 5          +2-15ms            5-30ms
  WiFi 4          +5-30ms            10-50ms+
  
  Even good WiFi adds 2-5ms of jitter.
  In a game where 1 frame = 4ms (at 240 FPS),
  WiFi jitter can cost you multiple frames of responsiveness.
```

### DNS Optimization

```
FASTER DNS = FASTER INITIAL CONNECTIONS:

  Switch to a faster DNS server:
  
  Cloudflare:  1.1.1.1 / 1.0.0.1
  Google:      8.8.8.8 / 8.8.4.4
  
  HOW (Windows):
  1. Settings → Network & Internet → Your Connection → Properties
  2. Edit DNS server assignment
  3. Set to Manual → IPv4
  4. Preferred: 1.1.1.1
  5. Alternate: 1.0.0.1
  
  IMPACT: Faster server connections, not in-game ping.
  But it helps with queue times and initial matchmaking.
```

### Router Settings for Gaming

```
ROUTER OPTIMIZATIONS:

  1. QoS (Quality of Service):
     If your router supports it, prioritize gaming traffic.
     Set your PC's IP to highest priority.
     
  2. Port Forwarding:
     Each game has specific ports. Forward them for NAT Type Open.
     
     Valorant:       8393-8400 TCP
     Apex Legends:   1024-1124 UDP, 3216 UDP, 9960-9969 UDP
     Fortnite:       5222, 5795-5847 TCP/UDP
     CS2:            27015-27050 UDP
     Overwatch 2:    1119 UDP, 3478-3479 UDP, 5060-5062 UDP
     
  3. UPnP:
     Enable UPnP as a fallback if you don't want to port forward.
     Less secure but easier.
```

### Reduce Bufferbloat

```
WHAT IS BUFFERBLOAT?
  When your network is under load (someone streaming, downloading),
  packets queue up in your router's buffer. This adds latency spikes.
  
TEST IT:
  Go to https://www.waveform.com/tools/bufferbloat
  Run the test. Grade A = good. Grade C/D/F = problem.
  
FIX IT:
  1. Enable SQM/fq_codel on your router (if supported)
  2. Limit bandwidth to 85% of your connection speed
  3. Or: use a gaming router with built-in traffic management
```

---

## Hardware Priorities

### What to Upgrade First (for FPS)

```
UPGRADE PRIORITY FOR GAMING PERFORMANCE:

  1. GPU (Graphics Card)      — Biggest FPS impact by far
  2. Monitor (Refresh Rate)   — 144Hz minimum for competitive
  3. CPU                      — Matters for CPU-bound games (Fortnite, CS2)
  4. RAM (16GB minimum)       — Below 16GB causes stutters
  5. SSD                      — Faster load times, less texture pop-in
  6. Mouse (sensor quality)   — Good sensor = no spinouts or jitter
  7. Mousepad                 — Consistent surface for aim
  
  DON'T WASTE MONEY ON:
  × RGB anything (0 FPS gain)
  × "Gaming" ethernet cables
  × RAM faster than 3600 MHz (diminishing returns)
  × 4K monitor for competitive FPS (1080p is better)
```

### Monitor Settings

```
MONITOR CHECKLIST:

  [ ] Set refresh rate to maximum (Windows Display Settings)
  [ ] Response time = fastest mode (check monitor OSD)
  [ ] Game mode / Low input lag mode = ON
  [ ] Overdrive = Medium/Normal (not max, causes inverse ghosting)
  [ ] Black stabilizer / dark boost = personal preference
  [ ] Disable unnecessary post-processing (motion blur, dynamic contrast)
```

---

## Monitoring Your Performance

### Tools for Tracking FPS and System Health

```
FREE MONITORING TOOLS:

  MSI Afterburner + RTSS:
    - On-screen FPS, frame time, GPU/CPU usage and temps
    - The gold standard for performance monitoring
    - Set up: Afterburner → Settings → Monitoring → Check items → Show in OSD
    
  Task Manager (Ctrl+Shift+Esc):
    - Quick check for CPU/RAM/Disk/GPU usage
    - Performance tab → GPU for GPU usage %
    
  CapFrameX:
    - Detailed frame time analysis
    - 1% and 0.1% low FPS (more important than average FPS)
    - Export benchmarks for before/after comparisons
```

### What to Monitor

```
KEY METRICS:

  Average FPS:       Your baseline. Should be stable above monitor refresh.
  1% Low FPS:        Your worst 1% of frames. If this drops below 60, you'll
                     feel stutters even if average is 200+.
  GPU Usage:         Should be 95-99% (GPU-bound = good)
  CPU Usage:         If 100%, you're CPU-bottlenecked
  GPU Temperature:   Keep below 85°C. Throttling starts at 85-90°C.
  CPU Temperature:   Keep below 90°C.
  Frame Time:        Should be consistent. Spikes = stutters.
  
  THE REAL METRIC:
  Frame time consistency matters more than raw FPS.
  Locked 144 FPS with stable frame times FEELS smoother than
  fluctuating 200-300 FPS with random spikes.
```

---

*A well-optimized system gives you a real competitive edge. Do this once, verify it works, and get back to gaming.*
