#!/usr/bin/env python3
"""
FPS Sensitivity Converter — Cross-Game Sensitivity Tool

Converts mouse sensitivity between Valorant, Apex Legends, Fortnite,
CS2, and Overwatch 2. Also calculates eDPI, cm/360, and recommends
a starting sensitivity based on your playstyle and hardware.

Usage:
    python3 sensitivity_converter.py

No external dependencies required — stdlib only.

Author: Game Vault
License: MIT
"""

import json
import math
import os
import sys
from typing import Optional


# =============================================================================
# CONSTANTS — Game sensitivity coefficients
# =============================================================================

# Yaw values: degrees of rotation per mouse count at sensitivity 1.0
# These are the engine-specific constants that define how each game
# translates raw mouse input into in-game rotation.
GAME_YAW: dict[str, float] = {
    "valorant": 0.07,
    "apex_legends": 0.022,
    "fortnite": 0.5585,
    "cs2": 0.022,
    "overwatch_2": 0.0066,
}

GAME_DISPLAY_NAMES: dict[str, str] = {
    "valorant": "Valorant",
    "apex_legends": "Apex Legends",
    "fortnite": "Fortnite",
    "cs2": "CS2",
    "overwatch_2": "Overwatch 2",
}

# Default FOV per game (horizontal, 16:9)
GAME_FOV: dict[str, float] = {
    "valorant": 103.0,
    "apex_legends": 110.0,
    "fortnite": 80.0,
    "cs2": 106.26,
    "overwatch_2": 103.0,
}

# Sensitivity recommendations by playstyle (cm/360 ranges)
PLAYSTYLE_RANGES: dict[str, tuple[float, float, str]] = {
    "aggressive": (20.0, 35.0, "Fast flicks, entry fragging, close-range dominance"),
    "balanced": (30.0, 50.0, "Versatile, works for any role"),
    "precision": (40.0, 65.0, "Long-range tracking, holding angles, sniping"),
    "controller_convert": (15.0, 30.0, "Coming from controller, used to fast turning"),
}


# =============================================================================
# CORE MATH
# =============================================================================

def calc_cm360(dpi: int, sensitivity: float, game: str) -> float:
    """Calculate cm/360 — centimeters of mouse movement for a full 360-degree turn.

    Args:
        dpi: Mouse DPI setting.
        sensitivity: In-game sensitivity value.
        game: Game key (must exist in GAME_YAW).

    Returns:
        cm/360 value.

    Raises:
        ValueError: If game is not supported.
    """
    if game not in GAME_YAW:
        raise ValueError(f"Unsupported game: {game}. Options: {list(GAME_YAW.keys())}")

    yaw = GAME_YAW[game]
    deg_per_count = yaw * sensitivity
    counts_per_360 = 360.0 / deg_per_count
    inches_per_360 = counts_per_360 / dpi
    return inches_per_360 * 2.54


def cm360_to_sens(cm360: float, dpi: int, game: str) -> float:
    """Convert a cm/360 value to in-game sensitivity for a specific game.

    Args:
        cm360: Target centimeters per 360-degree rotation.
        dpi: Mouse DPI.
        game: Target game key.

    Returns:
        In-game sensitivity value.
    """
    if game not in GAME_YAW:
        raise ValueError(f"Unsupported game: {game}. Options: {list(GAME_YAW.keys())}")

    yaw = GAME_YAW[game]
    inches_per_360 = cm360 / 2.54
    counts_per_360 = inches_per_360 * dpi
    deg_per_count = 360.0 / counts_per_360
    return deg_per_count / yaw


def calc_edpi(dpi: int, sensitivity: float) -> float:
    """Calculate eDPI (effective DPI) = DPI * in-game sensitivity.

    Only meaningful for comparisons within the same game.

    Args:
        dpi: Mouse DPI.
        sensitivity: In-game sensitivity.

    Returns:
        eDPI value.
    """
    return dpi * sensitivity


def convert_sensitivity(
    source_game: str,
    source_sens: float,
    target_game: str,
    dpi: int,
) -> dict:
    """Convert sensitivity from one game to another via cm/360.

    The resulting sensitivity in the target game will produce the same
    physical mouse movement for the same in-game rotation.

    Args:
        source_game: Game you're converting from.
        source_sens: Sensitivity in the source game.
        target_game: Game you're converting to.
        dpi: Mouse DPI (assumed same for both).

    Returns:
        Dict with conversion results.
    """
    cm360 = calc_cm360(dpi, source_sens, source_game)
    target_sens = cm360_to_sens(cm360, dpi, target_game)

    return {
        "source_game": GAME_DISPLAY_NAMES[source_game],
        "source_sensitivity": source_sens,
        "target_game": GAME_DISPLAY_NAMES[target_game],
        "target_sensitivity": round(target_sens, 4),
        "cm_per_360": round(cm360, 1),
        "dpi": dpi,
        "source_edpi": round(calc_edpi(dpi, source_sens), 1),
        "target_edpi": round(calc_edpi(dpi, target_sens), 1),
    }


def recommend_sensitivity(
    playstyle: str,
    mousepad_width_cm: float,
    dpi: int,
    game: str,
) -> dict:
    """Recommend a sensitivity based on playstyle, mousepad, and hardware.

    Args:
        playstyle: One of 'aggressive', 'balanced', 'precision', 'controller_convert'.
        mousepad_width_cm: Mousepad width in centimeters.
        dpi: Mouse DPI.
        game: Target game key.

    Returns:
        Dict with recommended sensitivity and metadata.
    """
    if playstyle not in PLAYSTYLE_RANGES:
        raise ValueError(f"Unknown playstyle: {playstyle}")

    low_cm, high_cm, desc = PLAYSTYLE_RANGES[playstyle]
    mid_cm = (low_cm + high_cm) / 2.0

    # Mousepad constraint: you need at least a 180 per full swipe
    min_viable = mousepad_width_cm * 2.0
    constrained = False
    if mid_cm > min_viable:
        mid_cm = min_viable
        low_cm = min(low_cm, min_viable)
        high_cm = min(high_cm, min_viable)
        constrained = True

    sens_rec = cm360_to_sens(mid_cm, dpi, game)
    sens_low = cm360_to_sens(high_cm, dpi, game)  # higher cm = lower sens
    sens_high = cm360_to_sens(low_cm, dpi, game)

    return {
        "game": GAME_DISPLAY_NAMES[game],
        "playstyle": playstyle,
        "playstyle_description": desc,
        "recommended_sensitivity": round(sens_rec, 4),
        "range_low": round(sens_low, 4),
        "range_high": round(sens_high, 4),
        "cm_per_360": round(mid_cm, 1),
        "edpi": round(calc_edpi(dpi, sens_rec), 1),
        "mousepad_constrained": constrained,
    }


# =============================================================================
# CLI HELPERS
# =============================================================================

def print_header(text: str) -> None:
    """Print a formatted section header."""
    width = 60
    print(f"\n{'=' * width}")
    print(f"  {text}")
    print(f"{'=' * width}\n")


def print_divider() -> None:
    print(f"  {'-' * 50}")


def get_int(prompt: str, lo: int = 1, hi: int = 99999) -> int:
    """Get validated integer input."""
    while True:
        try:
            val = int(input(prompt))
            if lo <= val <= hi:
                return val
            print(f"  Enter a value between {lo} and {hi}.")
        except ValueError:
            print("  Enter a valid number.")


def get_float(prompt: str, lo: float = 0.001, hi: float = 1000.0) -> float:
    """Get validated float input."""
    while True:
        try:
            val = float(input(prompt))
            if lo <= val <= hi:
                return val
            print(f"  Enter a value between {lo} and {hi}.")
        except ValueError:
            print("  Enter a valid number.")


def choose(prompt: str, options: list[str], labels: Optional[list[str]] = None) -> str:
    """Present numbered options and return the selected key."""
    display = labels if labels else options
    print(prompt)
    for i, label in enumerate(display, 1):
        print(f"  {i}. {label}")
    while True:
        try:
            idx = int(input("\n  Your choice: "))
            if 1 <= idx <= len(options):
                return options[idx - 1]
            print(f"  Enter 1-{len(options)}.")
        except ValueError:
            print("  Enter a valid number.")


def choose_game(prompt: str = "  Which game?") -> str:
    """Prompt user to select a game."""
    keys = list(GAME_YAW.keys())
    labels = [GAME_DISPLAY_NAMES[k] for k in keys]
    return choose(prompt, keys, labels)


# =============================================================================
# INTERACTIVE MODES
# =============================================================================

def mode_convert() -> None:
    """Convert sensitivity between two games."""
    print_header("SENSITIVITY CONVERTER")
    print("  Keep your muscle memory when switching games.\n")

    src = choose_game("  Convert FROM:")
    src_sens = get_float(f"\n  Your {GAME_DISPLAY_NAMES[src]} sensitivity: ")

    tgt = choose_game("\n  Convert TO:")
    dpi = get_int("\n  Your mouse DPI: ", 100, 16000)

    result = convert_sensitivity(src, src_sens, tgt, dpi)

    print_header("RESULT")
    print(f"  {result['source_game']}: {result['source_sensitivity']}")
    print(f"  -> {result['target_game']}: {result['target_sensitivity']}")
    print()
    print(f"  cm/360:      {result['cm_per_360']} cm (identical in both games)")
    print(f"  Source eDPI:  {result['source_edpi']}")
    print(f"  Target eDPI:  {result['target_edpi']}")
    print(f"  DPI:          {result['dpi']}")


def mode_edpi() -> None:
    """Calculate eDPI and cm/360 for current settings."""
    print_header("eDPI & cm/360 CALCULATOR")
    print("  Analyze your current sensitivity.\n")

    game = choose_game()
    sens = get_float(f"\n  Your {GAME_DISPLAY_NAMES[game]} sensitivity: ")
    dpi = get_int("\n  Your mouse DPI: ", 100, 16000)

    cm360 = calc_cm360(dpi, sens, game)
    edpi = calc_edpi(dpi, sens)

    print_header("YOUR SENSITIVITY BREAKDOWN")
    print(f"  Game:      {GAME_DISPLAY_NAMES[game]}")
    print(f"  Sens:      {sens}")
    print(f"  DPI:       {dpi}")
    print(f"  eDPI:      {round(edpi, 1)}")
    print(f"  cm/360:    {round(cm360, 1)} cm")

    # Categorize
    if cm360 < 20:
        cat = "VERY HIGH (mostly wrist, twitchy)"
    elif cm360 < 35:
        cat = "HIGH (wrist + some arm)"
    elif cm360 < 50:
        cat = "MEDIUM (balanced arm + wrist)"
    elif cm360 < 65:
        cat = "LOW (mostly arm, precise)"
    else:
        cat = "VERY LOW (full arm, extreme precision)"

    print(f"  Category:  {cat}")

    # Equivalents
    print("\n  Equivalent in other games:")
    print_divider()
    for g in GAME_YAW:
        if g != game:
            eq = cm360_to_sens(cm360, dpi, g)
            print(f"  {GAME_DISPLAY_NAMES[g]:20s} {round(eq, 4)}")


def mode_recommend() -> None:
    """Recommend a sensitivity based on playstyle and setup."""
    print_header("SENSITIVITY RECOMMENDER")
    print("  Answer a few questions to find your ideal sensitivity.\n")

    game = choose_game()
    dpi = get_int("\n  Your mouse DPI: ", 100, 16000)
    mousepad = get_float(
        "\n  Mousepad width in cm (measure it, or guess ~30-45): ",
        lo=10.0, hi=120.0,
    )

    styles = list(PLAYSTYLE_RANGES.keys())
    labels = [f"{s} — {PLAYSTYLE_RANGES[s][2]}" for s in styles]
    playstyle = choose("\n  How do you play?", styles, labels)

    result = recommend_sensitivity(playstyle, mousepad, dpi, game)

    print_header("RECOMMENDED SENSITIVITY")
    print(f"  Game:           {result['game']}")
    print(f"  Playstyle:      {result['playstyle']}")
    print(f"  DPI:            {dpi}")
    print(f"  Mousepad:       {mousepad} cm")
    print()
    print(f"  >>> Recommended: {result['recommended_sensitivity']}")
    print(f"      Range:       {result['range_low']} — {result['range_high']}")
    print(f"      cm/360:      {result['cm_per_360']} cm")
    print(f"      eDPI:        {result['edpi']}")

    if result["mousepad_constrained"]:
        print()
        print("  NOTE: Your mousepad is on the small side for this playstyle.")
        print("  Consider a larger pad (40cm+) for more comfortable low-sens play.")

    print()
    print("  TIP: Start at the recommended value. Play 5 games.")
    print("  Overshooting? Lower it 5-10%. Undershooting? Raise 5-10%.")
    print("  Then LOCK IT IN for at least 2 weeks.")


def mode_convert_all() -> None:
    """Convert one sensitivity to all supported games."""
    print_header("CONVERT TO ALL GAMES")
    print("  Get your sensitivity equivalent in every game at once.\n")

    src = choose_game("  Your current game:")
    sens = get_float(f"\n  Your {GAME_DISPLAY_NAMES[src]} sensitivity: ")
    dpi = get_int("\n  Your mouse DPI: ", 100, 16000)

    cm360 = calc_cm360(dpi, sens, src)

    print_header("YOUR SENSITIVITY ACROSS ALL GAMES")
    print(f"  Base: {GAME_DISPLAY_NAMES[src]} @ {sens} sens, {dpi} DPI")
    print(f"  cm/360: {round(cm360, 1)} cm")
    print()

    for game in GAME_YAW:
        eq_sens = cm360_to_sens(cm360, dpi, game)
        eq_edpi = calc_edpi(dpi, eq_sens)
        marker = " (current)" if game == src else ""
        print(f"  {GAME_DISPLAY_NAMES[game]:20s}  sens: {round(eq_sens, 4):>10}  eDPI: {round(eq_edpi, 1):>10}{marker}")


def mode_export() -> None:
    """Export a sensitivity profile to JSON."""
    print_header("EXPORT SENSITIVITY PROFILE")

    src = choose_game("  Your primary game:")
    sens = get_float(f"\n  Your {GAME_DISPLAY_NAMES[src]} sensitivity: ")
    dpi = get_int("\n  Your mouse DPI: ", 100, 16000)

    cm360 = calc_cm360(dpi, sens, src)

    profile = {
        "primary_game": GAME_DISPLAY_NAMES[src],
        "sensitivity": sens,
        "dpi": dpi,
        "cm_per_360": round(cm360, 1),
        "edpi": round(calc_edpi(dpi, sens), 1),
        "all_games": {},
    }

    for game in GAME_YAW:
        eq = cm360_to_sens(cm360, dpi, game)
        profile["all_games"][GAME_DISPLAY_NAMES[game]] = round(eq, 4)

    filename = "my_sensitivity_profile.json"
    with open(filename, "w") as f:
        json.dump(profile, f, indent=2)

    print(f"\n  Saved to {filename}")
    print(f"  Contains your equivalent sensitivity for all {len(GAME_YAW)} games.")


# =============================================================================
# MAIN MENU
# =============================================================================

def main() -> None:
    """Entry point — main menu loop."""
    print_header("FPS SENSITIVITY CONVERTER")
    print("  Convert, calculate, and optimize your mouse sensitivity")
    print("  across Valorant, Apex, Fortnite, CS2, and Overwatch 2.\n")

    menu = [
        "Convert between two games",
        "Convert to ALL games at once",
        "Calculate eDPI & cm/360",
        "Get a sensitivity recommendation",
        "Export sensitivity profile (JSON)",
        "Quit",
    ]

    while True:
        choice = choose("\n  What do you want to do?", menu)

        if choice == menu[0]:
            mode_convert()
        elif choice == menu[1]:
            mode_convert_all()
        elif choice == menu[2]:
            mode_edpi()
        elif choice == menu[3]:
            mode_recommend()
        elif choice == menu[4]:
            mode_export()
        elif choice == menu[5]:
            print("\n  GG. Happy fragging.\n")
            break


if __name__ == "__main__":
    main()
