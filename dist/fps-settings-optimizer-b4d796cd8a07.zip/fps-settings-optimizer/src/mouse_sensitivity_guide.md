# Mouse Sensitivity Guide — The Science Behind Your Aim

> DPI, in-game sensitivity, eDPI, cm/360 — what they mean, how they interact, and how to find YOUR perfect sensitivity.

## Table of Contents
1. [The Basics: DPI and Sensitivity](#the-basics-dpi-and-sensitivity)
2. [eDPI — Effective DPI](#edpi--effective-dpi)
3. [cm/360 — The Universal Metric](#cm360--the-universal-metric)
4. [How to Calculate cm/360](#how-to-calculate-cm360)
5. [Converting Between Games](#converting-between-games)
6. [Finding Your Ideal Sensitivity](#finding-your-ideal-sensitivity)
7. [Pro Player Sensitivity Ranges](#pro-player-sensitivity-ranges)
8. [Common Myths](#common-myths)

---

## The Basics: DPI and Sensitivity

### What Is DPI?

DPI = Dots Per Inch. It's a hardware setting on your mouse that controls how many pixels the cursor moves per inch of physical mouse movement.

```
DPI COMPARISON:

  400 DPI: Move mouse 1 inch → cursor moves 400 pixels
  800 DPI: Move mouse 1 inch → cursor moves 800 pixels
  1600 DPI: Move mouse 1 inch → cursor moves 1600 pixels
  
  HIGHER DPI ≠ BETTER
  Higher DPI just means the cursor is more sensitive to movement.
  You compensate by lowering in-game sensitivity.
```

### What DPI Should I Use?

```
RECOMMENDED DPI VALUES:

  400 DPI  — Classic CS player territory. Needs large mousepad.
  800 DPI  — The sweet spot for most players. Works everywhere.
  1600 DPI — Good for small mousepads or high-res monitors.
  
  WHY NOT HIGHER?
  - Above 1600 DPI, most sensors introduce smoothing or interpolation
  - Modern optical sensors are most accurate at 400-1600 DPI
  - Higher DPI = more jitter on cheaper mice
  
  THE TRUTH: DPI doesn't matter as long as you adjust in-game sens
  to match. 800 DPI at 0.5 sens = 400 DPI at 1.0 sens. Identical.
```

### In-Game Sensitivity

Every game has its own sensitivity scale. The numbers mean completely different things across games:

```
SAME PHYSICAL MOVEMENT, WILDLY DIFFERENT NUMBERS:

  Valorant:     0.30    (small number, precise scale)
  CS2:          1.05    (medium number)  
  Apex Legends: 1.50    (medium number, different scale)
  Overwatch 2:  4.50    (bigger number)
  Fortnite:     5.5%    (percentage-based)
  
  All of these produce roughly the same mouse movement per 360°.
  This is why you can't just copy numbers between games.
```

---

## eDPI — Effective DPI

eDPI = DPI × In-Game Sensitivity

It's a quick way to compare sensitivities between players using the SAME game. Two players with the same eDPI in the same game will have identical aim speed.

```
eDPI EXAMPLES (Valorant):

  Player A: 800 DPI × 0.30 sens = 240 eDPI
  Player B: 400 DPI × 0.60 sens = 240 eDPI
  Player C: 1600 DPI × 0.15 sens = 240 eDPI
  
  All three have IDENTICAL in-game sensitivity.
  Same physical movement = same rotation.
```

### eDPI Ranges by Game

| Game | Low eDPI | Medium eDPI | High eDPI |
|------|----------|-------------|-----------|
| Valorant | 150-220 | 220-320 | 320-500 |
| CS2 | 600-800 | 800-1100 | 1100-1600 |
| Apex Legends | 800-1200 | 1200-1600 | 1600-2400 |
| Overwatch 2 | 2400-3600 | 3600-5600 | 5600-8000 |
| Fortnite | 28-40 | 40-56 | 56-80 |

**Important:** eDPI only works for comparing within the SAME game. 240 eDPI in Valorant is NOT the same as 240 eDPI in Apex.

---

## cm/360 — The Universal Metric

cm/360 = centimeters of mouse movement needed for a full 360° rotation.

This is the ONLY metric that works across ALL games. If you have the same cm/360 in Valorant and Apex, your muscle memory transfers perfectly.

```
cm/360 CATEGORIES:

  < 20 cm:   VERY HIGH sensitivity
              Wrist aiming only. Twitchy. Hard to control.
              Almost no pros use this.
              
  20-35 cm:  HIGH sensitivity
              Mostly wrist, some arm. Good for fast flicks.
              Common in: OW2 (some DPS), Fortnite (building)
              
  35-50 cm:  MEDIUM sensitivity (the sweet spot)
              Arm + wrist hybrid. Best balance of speed and precision.
              Common in: Valorant, CS2, Apex, most FPS games
              
  50-65 cm:  LOW sensitivity
              Mostly arm aiming. Very precise tracking.
              Common in: CS2 AWPers, Valorant Opers
              
  > 65 cm:   VERY LOW sensitivity
              Full arm movement. Extreme precision.
              Needs a massive mousepad. Rare outside of snipers.
```

### Why cm/360 Matters

```
SCENARIO: You play Valorant and want to try Apex.

  WITHOUT cm/360:
  "I use 0.3 sensitivity in Valorant... what do I use in Apex?"
  "Uh... try 1.5? Maybe 2? Idk just feel it out"
  → Spends weeks rebuilding muscle memory
  
  WITH cm/360:
  "My Valorant sensitivity = 47.6 cm/360"
  "What Apex sensitivity gives me 47.6 cm/360?"
  → Calculator says: 1.49 at 800 DPI
  → Muscle memory transfers instantly
```

---

## How to Calculate cm/360

### The Formula

```
cm/360 = (360 / (DPI × sensitivity × yaw_value)) × 2.54

WHERE:
  DPI          = Your mouse DPI
  sensitivity  = In-game sensitivity
  yaw_value    = Game-specific rotation constant (deg/count at sens 1)
  2.54         = Inches to centimeters conversion

GAME YAW VALUES:
  Valorant:      0.07
  CS2:           0.022
  Apex Legends:  0.022
  Overwatch 2:   0.0066
  Fortnite:      0.5585
```

### Manual Calculation Example

```
EXAMPLE: Valorant, 800 DPI, sensitivity 0.30

  degrees_per_count = yaw × sensitivity
                    = 0.07 × 0.30
                    = 0.021 degrees per mouse count

  counts_per_360 = 360 / 0.021
                 = 17,142.86 counts

  inches_per_360 = 17,142.86 / 800
                 = 21.43 inches

  cm_per_360 = 21.43 × 2.54
             = 54.43 cm

  RESULT: You need 54.43 cm of mouse movement for a full 360°.
```

### Use the Script Instead

Don't do this by hand. Run the included Python tool:

```bash
python3 src/sensitivity_converter.py
```

It calculates cm/360, converts between games, recommends sensitivities, and exports profiles. All stdlib, no pip installs needed.

---

## Converting Between Games

### Step-by-Step Conversion

```
TO CONVERT: Valorant 0.30 @ 800 DPI → Apex Legends

  STEP 1: Calculate cm/360 in source game
    cm/360 = (360 / (800 × 0.30 × 0.07)) × 2.54
           = 54.43 cm

  STEP 2: Reverse the formula for the target game
    target_sens = 360 / (cm/360 / 2.54 × DPI × yaw)
                = 360 / (54.43 / 2.54 × 800 × 0.022)
                = 360 / (21.43 × 800 × 0.022)
                = 360 / 377.14
                = 0.955

  RESULT: Apex sensitivity = 0.955 at 800 DPI
```

### Quick Reference Conversion Table (800 DPI)

| From → To | Valorant 0.30 | CS2 1.0 | Apex 1.5 | OW2 4.5 | Fortnite 5.5% |
|-----------|--------------|---------|----------|---------|---------------|
| cm/360 | 54.4 cm | 51.9 cm | 30.8 cm | 30.2 cm | 29.3 cm |
| → Valorant | **0.30** | 0.31 | 0.53 | 0.54 | 0.56 |
| → CS2 | 1.05 | **1.0** | 1.69 | 1.72 | 1.77 |
| → Apex | 1.05 | 1.0 | **1.5** | 1.53 | 1.58 |
| → OW2 | 4.74 | 4.97 | 8.53 | **4.50** | 8.84 |
| → Fortnite | 5.17 | 5.41 | 9.14 | 9.31 | **5.50** |

*Use the converter script for precise values with your exact DPI.*

---

## Finding Your Ideal Sensitivity

### The PSA Method (Perfect Sensitivity Approximation)

```
STEP 1: ESTABLISH A BASELINE
  Set your cm/360 to 35 cm (medium sensitivity).
  Calculate the in-game sensitivity for your DPI and game.

STEP 2: PLAY 5 GAMES
  Focus on: Can you comfortably...
  - Track a moving target without lifting your mouse?
  - Do a 180° turn without running out of mousepad?
  - Make small adjustments without overshooting?

STEP 3: ADJUST
  Overshooting targets? → INCREASE cm/360 by 5 cm (lower sens)
  Undershooting/lifting mouse? → DECREASE cm/360 by 5 cm (higher sens)

STEP 4: FINE-TUNE
  Repeat step 2-3 with smaller adjustments (2-3 cm).
  When you stop noticing issues → that's your sensitivity.

STEP 5: LOCK IT IN
  Do NOT change your sensitivity for at least 2 weeks.
  Muscle memory needs time. Constantly changing = constant regression.
```

### Sensitivity by Playstyle

| Playstyle | cm/360 Range | Why |
|-----------|-------------|-----|
| Entry/Duelist | 25-40 cm | Need fast 180° turns, clearing angles quickly |
| Support/Anchor | 35-55 cm | Holding angles, precise crosshair placement |
| AWP/Sniper | 40-65 cm | Precise flicks, minimal overcorrection |
| Flex/All-around | 30-45 cm | Balanced for any situation |

### Mousepad Size Constraint

```
YOUR MOUSEPAD LIMITS YOUR SENSITIVITY:

  Minimum requirement: one full mousepad swipe = 180° turn
  
  FORMULA: Minimum cm/360 = mousepad_width × 2
  
  EXAMPLES:
    30 cm mousepad → minimum 60 cm/360 (you'll be lifting a LOT below this)
    40 cm mousepad → minimum 80 cm/360 (comfortable up to ~45 cm/360)
    45 cm mousepad → minimum 90 cm/360 (comfortable for most sensitivities)
    
  RECOMMENDATION: Get a mousepad that's at least 40 cm wide.
  Most gaming mousepads (e.g., QcK+, Artisan, LGG) are 45-50 cm.
```

---

## Pro Player Sensitivity Ranges

### Average cm/360 by Game (Pro Players)

```
GAME              AVG cm/360   RANGE
───────────────────────────────────────
Valorant          42.0 cm      28-65 cm
CS2               47.5 cm      30-70 cm
Apex Legends      30.5 cm      20-45 cm
Overwatch 2       28.0 cm      15-45 cm
Fortnite          32.0 cm      20-50 cm
```

**Why are Apex and OW2 faster?** Both games reward fast movement and 180° turns more than Valorant/CS2. In Valorant, you mostly hold angles. In Apex, you're constantly spinning and tracking.

---

## Common Myths

### Myth 1: "Higher DPI is more accurate"

```
WRONG. Above 1600 DPI, most sensors add smoothing.
The sensor's native resolution matters more than the DPI number.
800 DPI with raw input = perfect for any game.
```

### Myth 2: "Low sensitivity = better aim"

```
HALF TRUE. Low sensitivity gives more precision for SMALL adjustments.
But if your sensitivity is too low, you'll:
  - Lift your mouse constantly (inconsistent)
  - Struggle with 180° turns (die from behind)
  - Fatigue your arm in long sessions
  
The best sensitivity is the LOWEST you can use comfortably without
lifting or struggling with turns.
```

### Myth 3: "Mouse acceleration is always bad"

```
MOSTLY TRUE for FPS games.
Mouse acceleration makes the same physical movement produce
different in-game results depending on speed.
This makes muscle memory nearly impossible to build.

EXCEPTION: Some players use custom acceleration curves
(like RawAccel) after extensive calibration. This is
advanced and NOT recommended for most players.
```

### Myth 4: "You need a 4000 Hz polling rate mouse"

```
DIMINISHING RETURNS.
  
  125 Hz → 1000 Hz: MASSIVE improvement (8ms → 1ms delay)
  1000 Hz → 4000 Hz: Barely noticeable (1ms → 0.25ms)
  
  1000 Hz is sufficient for any competitive level.
  4000 Hz is nice but won't make you rank up.
```

---

*Your sensitivity is the most personal setting in gaming. Don't copy someone else's — find your own. The math just makes it faster.*
