# Optimal Settings — Game-by-Game Breakdown

> Every setting, every game. Tuned for competitive play with clear explanations.

## Table of Contents
1. [Valorant](#valorant)
2. [Apex Legends](#apex-legends)
3. [Fortnite](#fortnite)
4. [CS2](#cs2)
5. [Overwatch 2](#overwatch-2)
6. [Universal Principles](#universal-principles)

---

## Universal Principles

Before diving into specific games, these rules apply everywhere:

```
THE 5 COMMANDMENTS OF FPS SETTINGS:

  1. FULLSCREEN ALWAYS — Borderless adds 1-3 frames of input lag
  2. SHADOWS OFF/LOW — Biggest FPS gain in every game
  3. V-SYNC OFF — Adds 20-50ms input lag, never worth it
  4. EFFECTS LOW — Explosions and particles tank FPS in fights
  5. MOUSE ACCEL OFF — Makes muscle memory impossible
```

### How Settings Affect FPS (Universal)

```
FPS IMPACT RANKING (biggest to smallest):

  Resolution:       ██████████████████████████ (-50-70% at 4K vs 1080p)
  Shadows:          ████████████████████ (-30-40%)
  Effects/Particles:██████████████ (-20-30%)
  Post Processing:  ████████████ (-15-25%)
  Anti-Aliasing:    ████████ (-10-20%)
  View Distance:    ██████ (-5-15%)
  Textures:         ████ (-5-10%, mostly VRAM)
  Anisotropic:      ██ (-1-3%)
```

---

## Valorant

### Video Settings

| Setting | Competitive | Balanced | Why |
|---------|------------|----------|-----|
| Display Mode | Fullscreen | Fullscreen | Lowest input lag |
| Resolution | 1920×1080 | 1920×1080 | Native res, sharp edges |
| Limit FPS | On (240+) | On (144+) | Match monitor + buffer |
| Material Quality | Low | Medium | No competitive impact |
| Texture Quality | Low | Medium | Slight VRAM usage |
| Detail Quality | Low | Medium | Reduces visual clutter |
| UI Quality | Low | Medium | Minor FPS gain |
| Vignette | Off | Off | Darkens screen edges |
| VSync | Off | Off | Always off |
| Anti-Aliasing | None | MSAA 2x | Slight FPS cost |
| Anisotropic | 1x | 4x | Minimal impact |
| Improve Clarity | On | On | Makes enemies sharper |
| Distortion | Off | Off | Visual noise, 0 benefit |
| Cast Shadows | Off | Off | Removes player shadows |

### Audio Settings

| Setting | Recommended | Why |
|---------|-------------|-----|
| Master Volume | 50-70% | Protect hearing |
| Sound Effects | 100% | Footsteps and ability cues |
| Voice-Over | 50% | Agent callouts aren't critical |
| Music | 0% | Distracting in clutch moments |
| HRTF | On | Directional audio (huge for locating enemies) |
| Speaker Config | Stereo | Best directional accuracy with headphones |

### Keybind Recommendations

| Action | Default | Optimized | Why |
|--------|---------|-----------|-----|
| Ability 1 | C | Mouse 4 | Use abilities while strafing |
| Ability 2 | Q | Q | Already well-placed |
| Ultimate | X | Mouse 5 | Quick access for clutch ults |
| Spike (Plant) | 4 | 4 | Default is fine |
| Walk | Shift | Shift | Standard |
| Crouch | Ctrl | Ctrl / C | C is easier to spam |
| Jump | Space | Space | Standard |
| Reload | R | R | Standard |

---

## Apex Legends

### Video Settings

| Setting | Competitive | Balanced | Why |
|---------|------------|----------|-----|
| Display Mode | Full Screen | Full Screen | Lowest input lag |
| Resolution | 1920×1080 | 1920×1080 | Native, sharp visuals |
| FOV | 110 | 104 | Max FOV = see more, slightly smaller targets |
| FPS Cap | Uncapped / 190 | 144 | Higher = smoother inputs |
| V-Sync | Disabled | Disabled | Always off |
| Anti-Aliasing | None / TSAA | TSAA | TSAA is light on performance |
| Texture Streaming | Low / Medium | Medium | Reduces VRAM stutters |
| Texture Filtering | Bilinear | Aniso 4x | Minimal FPS cost |
| Ambient Occlusion | Disabled | Disabled | Big FPS drain, no advantage |
| Sun Shadow Coverage | Low | Low | Shadows = FPS killer |
| Sun Shadow Detail | Low | Low | Same |
| Spot Shadow Detail | Disabled | Low | Slight visual clarity trade |
| Volumetric Lighting | Disabled | Disabled | Pure FPS drain |
| Dynamic Spot Shadows | Disabled | Disabled | Major FPS hit |
| Model Detail | Low | Medium | Minimal visual change |
| Effects Detail | Low | Medium | Cleaner fights |
| Impact Marks | Disabled | Low | No competitive value |
| Ragdolls | Low | Low | Distracting in fights |

### Audio Settings

| Setting | Recommended | Why |
|---------|-------------|-----|
| Master Volume | 60-80% | Balance hearing vs comfort |
| Sound Effects | 100% | Footsteps are life or death |
| Dialogue | 30% | Legend quips are non-essential |
| Music | 0% | Zero competitive value |
| Lobby Music | Personal preference | Doesn't affect gameplay |

### Keybind Recommendations

| Action | Default | Optimized | Why |
|--------|---------|-----------|-----|
| Jump | Space | Space + Scroll Down | Scroll for tap-strafing |
| Crouch | Ctrl | Left Ctrl (Hold) | Hold mode for slide-jumps |
| Tactical | Q | Q / Mouse 4 | Mouse frees left hand |
| Ultimate | Z | Z / Mouse 5 | Quick access |
| Interact | E | E | Standard |
| Sprint | Shift | Auto-Sprint ON | One less button |
| Melee | V | V / F | Punch boost access |
| Holster | 3 | 3 / X | Run speed between fights |

---

## Fortnite

### Video Settings

| Setting | Competitive | Balanced | Why |
|---------|------------|----------|-----|
| Window Mode | Fullscreen | Fullscreen | Mandatory for performance |
| Resolution | 1920×1080 | 1920×1080 | Native res |
| Frame Rate Limit | 240 / Unlimited | 165 | Higher = lower input lag |
| 3D Resolution | 100% | 100% | Below 100% = blurry |
| View Distance | Medium | Far | Players render same distance anyway |
| Shadows | Off | Medium | Biggest FPS gain |
| Anti-Aliasing | Off | Medium | Cleaner edges vs FPS |
| Textures | Low | Medium | Minor VRAM usage |
| Effects | Low | Medium | Explosions won't tank FPS |
| Post Processing | Low | Medium | Removes unnecessary blur |

### Audio Settings

| Setting | Recommended | Why |
|---------|-------------|-----|
| Master Volume | 60-80% | Long sessions, protect ears |
| Music | 0% | Useless in competitive |
| Sound Effects | 100% | Hear builds, footsteps, shots |
| Voice Chat | 50-70% | Hear callouts without distortion |
| Visualize Sound | On (competitive) | Shows sound direction on HUD |

### Keybind Recommendations

| Action | Default | Optimized | Why |
|--------|---------|-----------|-----|
| Wall | - | Q | Fastest build piece access |
| Floor | - | Mouse 5 | Thumb on mouse, doesn't interrupt WASD |
| Ramp | - | Mouse 4 | Same — thumb access |
| Cone/Pyramid | - | T / V | Easy reach |
| Edit | G | F | Closer to WASD |
| Confirm Edit | LMB | LMB | Fastest confirmation |
| Reset Edit | - | Scroll Down | Instant reset |
| Crouch | Ctrl | Left Ctrl / C | Fast crouch-peeks |
| Sprint | Shift | Auto-Sprint ON | Frees your pinky |

---

## CS2

### Video Settings

| Setting | Competitive | Balanced | Why |
|---------|------------|----------|-----|
| Display Mode | Fullscreen | Fullscreen | Lowest latency |
| Resolution | 1280×960 (4:3) | 1920×1080 | 4:3 stretched = wider player models |
| Aspect Ratio | 4:3 (stretched) | 16:9 | Preference — many pros use 4:3 |
| Global Shadow Quality | Low | Medium | FPS + visual clarity |
| Model / Texture Detail | Low | Medium | Minor visual improvement |
| Texture Filtering | Bilinear | Trilinear | Minimal FPS cost |
| Shader Detail | Low | Medium | Reduces water reflections etc. |
| Particle Detail | Low | Low | Smoke and molly clarity |
| Ambient Occlusion | Disabled | Medium | Pure FPS drain |
| High Dynamic Range | Performance | Quality | Brighter = easier to see |
| FidelityFX Super Res | Disabled | Disabled | Introduces blur |
| NVIDIA Reflex | Enabled + Boost | Enabled | Reduces input lag significantly |
| V-Sync | Disabled | Disabled | Always off |
| Multisampling AA | None / 2x | 4x | Smoother edges vs FPS |

### Audio Settings

| Setting | Recommended | Why |
|---------|-------------|-----|
| Master Volume | 50-70% | CS2 is LOUD by default |
| Music Volume | 0% | Round start music is a crutch, learn timing |
| Ten Second Warning | 10-20% | Actually useful for retake timing |
| HRTF | On | Directional sound for footsteps |

### Keybind Recommendations

| Action | Default | Optimized | Why |
|--------|---------|-----------|-----|
| Jump | Space | Space + Scroll Down | Bunny hopping |
| Crouch | Ctrl | Ctrl | Standard |
| Walk | Shift | Shift | Standard |
| Inspect Weapon | F | Unbound | Frees F for use |
| Flashbang | - | Mouse 4 | Quick flash access |
| Smoke | - | Mouse 5 | Quick smoke access |
| HE Grenade | - | 4 / C | Depends on preference |
| Molotov | - | V / X | Easy reach |

---

## Overwatch 2

### Video Settings

| Setting | Competitive | Balanced | Why |
|---------|------------|----------|-----|
| Display Mode | Fullscreen | Fullscreen | Lowest latency |
| Resolution | 1920×1080 | 1920×1080 | Native res |
| Field of View | 103 | 103 | Max FOV, more peripheral vision |
| Frame Rate Cap | 240+ / Display | 165 | Match monitor refresh |
| V-Sync | Off | Off | Always off |
| Graphics Quality | Low | Medium | Custom is better |
| Texture Quality | Medium | High | Medium looks fine, saves VRAM |
| Texture Filtering | Low - 1x | Medium - 2x | Minimal impact |
| Local Fog Detail | Low | Medium | Reduces clutter in fights |
| Dynamic Reflections | Off | Off | Big FPS drain |
| Shadow Detail | Off | Low | Biggest single FPS gain |
| Model Detail | Low | Medium | Slightly cleaner models |
| Effects Detail | Low | Medium | Ult effects won't tank FPS |
| Lighting Quality | Low | Medium | Competitive advantage in dark areas |
| Antialias Quality | Off / Low | Medium | Minor smoothing |
| NVIDIA Reflex | Enabled + Boost | Enabled | Reduces input lag |

### Audio Settings

| Setting | Recommended | Why |
|---------|-------------|-----|
| Master Volume | 60-80% | Long sessions |
| Sound Effects | 100% | Ability cues, footsteps, ult voicelines |
| Music | 0-10% | Distracting in competitive |
| Voice Chat | 60-80% | Callouts are critical in OW2 |
| Dolby Atmos | On (with headphones) | Directional audio for flankers |

### Keybind Recommendations

| Action | Default | Optimized | Why |
|--------|---------|-----------|-----|
| Primary Fire | LMB | LMB | Standard |
| Secondary Fire | RMB | RMB | Standard |
| Ability 1 | Shift | Shift | Good position |
| Ability 2 | E | E | Good position |
| Ultimate | Q | Q | Standard |
| Melee | V | Mouse 4 | Quick melee without moving off WASD |
| Crouch | Ctrl | Ctrl / C | C for fast crouch-spam |
| Jump | Space | Space | Standard |
| Reload | R | R | Standard |
| Interact | F | F | Standard |
| Communication Menu | C | Unbound / X | Frees C for crouch if desired |

---

## Settings Application Checklist

Use this after applying settings for any game:

```
PRE-GAME CHECKLIST:

  [ ] Display Mode = Fullscreen
  [ ] V-Sync = OFF
  [ ] Resolution = Native (or intentional stretch)
  [ ] FPS capped at monitor refresh + buffer
  [ ] Shadows = OFF or LOW
  [ ] Effects = LOW
  [ ] Mouse acceleration = OFF (Windows AND in-game)
  [ ] NVIDIA Reflex or AMD Anti-Lag = ON (if available)
  [ ] All unnecessary background apps closed
  [ ] Power plan = High Performance
  
  THEN:
  [ ] Play 3-5 games to confirm stability (no FPS drops)
  [ ] Monitor temperatures (GPU below 85°C, CPU below 90°C)
  [ ] Note average FPS — this is your baseline
```

---

*Settings are the foundation. Get them right once and you never have to think about them again.*
