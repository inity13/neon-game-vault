# FPS Settings Optimizer — Universal Competitive Settings Guide

> **Price:** $3 | **Skill Level:** All Levels | **Format:** Markdown Guides + Python Tool + JSON Data

## What Is This?

The FPS Settings Optimizer is a cross-game settings bible for competitive FPS players. It covers Valorant, Apex Legends, Fortnite, CS2, and Overwatch 2 — every setting that affects your performance, from video options to mouse sensitivity to OS-level tweaks.

**Stop copying random pro player settings.** This guide teaches you WHY certain settings matter, how they interact with YOUR hardware, and how to find the optimal config for your specific setup. One guide, five games, zero guesswork.

## What's Included

| File | Description |
|------|-------------|
| `src/optimal_settings.md` | Game-by-game optimal settings: video, audio, and keybinds for each title |
| `src/mouse_sensitivity_guide.md` | DPI, in-game sensitivity, eDPI calculator explanation, cm/360 conversion |
| `src/performance_optimization.md` | OS tweaks, GPU driver settings, network optimization for competitive FPS |
| `src/sensitivity_converter.py` | Python script that converts sensitivity between games + eDPI calculator |
| `examples/pro_settings.json` | Database of 20+ pro player settings across all five games |

## Quick Preview

Here's a taste from the sensitivity guide:

### The Universal Metric: cm/360

Every game uses a different sensitivity scale. Valorant's 0.3 feels nothing like Apex's 1.5. But there's one metric that works across ALL games: **cm/360** — how many centimeters of mouse movement it takes to do a full 360° turn.

```
THE SENSITIVITY ROSETTA STONE:

  Same physical movement, different numbers:

  Game          Sensitivity   DPI    cm/360
  ──────────────────────────────────────────
  Valorant      0.30          800    47.6 cm
  Apex Legends  1.50          800    47.1 cm
  CS2           1.05          800    47.5 cm
  Fortnite      5.5%          800    47.0 cm
  Overwatch 2   4.50          800    47.0 cm

  All five = roughly the same physical mouse movement.
  Your muscle memory stays intact across games.
```

### Run the Converter

```bash
python3 src/sensitivity_converter.py
```

The script calculates cm/360, converts between any two supported games, and recommends a starting sensitivity based on your playstyle and mousepad size.

## Who This Is For

- **Multi-game players** who switch between FPS titles and want consistent aim
- **New competitive players** setting up their game for the first time
- **Anyone with FPS issues** looking to squeeze more frames out of their hardware
- **Players copying pro settings** who want to understand what they're actually changing

## How to Use This Guide

1. **Start with `src/optimal_settings.md`** — Find your game, apply the recommended settings
2. **Read `src/mouse_sensitivity_guide.md`** — Understand the math behind sensitivity
3. **Run `src/sensitivity_converter.py`** — Find your ideal sens or convert between games
4. **Apply `src/performance_optimization.md`** — OS and driver tweaks for maximum performance
5. **Reference `examples/pro_settings.json`** — See what the pros use and why

## FAQ

**Q: Will these settings work on my potato PC?**
A: Yes. The guide includes settings tiers: Competitive (max FPS), Balanced, and Performance (low-end). The Performance profile targets 60+ FPS on older hardware.

**Q: Should I just copy a pro's sensitivity?**
A: No. Pro sensitivities vary wildly (20-60 cm/360). The guide teaches you how to find YOUR ideal sensitivity based on your mousepad size, playstyle, and physical comfort. The pro database is for reference, not copying.

**Q: How often do optimal settings change?**
A: Rarely. Core settings (shadows off, low effects, sensitivity principles) haven't changed in years. When game updates change something, the principles in this guide help you adapt.

## License

MIT License — see LICENSE file.
