#!/usr/bin/env python3
"""
Keybind Planner — Generate HTML Keyboard Layout Visualizations

Takes a JSON keybind config and generates a color-coded HTML keyboard
layout showing which key does what.

Usage:
    python3 keybind_planner.py --input layout.json --output keyboard.html
    python3 keybind_planner.py --input layout.json  (prints to stdout)
    python3 keybind_planner.py --list-defaults

No external dependencies — stdlib only.

Author: Game Vault
License: MIT
"""

import argparse
import json
import os
import sys
from typing import Optional


# =============================================================================
# CONSTANTS
# =============================================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULTS_DIR = os.path.join(SCRIPT_DIR, "default_layouts")

# Standard QWERTY keyboard layout (US)
# Each row is a list of (key_id, display_label, width_multiplier)
KEYBOARD_ROWS: list[list[tuple[str, str, float]]] = [
    # Row 0: Function keys
    [
        ("esc", "ESC", 1.0),
        ("_gap1", "", 0.5),
        ("f1", "F1", 1.0), ("f2", "F2", 1.0), ("f3", "F3", 1.0), ("f4", "F4", 1.0),
        ("_gap2", "", 0.3),
        ("f5", "F5", 1.0), ("f6", "F6", 1.0), ("f7", "F7", 1.0), ("f8", "F8", 1.0),
        ("_gap3", "", 0.3),
        ("f9", "F9", 1.0), ("f10", "F10", 1.0), ("f11", "F11", 1.0), ("f12", "F12", 1.0),
    ],
    # Row 1: Number row
    [
        ("backtick", "`", 1.0),
        ("1", "1", 1.0), ("2", "2", 1.0), ("3", "3", 1.0), ("4", "4", 1.0),
        ("5", "5", 1.0), ("6", "6", 1.0), ("7", "7", 1.0), ("8", "8", 1.0),
        ("9", "9", 1.0), ("0", "0", 1.0), ("minus", "-", 1.0), ("equals", "=", 1.0),
        ("backspace", "BKSP", 2.0),
    ],
    # Row 2: QWERTY top
    [
        ("tab", "TAB", 1.5),
        ("q", "Q", 1.0), ("w", "W", 1.0), ("e", "E", 1.0), ("r", "R", 1.0),
        ("t", "T", 1.0), ("y", "Y", 1.0), ("u", "U", 1.0), ("i", "I", 1.0),
        ("o", "O", 1.0), ("p", "P", 1.0), ("lbracket", "[", 1.0),
        ("rbracket", "]", 1.0), ("backslash", "\\", 1.5),
    ],
    # Row 3: Home row
    [
        ("capslock", "CAPS", 1.75),
        ("a", "A", 1.0), ("s", "S", 1.0), ("d", "D", 1.0), ("f", "F", 1.0),
        ("g", "G", 1.0), ("h", "H", 1.0), ("j", "J", 1.0), ("k", "K", 1.0),
        ("l", "L", 1.0), ("semicolon", ";", 1.0), ("quote", "'", 1.0),
        ("enter", "ENTER", 2.25),
    ],
    # Row 4: Bottom row
    [
        ("lshift", "SHIFT", 2.25),
        ("z", "Z", 1.0), ("x", "X", 1.0), ("c", "C", 1.0), ("v", "V", 1.0),
        ("b", "B", 1.0), ("n", "N", 1.0), ("m", "M", 1.0), ("comma", ",", 1.0),
        ("period", ".", 1.0), ("slash", "/", 1.0),
        ("rshift", "RSHIFT", 2.75),
    ],
    # Row 5: Spacebar row
    [
        ("lctrl", "CTRL", 1.5),
        ("lalt", "ALT", 1.25),
        ("space", "SPACE", 6.25),
        ("ralt", "RALT", 1.25),
        ("rctrl", "RCTRL", 1.5),
    ],
]

# Category colors for the HTML output
CATEGORY_COLORS: dict[str, str] = {
    "movement": "#3b82f6",      # blue
    "combat": "#ef4444",        # red
    "abilities": "#22c55e",     # green
    "utility": "#eab308",       # yellow
    "communication": "#a855f7", # purple
    "building": "#f97316",      # orange
    "weapons": "#ec4899",       # pink
    "default": "#6b7280",       # gray
}


# =============================================================================
# LAYOUT LOADING
# =============================================================================

def load_layout(filepath: str) -> dict:
    """Load a keybind layout from a JSON file.

    Expected format:
    {
        "meta": { "game": "...", "name": "..." },
        "bindings": {
            "key_id": { "action": "...", "category": "..." },
            ...
        }
    }

    Args:
        filepath: Path to the JSON layout file.

    Returns:
        Parsed layout dictionary.
    """
    with open(filepath, "r") as f:
        return json.load(f)


def list_defaults() -> list[str]:
    """List available default layout files.

    Returns:
        List of layout file names.
    """
    if not os.path.isdir(DEFAULTS_DIR):
        return []
    return [f for f in os.listdir(DEFAULTS_DIR) if f.endswith(".json")]


# =============================================================================
# HTML GENERATION
# =============================================================================

def generate_html(layout: dict) -> str:
    """Generate a complete HTML page showing the keyboard layout.

    Args:
        layout: Layout dictionary with meta and bindings.

    Returns:
        Complete HTML string.
    """
    meta = layout.get("meta", {})
    bindings = layout.get("bindings", {})
    game = meta.get("game", "Custom")
    name = meta.get("name", "Keybind Layout")

    key_size = 54  # base key size in pixels
    gap = 4

    html_parts = []
    html_parts.append(f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{name} — {game} Keybinds</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    background: #0a0a0a;
    color: #e5e5e5;
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    padding: 40px;
    display: flex;
    flex-direction: column;
    align-items: center;
  }}
  h1 {{
    font-size: 24px;
    margin-bottom: 8px;
    color: #fff;
  }}
  .subtitle {{
    color: #888;
    font-size: 14px;
    margin-bottom: 30px;
  }}
  .keyboard {{
    background: #1a1a1a;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 20px;
    display: flex;
    flex-direction: column;
    gap: {gap}px;
  }}
  .row {{
    display: flex;
    gap: {gap}px;
  }}
  .key {{
    height: {key_size}px;
    border-radius: 6px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border: 1px solid #444;
    background: #2a2a2a;
    position: relative;
    overflow: hidden;
  }}
  .key-label {{
    font-size: 11px;
    font-weight: 700;
    color: #ccc;
    z-index: 1;
  }}
  .key-action {{
    font-size: 9px;
    color: #fff;
    margin-top: 2px;
    z-index: 1;
    text-align: center;
    padding: 0 2px;
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }}
  .key.bound {{
    border-color: rgba(255,255,255,0.2);
  }}
  .key.bound::before {{
    content: '';
    position: absolute;
    inset: 0;
    opacity: 0.25;
    border-radius: 5px;
  }}
  .gap {{
    background: transparent;
    border: none;
  }}
  .legend {{
    display: flex;
    gap: 20px;
    margin-top: 20px;
    flex-wrap: wrap;
    justify-content: center;
  }}
  .legend-item {{
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    color: #aaa;
  }}
  .legend-color {{
    width: 14px;
    height: 14px;
    border-radius: 3px;
  }}
</style>
</head>
<body>
<h1>{name}</h1>
<p class="subtitle">{game} — Generated by Game Vault Keybind Planner</p>
<div class="keyboard">
""")

    # Generate keyboard rows
    for row in KEYBOARD_ROWS:
        html_parts.append('  <div class="row">')
        for key_id, label, width in row:
            w = int(key_size * width + gap * (width - 1))

            if key_id.startswith("_gap"):
                html_parts.append(f'    <div class="key gap" style="width:{w}px"></div>')
                continue

            binding = bindings.get(key_id, {})
            action = binding.get("action", "")
            category = binding.get("category", "default")
            color = CATEGORY_COLORS.get(category, CATEGORY_COLORS["default"])

            bound_class = " bound" if action else ""
            bg_style = f"background-color:{color}" if action else ""

            html_parts.append(f'    <div class="key{bound_class}" style="width:{w}px">')
            if action:
                html_parts.append(f'      <div style="position:absolute;inset:0;background:{color};opacity:0.2;border-radius:5px"></div>')
            html_parts.append(f'      <span class="key-label">{label}</span>')
            if action:
                html_parts.append(f'      <span class="key-action">{action}</span>')
            html_parts.append('    </div>')

        html_parts.append('  </div>')

    html_parts.append('</div>')

    # Legend
    used_categories = set()
    for b in bindings.values():
        if b.get("action"):
            used_categories.add(b.get("category", "default"))

    if used_categories:
        html_parts.append('<div class="legend">')
        for cat in sorted(used_categories):
            color = CATEGORY_COLORS.get(cat, CATEGORY_COLORS["default"])
            html_parts.append(
                f'  <div class="legend-item">'
                f'<div class="legend-color" style="background:{color}"></div>'
                f'{cat.capitalize()}</div>'
            )
        html_parts.append('</div>')

    html_parts.append('</body>\n</html>')

    return "\n".join(html_parts)


# =============================================================================
# CLI
# =============================================================================

def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Generate HTML keyboard layout visualizations from JSON configs."
    )
    parser.add_argument("--input", "-i", help="Path to keybind JSON file")
    parser.add_argument("--output", "-o", help="Output HTML file (default: stdout)")
    parser.add_argument("--list-defaults", action="store_true",
                        help="List available default layout files")

    args = parser.parse_args()

    if args.list_defaults:
        defaults = list_defaults()
        if defaults:
            print("Available default layouts:")
            for f in defaults:
                print(f"  {f}")
        else:
            print("No default layouts found.")
        return

    if not args.input:
        parser.print_help()
        print("\nError: --input is required (path to a keybind JSON file)")
        sys.exit(1)

    layout = load_layout(args.input)
    html = generate_html(layout)

    if args.output:
        with open(args.output, "w") as f:
            f.write(html)
        print(f"Generated: {args.output}")
    else:
        print(html)


if __name__ == "__main__":
    main()
