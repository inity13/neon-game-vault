# Gaming Keybind Planner — Visual Keyboard Layout Tool

> **Price:** $1 | **Skill Level:** All Levels | **Format:** Python Script + HTML Visualizer + JSON Configs

## What Is This?

The Gaming Keybind Planner is a tool for designing, visualizing, and sharing keyboard layouts for any game. Feed it a JSON config of your keybinds and it generates a color-coded HTML keyboard visualization. Or use the interactive HTML planner to click keys and assign actions directly.

**Keybind optimization is free performance.** A well-planned layout means less finger travel, faster ability use, and fewer misclicks in fights. This tool makes it easy to experiment with layouts before committing them in-game.

## What's Included

| File | Description |
|------|-------------|
| `src/keybind_planner.py` | Python script that generates HTML keyboard visualizations from JSON configs |
| `src/default_layouts/valorant.json` | Default Valorant keybind layout |
| `src/default_layouts/apex.json` | Default Apex Legends keybind layout |
| `src/default_layouts/fortnite.json` | Default Fortnite keybind layout |
| `demo/index.html` | Interactive HTML keybind planner — click keys to assign actions, export JSON |
| `preview/keyboard_layout.html` | Static preview showing a sample keybind layout |

## Quick Preview

### Generate a Keyboard Visualization

```bash
# From a default layout
python3 src/keybind_planner.py --input src/default_layouts/valorant.json --output my_layout.html

# Open the generated file in your browser
# (or just double-click it)
```

### Interactive Planner

Open `demo/index.html` in any browser. No server needed — it's pure HTML/CSS/JS.

- Click any key on the keyboard to assign an action
- Color-coded by category (movement, abilities, weapons, utility)
- Export your layout as JSON
- Import existing JSON layouts

### What the Output Looks Like

```
  ┌─────────────────────────────────────────────────┐
  │  [ESC]    [F1][F2][F3][F4] [F5][F6][F7][F8]    │
  │                                                  │
  │  [`][1 ][2 ][3 ][4 ][5 ][6 ][7 ][8 ][9 ][0 ]  │
  │     WPN WPN WPN WPN  5   6   7   8   9   0     │
  │                                                  │
  │  [TAB][Q ][W ][E ][R ][T ][Y ][U ][I ][O ][P ] │
  │   INV ABL FWD INT RLD  .   .   .   .   .   .   │
  │                                                  │
  │  [CAP][A ][S ][D ][F ][G ][H ][J ][K ][L ][; ] │
  │       LFT BCK RGT ABL  .   .   .   .   .   .   │
  │                                                  │
  │  [SHFT ][Z ][X ][C ][V ][B ][N ][M ][, ][. ]   │
  │   WALK  ULT  .  CRC MLY  .   .   .   .   .     │
  │                                                  │
  │  [CTRL]  [ALT]  [     SPACE     ]  [ALT] [CTRL] │
  │   CROUCH         JUMP                            │
  └─────────────────────────────────────────────────┘
  
  Colors: BLUE=Movement  RED=Combat  GREEN=Abilities
          YELLOW=Utility  PURPLE=Communication
```

## Who This Is For

- **Anyone switching keybinds** who wants to plan before committing
- **New PC gamers** setting up their first keyboard layout
- **Multi-game players** who want consistent binds across games
- **Content creators** making keybind guides for their audience

## How to Use

1. **Start with a default layout** from `src/default_layouts/` for your game
2. **Run the Python script** to generate an HTML visualization
3. **Open `demo/index.html`** to interactively modify the layout
4. **Export your custom layout** as JSON for backup or sharing
5. **Apply the keybinds** in your game's settings

## FAQ

**Q: Does this change my actual game keybinds?**
A: No. This is a planning and visualization tool. You still need to apply the keybinds in your game's settings manually.

**Q: Can I use this for games not included?**
A: Absolutely. The JSON format is universal. Create a new layout file for any game — the tool just reads key-to-action mappings.

**Q: Does the HTML planner need internet?**
A: No. It's a standalone HTML file. No server, no CDN, no internet required.

## License

MIT License — see LICENSE file.
